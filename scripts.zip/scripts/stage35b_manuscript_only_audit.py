from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# STAGE 35B — MANUSCRIPT-ONLY FINAL CONSISTENCY AUDIT
# ============================================================

ROOT = Path(__file__).resolve().parent

SCI = ROOT / "scientific_validation_results"
FIG = ROOT / "figures"

OUT = SCI / "stage35b_audit"
OUT.mkdir(parents=True, exist_ok=True)

print("=" * 100)
print("STAGE 35B — MANUSCRIPT-ONLY FINAL Q1 CONSISTENCY AUDIT")
print("=" * 100)

# ============================================================
# FINAL VERIFIED VALUES
# ============================================================

EXPECTED = {
    "ExtraTrees_MAE": 1400.3844781891,
    "ExtraTrees_RMSE": 4036.1221687711,
    "ExtraTrees_R2": 0.9804465419,
    "ExtraTrees_Pearson": 0.9902146576,
    "ExtraTrees_Bias": 26.3903403536,

    "XGB_MAE": 1490.7452392578125,
    "XGB_RMSE": 4087.0079520353274,
    "XGB_R2": 0.9799503684,
    "XGB_Pearson": 0.98993228,

    "Lag_28": 20.004240,
    "Lag_7": 19.759367,
    "Lag_14": 16.097803,
}

# ============================================================
# 1. VERIFIED SOURCE FILES
# ============================================================

model_file = SCI / "FINAL_MANUSCRIPT_MODEL_RESULTS.csv"
feature_file = SCI / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"

print("\n" + "=" * 100)
print("1. SOURCE-OF-TRUTH FILES")
print("=" * 100)

print(f"Model results   : {model_file}")
print(f"Feature results : {feature_file}")

if not model_file.exists():
    raise FileNotFoundError(model_file)

if not feature_file.exists():
    raise FileNotFoundError(feature_file)

model_df = pd.read_csv(model_file)
feature_df = pd.read_csv(feature_file)

print("\nModel results:")
print(model_df.to_string(index=False))

print("\nFeature importance:")
print(feature_df.to_string(index=False))


# ============================================================
# 2. METRIC RECONCILIATION
# ============================================================

print("\n" + "=" * 100)
print("2. METRIC RECONCILIATION")
print("=" * 100)

checks = []


def add_check(name, actual, expected, tolerance=1e-6):

    ok = np.isclose(
        float(actual),
        float(expected),
        atol=tolerance,
        rtol=1e-6
    )

    checks.append({
        "Check": name,
        "Expected": expected,
        "Actual": actual,
        "Status": "PASS" if ok else "FAIL"
    })


for _, row in model_df.iterrows():

    model = str(row["Model"]).lower()

    if "extratrees" in model:

        add_check(
            "ExtraTrees MAE",
            row["Test_MAE"],
            EXPECTED["ExtraTrees_MAE"]
        )

        add_check(
            "ExtraTrees RMSE",
            row["Test_RMSE"],
            EXPECTED["ExtraTrees_RMSE"]
        )

        add_check(
            "ExtraTrees R2",
            row["Test_R2"],
            EXPECTED["ExtraTrees_R2"]
        )

        add_check(
            "ExtraTrees Pearson",
            row["Test_Pearson_r"],
            EXPECTED["ExtraTrees_Pearson"]
        )

        if "Mean_Bias" in model_df.columns:
            add_check(
                "ExtraTrees Mean Bias",
                row["Mean_Bias"],
                EXPECTED["ExtraTrees_Bias"]
            )

    elif "xgboost" in model:

        add_check(
            "XGBoost MAE",
            row["Test_MAE"],
            EXPECTED["XGB_MAE"]
        )

        add_check(
            "XGBoost RMSE",
            row["Test_RMSE"],
            EXPECTED["XGB_RMSE"]
        )

        add_check(
            "XGBoost R2",
            row["Test_R2"],
            EXPECTED["XGB_R2"]
        )

        add_check(
            "XGBoost Pearson",
            row["Test_Pearson_r"],
            EXPECTED["XGB_Pearson"]
        )


# ============================================================
# 3. FEATURE IMPORTANCE
# ============================================================

print("\n" + "=" * 100)
print("3. FEATURE IMPORTANCE RECONCILIATION")
print("=" * 100)

for feature_name, expected in [
    ("Lag_28", EXPECTED["Lag_28"]),
    ("Lag_7", EXPECTED["Lag_7"]),
    ("Lag_14", EXPECTED["Lag_14"]),
]:

    matches = feature_df[
        feature_df["Feature"].astype(str).str.contains(
            feature_name,
            case=False,
            regex=False
        )
    ]

    if len(matches) == 0:

        checks.append({
            "Check": f"Feature importance {feature_name}",
            "Expected": expected,
            "Actual": "NOT FOUND",
            "Status": "FAIL"
        })

    else:

        actual = float(matches.iloc[0]["Percentage"])

        add_check(
            f"Feature importance {feature_name}",
            actual,
            expected,
            tolerance=1e-4
        )


# ============================================================
# 4. FIGURE AUDIT
# ============================================================

print("\n" + "=" * 100)
print("4. FINAL FIGURE AUDIT")
print("=" * 100)

required_figures = [
    "Figure_1_Feature_Importance.png",
    "Figure_1_Feature_Importance.pdf",

    "Figure_2_Actual_vs_Predicted.png",
    "Figure_2_Actual_vs_Predicted.pdf",

    "Figure_3_Residual_Diagnostics.png",
    "Figure_3_Residual_Diagnostics.pdf",

    "Figure_4_Model_Comparison.png",
    "Figure_4_Model_Comparison.pdf",
]

figure_checks = []

for filename in required_figures:

    path = FIG / filename

    status = "PASS" if path.exists() else "FAIL"

    figure_checks.append({
        "File": filename,
        "Exists": path.exists(),
        "Size_bytes": path.stat().st_size if path.exists() else 0,
        "Status": status
    })

    print(f"[{status}] {filename}")

figure_df = pd.DataFrame(figure_checks)

figure_df.to_csv(
    OUT / "figure_audit.csv",
    index=False
)


# ============================================================
# 5. MANUSCRIPT-ONLY LEGACY VALUE CHECK
# ============================================================

print("\n" + "=" * 100)
print("5. MANUSCRIPT-ONLY LEGACY VALUE CHECK")
print("=" * 100)

# ------------------------------------------------------------
# IMPORTANT:
# This section deliberately does NOT scan:
#
# - *.csv raw prediction files
# - *.csv datasets
# - validation scripts
# - stage scripts
#
# because old numbers can legitimately occur there as:
# validation targets, residuals, historical references, etc.
#
# The audit is only concerned with actual manuscript text.
# ------------------------------------------------------------

manuscript_candidates = []

patterns = [
    "manuscript",
    "paper",
    "article",
    "final",
]

for path in ROOT.rglob("*"):

    if not path.is_file():
        continue

    if ".venv" in path.parts:
        continue

    if "scientific_validation_results" in path.parts:
        continue

    suffix = path.suffix.lower()

    if suffix not in {".docx", ".doc", ".tex", ".md", ".txt", ".rtf"}:
        continue

    name = path.name.lower()

    if any(pattern in name for pattern in patterns):
        manuscript_candidates.append(path)


print("\nCandidate manuscript files:")

if manuscript_candidates:

    for path in manuscript_candidates:
        print("  ", path)

else:

    print("  No manuscript file found in project root.")

# ------------------------------------------------------------
# Search only textual manuscript files.
# DOCX is intentionally not parsed here because a binary DOCX
# should be inspected separately if it exists.
# ------------------------------------------------------------

legacy_hits = []

rejected_patterns = [
    "61.998%",
    "61.998",
    "-5.48",
    "mean bias = -5.48",
    "Mean Bias = -5.48",
]

for path in manuscript_candidates:

    if path.suffix.lower() == ".docx":
        continue

    try:
        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )
    except Exception:
        continue

    for pattern in rejected_patterns:

        if pattern.lower() in text.lower():

            legacy_hits.append({
                "File": str(path.relative_to(ROOT)),
                "Rejected_Value": pattern
            })


legacy_df = pd.DataFrame(
    legacy_hits,
    columns=["File", "Rejected_Value"]
)

legacy_df.to_csv(
    OUT / "manuscript_only_legacy_scan.csv",
    index=False
)

if len(legacy_df) == 0:

    print("\n[PASS] No rejected legacy values found in manuscript text.")

else:

    print("\n[FAIL] Rejected values found in manuscript:")
    print(legacy_df.to_string(index=False))


# ============================================================
# 6. FINAL STATUS
# ============================================================

print("\n" + "=" * 100)
print("6. FINAL STAGE 35B STATUS")
print("=" * 100)

check_df = pd.DataFrame(checks)

if len(check_df):

    print(check_df.to_string(index=False))

metric_failures = int(
    (check_df["Status"] == "FAIL").sum()
)

figure_failures = int(
    (figure_df["Status"] == "FAIL").sum()
)

legacy_failures = len(legacy_df)

total_failures = (
    metric_failures +
    figure_failures +
    legacy_failures
)

summary = pd.DataFrame([{
    "Metric_failures": metric_failures,
    "Figure_failures": figure_failures,
    "Manuscript_legacy_value_hits": legacy_failures,
    "Total_failures": total_failures,
    "Overall_status": (
        "PASS"
        if total_failures == 0
        else "REVIEW_REQUIRED"
    )
}])

summary.to_csv(
    OUT / "STAGE35B_FINAL_STATUS.csv",
    index=False
)

print("\n")
print(summary.to_string(index=False))

print("\n" + "=" * 100)

if total_failures == 0:

    print("STAGE 35B — PASS")
    print()
    print("Scientific metrics: PASS")
    print("Feature importance: PASS")
    print("Figures: PASS")
    print("Manuscript legacy-value scan: PASS")
    print()
    print("FINAL Q1 CONSISTENCY AUDIT PASSED.")

else:

    print("STAGE 35B — REVIEW REQUIRED")
    print(f"Total failures: {total_failures}")

print("=" * 100)

print("\nNEXT STAGE:")
print("STAGE 36 -> FINAL Q1 SUBMISSION PACKAGE")
print("=" * 100)