
from pathlib import Path
import json
import numpy as np
import pandas as pd

# ============================================================
# STAGE 77: TEMPORAL LEAKAGE, FEATURE INTEGRITY & RESULTS AUDIT
# Does NOT modify any existing project files.
# ============================================================

BASE_DIR = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

DATA_DIR = BASE_DIR / "tfl_calendar_ml"
RESULTS_DIR = BASE_DIR / "tfl_mhtdr_station_ablation_stage76"
AUDIT_DIR = BASE_DIR / "tfl_stage77_audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

SPLIT_FILES = [
    DATA_DIR / "train_2023.csv",
    DATA_DIR / "validation_2024.csv",
    DATA_DIR / "test_2025_2026.csv",
]

LAG_DAYS = [1, 7, 14, 28]
ROLLING_COLUMNS = [
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

checks = []
warnings = []


def record(name, passed, details):
    checks.append({
        "Check": name,
        "Status": "PASS" if passed else "REVIEW",
        "Details": str(details),
    })
    print(f"[{'PASS' if passed else 'REVIEW'}] {name}: {details}")


print("=" * 88)
print("STAGE 77 — TEMPORAL LEAKAGE & FEATURE INTEGRITY AUDIT")
print("=" * 88)

# ============================================================
# 1. VERIFY INPUT FILES
# ============================================================

missing_files = [str(p) for p in SPLIT_FILES if not p.exists()]

if missing_files:
    raise FileNotFoundError(
        "Required input files are missing:\n" + "\n".join(missing_files)
    )

frames = []

for path in SPLIT_FILES:
    part = pd.read_csv(path, low_memory=False)
    part["TravelDate"] = pd.to_datetime(
        part["TravelDate"], errors="coerce"
    )
    part["_AuditSplit"] = path.stem
    frames.append(part)
    print(f"Loaded {path.name}: {len(part):,} rows")

df = pd.concat(frames, ignore_index=True)

required = {
    "Station", "TravelDate", "TotalFootfall",
    *[f"Lag_{d}" for d in LAG_DAYS],
    *ROLLING_COLUMNS,
}

missing_columns = sorted(required - set(df.columns))

if missing_columns:
    raise ValueError(
        "Required columns missing: " + ", ".join(missing_columns)
    )

record(
    "Required columns",
    True,
    f"All required columns present; combined rows={len(df):,}"
)

# ============================================================
# 2. DUPLICATE AND DATE-INTEGRITY CHECKS
# ============================================================

duplicates = int(
    df.duplicated(["Station", "TravelDate"]).sum()
)

record(
    "Unique Station-Date keys",
    duplicates == 0,
    f"Duplicate rows={duplicates}"
)

invalid_dates = int(df["TravelDate"].isna().sum())

record(
    "Valid dates",
    invalid_dates == 0,
    f"Invalid dates={invalid_dates}"
)

negative_targets = int(
    (df["TotalFootfall"].dropna() < 0).sum()
)

record(
    "Non-negative targets",
    negative_targets == 0,
    f"Negative target rows={negative_targets}"
)

# Verify split date boundaries.
split_checks = {
    "train_2023": (2023, 2023),
    "validation_2024": (2024, 2024),
    "test_2025_2026": (2025, 2026),
}

for split_name, (year_min, year_max) in split_checks.items():
    part = df[df["_AuditSplit"] == split_name]
    years = part["TravelDate"].dt.year.dropna()

    ok = (
        len(years) > 0
        and years.min() >= year_min
        and years.max() <= year_max
    )

    record(
        f"Date boundaries: {split_name}",
        ok,
        (
            f"rows={len(part):,}; "
            f"years={years.min() if len(years) else 'NA'}"
            f"-{years.max() if len(years) else 'NA'}"
        )
    )

# ============================================================
# 3. STATION-DATE COVERAGE AND GAPS
# ============================================================

coverage = (
    df.groupby("_AuditSplit")
    .agg(
        Rows=("TotalFootfall", "size"),
        Stations=("Station", "nunique"),
        FirstDate=("TravelDate", "min"),
        LastDate=("TravelDate", "max"),
    )
    .reset_index()
)

coverage.to_csv(
    AUDIT_DIR / "stage77_split_coverage.csv",
    index=False
)

gap_rows = []

for station, group in df.groupby("Station"):
    dates = (
        group["TravelDate"]
        .dropna()
        .drop_duplicates()
        .sort_values()
    )

    if len(dates) > 1:
        gaps = dates.diff().dt.days.dropna()
        gap_rows.append({
            "Station": station,
            "Date_Count": len(dates),
            "Max_Gap_Days": int(gaps.max()),
            "Gaps_Over_1_Day": int((gaps > 1).sum()),
        })

gaps_df = pd.DataFrame(gap_rows)
gaps_df.to_csv(
    AUDIT_DIR / "stage77_station_date_gaps.csv",
    index=False
)

stations_with_gaps = (
    int((gaps_df["Gaps_Over_1_Day"] > 0).sum())
    if not gaps_df.empty else 0
)

record(
    "Station date continuity",
    stations_with_gaps == 0,
    f"Stations with gaps > 1 day={stations_with_gaps}"
)

# ============================================================
# 4. VERIFY CALENDAR-DAY LAGS
# ============================================================

# Use the observed target from exactly the required prior date.
# Compare only rows where that prior observation is available
# in the combined audit data.

target_lookup = df[
    ["Station", "TravelDate", "TotalFootfall"]
].copy()

lag_summary = []

for lag_days in LAG_DAYS:
    expected = target_lookup.copy()

    expected["TravelDate"] = (
        expected["TravelDate"]
        + pd.Timedelta(days=lag_days)
    )

    expected = expected.rename(
        columns={"TotalFootfall": "_ExpectedLag"}
    )

    joined = df[
        ["Station", "TravelDate", f"Lag_{lag_days}"]
    ].merge(
        expected,
        on=["Station", "TravelDate"],
        how="left",
        validate="many_to_one",
    )

    comparable = (
        joined["_ExpectedLag"].notna()
        & joined[f"Lag_{lag_days}"].notna()
    )

    n = int(comparable.sum())

    if n:
        diff = (
            joined.loc[comparable, f"Lag_{lag_days}"].astype(float)
            - joined.loc[comparable, "_ExpectedLag"].astype(float)
        ).abs()

        mismatches = int((diff > 1e-8).sum())
        max_error = float(diff.max())
    else:
        mismatches = 0
        max_error = None

    lag_summary.append({
        "Feature": f"Lag_{lag_days}",
        "Comparable_Rows": n,
        "Mismatches": mismatches,
        "Max_Absolute_Error": max_error,
    })

    record(
        f"Lag_{lag_days} calendar-date alignment",
        n > 0 and mismatches == 0,
        f"compared={n:,}; mismatches={mismatches}; max_error={max_error}"
    )

pd.DataFrame(lag_summary).to_csv(
    AUDIT_DIR / "stage77_lag_integrity.csv",
    index=False
)

# ============================================================
# 5. VERIFY ROLLING FEATURES
# ============================================================

# Recompute the original shift(1) + time-window rolling procedure.
# The first 35 days per station are excluded from comparison because
# early history may be absent from the already-filtered split files.

rolling_summary = []

for station, group in df.groupby("Station"):
    group = group.sort_values("TravelDate").copy()

    if group["TravelDate"].duplicated().any():
        continue

    station_series = group.set_index("TravelDate")["TotalFootfall"]
    previous = station_series.shift(1)

    recomputed = pd.DataFrame(index=station_series.index)

    recomputed["RollingMean_7"] = (
        previous.rolling("7D", min_periods=3).mean()
    )
    recomputed["RollingStd_7"] = (
        previous.rolling("7D", min_periods=3).std()
    )
    recomputed["RollingMean_14"] = (
        previous.rolling("14D", min_periods=5).mean()
    )
    recomputed["RollingMean_28"] = (
        previous.rolling("28D", min_periods=7).mean()
    )

    first_date = station_series.index.min()
    eligible = (
        station_series.index >= first_date + pd.Timedelta(days=35)
    )

    for col in ROLLING_COLUMNS:
        observed = group.set_index("TravelDate")[col]
        expected = recomputed[col]

        comparable = (
            eligible
            & observed.notna().to_numpy()
            & expected.notna().to_numpy()
        )

        if comparable.sum() == 0:
            continue

        observed_values = observed.to_numpy(dtype=float)[comparable]
        expected_values = expected.to_numpy(dtype=float)[comparable]

        errors = np.abs(observed_values - expected_values)
        mismatches = int((errors > 1e-6).sum())

        rolling_summary.append({
            "Station": station,
            "Feature": col,
            "Comparable_Rows": int(comparable.sum()),
            "Mismatches": mismatches,
            "Max_Absolute_Error": float(errors.max()),
        })

rolling_df = pd.DataFrame(rolling_summary)

if not rolling_df.empty:
    rolling_df.to_csv(
        AUDIT_DIR / "stage77_rolling_integrity.csv",
        index=False
    )

    total_compared = int(rolling_df["Comparable_Rows"].sum())
    total_mismatches = int(rolling_df["Mismatches"].sum())

    record(
        "Rolling feature reconstruction",
        total_compared > 0 and total_mismatches == 0,
        (
            f"comparisons={total_compared:,}; "
            f"mismatches={total_mismatches:,}"
        )
    )
else:
    record(
        "Rolling feature reconstruction",
        False,
        "No eligible rolling-feature rows were available for comparison"
    )

# ============================================================
# 6. CHECK STAGE 76 RESULT ARTIFACTS
# ============================================================

result_files = [
    RESULTS_DIR / "station_ablation_metrics.csv",
    RESULTS_DIR / "station_ablation_test_predictions.csv",
    RESULTS_DIR / "experiment_config.json",
    RESULTS_DIR / "station_coverage_audit.json",
]

artifact_report = []

for path in result_files:
    exists = path.exists()
    rows = None
    columns = None
    error = None

    if exists and path.suffix == ".csv":
        try:
            temp = pd.read_csv(path, low_memory=False)
            rows = len(temp)
            columns = list(temp.columns)
        except Exception as exc:
            error = str(exc)

    artifact_report.append({
        "File": path.name,
        "Exists": exists,
        "Rows": rows,
        "Columns": json.dumps(columns) if columns else None,
        "Read_Error": error,
    })

    record(
        f"Stage76 artifact: {path.name}",
        exists and error is None,
        f"exists={exists}; rows={rows}; read_error={error}"
    )

pd.DataFrame(artifact_report).to_csv(
    AUDIT_DIR / "stage77_results_artifact_audit.csv",
    index=False
)

# Show the stored Stage76 metric table for review.
metrics_path = RESULTS_DIR / "station_ablation_metrics.csv"

if metrics_path.exists():
    metrics = pd.read_csv(metrics_path)
    print("\nSTAGE 76 METRICS")
    print(metrics.to_string(index=False))
else:
    warnings.append("Stage76 metrics CSV was not found.")

# ============================================================
# 7. FINAL REPORT
# ============================================================

checks_df = pd.DataFrame(checks)
checks_df.to_csv(
    AUDIT_DIR / "stage77_audit_checks.csv",
    index=False
)

summary = {
    "stage": 77,
    "combined_rows": int(len(df)),
    "station_count": int(df["Station"].nunique()),
    "date_min": str(df["TravelDate"].min()),
    "date_max": str(df["TravelDate"].max()),
    "checks_passed": int((checks_df["Status"] == "PASS").sum()),
    "checks_review": int((checks_df["Status"] == "REVIEW").sum()),
    "warnings": warnings,
    "important_protocol_note": (
        "This audit checks feature integrity. It does not prove that "
        "the experiment is a multi-step forecast. If test-period lag "
        "features use actual previous test-day targets, describe the "
        "evaluation as rolling one-step-ahead unless a separate "
        "multi-step protocol has been implemented."
    ),
}

with open(
    AUDIT_DIR / "stage77_audit_summary.json",
    "w",
    encoding="utf-8"
) as f:
    json.dump(summary, f, indent=2, ensure_ascii=False)

print("\n" + "=" * 88)
print("STAGE 77 AUDIT FINISHED")
print("=" * 88)
print(json.dumps(summary, indent=2, ensure_ascii=False))
print(f"\nAudit outputs: {AUDIT_DIR}")
print("Existing datasets and Stage76 results were not modified.")
