from pathlib import Path
import pandas as pd
import numpy as np
import shutil
import re
from datetime import datetime

# =============================================================================
# STAGE 49.1
# SUPPLEMENTARY TABLES CORRECTION & RE-AUDIT
#
# Purpose:
#   1. Inspect Table S3 and S6 for NaN values.
#   2. Trace each affected value back to source files.
#   3. Correct ONLY values that can be reconstructed unambiguously.
#   4. Never replace unexplained NaN with zero.
#   5. Preserve a backup of the original supplementary tables.
#   6. Re-audit S1-S10 after correction.
# =============================================================================

ROOT = Path(__file__).resolve().parent

PACKAGE = (
    ROOT
    / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"
    / "05_Supplementary_Material"
)

TABLE_DIR = PACKAGE / "Tables"
BACKUP_DIR = PACKAGE / "Stage49_1_Backup"
AUDIT_DIR = PACKAGE / "Stage49_1_Audit"

BACKUP_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

S3 = TABLE_DIR / "Table_S3_Model_Comparison.csv"
S6 = TABLE_DIR / "Table_S6_Validation_Results.csv"

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

AUDIT_FILE = (
    AUDIT_DIR
    / f"STAGE49_1_CORRECTION_AUDIT_{TIMESTAMP}.csv"
)

REQUIRED_TABLES = [
    f"Table_S{i}_{name}.csv"
    for i, name in [
        (1, "Descriptive_Statistics"),
        (2, "Data_Quality"),
        (3, "Model_Comparison"),
        (4, "Final_Ablation"),
        (5, "Feature_Importance"),
        (6, "Validation_Results"),
        (7, "Experiment_Configuration"),
        (8, "Temporal_Validation"),
        (9, "Prediction_Diagnostics"),
        (10, "Split_Validation"),
    ]
]


# =============================================================================
# UTILITIES
# =============================================================================

def h(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def locate(filename):
    """
    Locate a source file recursively under project root.
    """
    direct = ROOT / filename
    if direct.exists():
        return direct

    hits = list(ROOT.rglob(filename))

    if hits:
        return hits[0]

    return None


def locate_all(filename):
    return list(ROOT.rglob(filename))


def backup_file(path):
    if not path.exists():
        return None

    target = BACKUP_DIR / f"{path.stem}_ORIGINAL_{TIMESTAMP}{path.suffix}"
    shutil.copy2(path, target)
    return target


def load_csv(path):
    if not path or not path.exists():
        return None

    try:
        return pd.read_csv(path)
    except Exception as exc:
        print(f"ERROR loading {path}: {exc}")
        return None


def normalize_name(x):
    """
    Normalize model / experiment names for matching.
    """
    if pd.isna(x):
        return ""

    s = str(x).strip().lower()

    replacements = {
        "–": "-",
        "—": "-",
        "_": " ",
        "  ": " ",
    }

    for a, b in replacements.items():
        s = s.replace(a, b)

    s = re.sub(r"\s+", " ", s)

    return s


def numeric_columns(df):
    return [
        c for c in df.columns
        if pd.api.types.is_numeric_dtype(df[c])
    ]


def nan_report(df, table_name):
    rows = []

    for col in df.columns:
        n = int(df[col].isna().sum())

        if n > 0:
            rows.append({
                "Table": table_name,
                "Column": col,
                "NaN_Count": n
            })

    return rows


def print_dataframe_structure(df, name):
    print(f"\n{name}")
    print("-" * 80)
    print("Shape :", df.shape)
    print("Columns:")
    for c in df.columns:
        print(f"  - {c}")


# =============================================================================
# 1. INITIAL CHECK
# =============================================================================

h("STAGE 49.1 — SUPPLEMENTARY TABLES CORRECTION & RE-AUDIT")

print("Project root :", ROOT)
print("Package      :", PACKAGE)
print("Table dir    :", TABLE_DIR)

if not TABLE_DIR.exists():
    raise FileNotFoundError(
        f"Supplementary table directory not found:\n{TABLE_DIR}"
    )

missing_tables = []

for name in REQUIRED_TABLES:
    p = TABLE_DIR / name

    if p.exists():
        print(f"PASS | {name}")
    else:
        print(f"FAIL | {name}")
        missing_tables.append(name)

if missing_tables:
    raise FileNotFoundError(
        "Required Supplementary Tables are missing:\n"
        + "\n".join(missing_tables)
    )


# =============================================================================
# 2. LOAD S3 AND S6
# =============================================================================

h("1. LOAD PROBLEMATIC TABLES")

df_s3 = load_csv(S3)
df_s6 = load_csv(S6)

if df_s3 is None:
    raise FileNotFoundError(S3)

if df_s6 is None:
    raise FileNotFoundError(S6)

print_dataframe_structure(df_s3, "TABLE S3")
print_dataframe_structure(df_s6, "TABLE S6")


# =============================================================================
# 3. BACKUP ORIGINAL FILES
# =============================================================================

h("2. BACKUP ORIGINAL SUPPLEMENTARY TABLES")

backup_s3 = backup_file(S3)
backup_s6 = backup_file(S6)

print("S3 backup:", backup_s3)
print("S6 backup:", backup_s6)


# =============================================================================
# 4. INITIAL NaN AUDIT
# =============================================================================

h("3. INITIAL NaN AUDIT")

initial_nan_s3 = nan_report(
    df_s3,
    "Table_S3_Model_Comparison.csv"
)

initial_nan_s6 = nan_report(
    df_s6,
    "Table_S6_Validation_Results.csv"
)

print("\nS3 NaN report:")
if initial_nan_s3:
    for row in initial_nan_s3:
        print(row)
else:
    print("NONE")

print("\nS6 NaN report:")
if initial_nan_s6:
    for row in initial_nan_s6:
        print(row)
else:
    print("NONE")

print(
    "\nTotal S3 NaN:",
    int(df_s3.isna().sum().sum())
)

print(
    "Total S6 NaN:",
    int(df_s6.isna().sum().sum())
)


# =============================================================================
# 5. SHOW AFFECTED ROWS
# =============================================================================

h("4. AFFECTED ROWS — S3")

s3_bad = df_s3[df_s3.isna().any(axis=1)].copy()

if s3_bad.empty:
    print("No affected rows.")
else:
    print(s3_bad.to_string(index=True))


h("5. AFFECTED ROWS — S6")

s6_bad = df_s6[df_s6.isna().any(axis=1)].copy()

if s6_bad.empty:
    print("No affected rows.")
else:
    print(s6_bad.to_string(index=True))


# =============================================================================
# 6. SOURCE FILES
# =============================================================================

h("6. SOURCE FILE DISCOVERY")

SOURCE_MAP = {
    "baseline_comparison":
        "baseline_comparison_table.csv",

    "baseline_vs_advanced":
        "baseline_vs_advanced.csv",

    "final_model_results":
        "FINAL_MANUSCRIPT_MODEL_RESULTS.csv",

    "validation_baseline":
        "validation_baseline_results.csv",

    "validation_advanced":
        "advanced_validation_results.csv",
}

sources = {}

for key, filename in SOURCE_MAP.items():

    hits = locate_all(filename)

    if hits:
        # Prefer the first file under the expected project tree.
        sources[key] = hits[0]
        print(f"PASS | {key:25s} | {hits[0]}")
    else:
        sources[key] = None
        print(f"MISS | {key:25s} | {filename}")


# =============================================================================
# 7. LOAD SOURCES
# =============================================================================

h("7. SOURCE DATA INSPECTION")

source_frames = {}

for key, path in sources.items():

    if path is None:
        continue

    df = load_csv(path)

    if df is None:
        continue

    source_frames[key] = df

    print_dataframe_structure(df, key)


# =============================================================================
# 8. SOURCE NaN CHECK
# =============================================================================

h("8. SOURCE NaN CHECK")

for key, df in source_frames.items():

    n = int(df.isna().sum().sum())

    print(
        f"{key:25s} | shape={df.shape} | total_NaN={n}"
    )


# =============================================================================
# 9. GENERIC EXACT VALUE RECOVERY
# =============================================================================

def find_matching_source_row(
    target_row,
    source_df,
    preferred_keys
):
    """
    Find an unambiguous source row.

    Only exact normalized matches are accepted.
    No fuzzy inference is performed.
    """

    if source_df is None or source_df.empty:
        return None

    available = set(source_df.columns)

    usable_keys = [
        k for k in preferred_keys
        if k in available and k in target_row.index
    ]

    if not usable_keys:
        return None

    mask = pd.Series(True, index=source_df.index)

    for key in usable_keys:

        target_value = target_row[key]

        if pd.isna(target_value):
            continue

        target_norm = normalize_name(target_value)

        mask = mask & (
            source_df[key]
            .astype(str)
            .map(normalize_name)
            == target_norm
        )

    matches = source_df.loc[mask]

    if len(matches) == 1:
        return matches.iloc[0]

    return None


# =============================================================================
# 10. S3 CORRECTION
# =============================================================================

h("9. TABLE S3 — SOURCE-BASED CORRECTION")

s3_changes = []

# Candidate key columns.
S3_KEYS = [
    "Model",
    "Model_Name",
    "Experiment",
    "Experiment_Name",
    "Method",
    "Method_Name",
    "Configuration",
]

# Build source pool.
s3_sources = [
    source_frames.get("baseline_comparison"),
    source_frames.get("baseline_vs_advanced"),
    source_frames.get("final_model_results"),
]

s3_sources = [
    x for x in s3_sources
    if x is not None
]


for idx in df_s3.index:

    row = df_s3.loc[idx]

    missing_cols = [
        c for c in df_s3.columns
        if pd.isna(row[c])
    ]

    if not missing_cols:
        continue

    print(f"\nS3 row {idx} has missing columns:")
    print(missing_cols)

    for source_df in s3_sources:

        source_row = find_matching_source_row(
            row,
            source_df,
            S3_KEYS
        )

        if source_row is None:
            continue

        for col in missing_cols:

            # Exact same column.
            if col in source_row.index:
                value = source_row[col]

                if not pd.isna(value):

                    old_value = df_s3.at[idx, col]

                    df_s3.at[idx, col] = value

                    s3_changes.append({
                        "Table": "S3",
                        "Row": idx,
                        "Column": col,
                        "Old_Value": old_value,
                        "New_Value": value,
                        "Source": "exact-column-source-match",
                    })

                    print(
                        f"CORRECTED | row={idx} | "
                        f"{col} | {old_value} -> {value}"
                    )

        # Stop after a successful source match.
        break


# =============================================================================
# 11. S6 CORRECTION
# =============================================================================

h("10. TABLE S6 — SOURCE-BASED CORRECTION")

s6_changes = []

S6_KEYS = [
    "Model",
    "Model_Name",
    "Experiment",
    "Experiment_Name",
    "Method",
    "Method_Name",
    "Configuration",
    "Metric",
]

s6_sources = [
    source_frames.get("validation_baseline"),
    source_frames.get("validation_advanced"),
]

s6_sources = [
    x for x in s6_sources
    if x is not None
]


for idx in df_s6.index:

    row = df_s6.loc[idx]

    missing_cols = [
        c for c in df_s6.columns
        if pd.isna(row[c])
    ]

    if not missing_cols:
        continue

    print(f"\nS6 row {idx} has missing columns:")
    print(missing_cols)

    for source_df in s6_sources:

        source_row = find_matching_source_row(
            row,
            source_df,
            S6_KEYS
        )

        if source_row is None:
            continue

        for col in missing_cols:

            if col in source_row.index:

                value = source_row[col]

                if not pd.isna(value):

                    old_value = df_s6.at[idx, col]

                    df_s6.at[idx, col] = value

                    s6_changes.append({
                        "Table": "S6",
                        "Row": idx,
                        "Column": col,
                        "Old_Value": old_value,
                        "New_Value": value,
                        "Source": "exact-column-source-match",
                    })

                    print(
                        f"CORRECTED | row={idx} | "
                        f"{col} | {old_value} -> {value}"
                    )

        break


# =============================================================================
# 12. DO NOT INVENT VALUES
# =============================================================================

h("11. UNRESOLVED NaN CHECK")

remaining_s3 = df_s3[df_s3.isna().any(axis=1)]
remaining_s6 = df_s6[df_s6.isna().any(axis=1)]

print(
    "Remaining S3 NaN:",
    int(df_s3.isna().sum().sum())
)

print(
    "Remaining S6 NaN:",
    int(df_s6.isna().sum().sum())
)

if not remaining_s3.empty:
    print("\nUNRESOLVED S3:")
    print(remaining_s3.to_string(index=True))

if not remaining_s6.empty:
    print("\nUNRESOLVED S6:")
    print(remaining_s6.to_string(index=True))


# =============================================================================
# 13. SAVE ONLY IF CORRECTIONS WERE MADE
# =============================================================================

h("12. SAVE CORRECTED TABLES")

if s3_changes:
    df_s3.to_csv(S3, index=False)
    print(f"SAVED | {S3}")
else:
    print("NO S3 changes.")

if s6_changes:
    df_s6.to_csv(S6, index=False)
    print(f"SAVED | {S6}")
else:
    print("NO S6 changes.")


# =============================================================================
# 14. STRUCTURAL RE-AUDIT
# =============================================================================

h("13. STRUCTURAL RE-AUDIT")

expected_shapes = {
    "Table_S1_Descriptive_Statistics.csv": (4, 6),
    "Table_S2_Data_Quality.csv": (30, 3),
    "Table_S3_Model_Comparison.csv": (10, 11),
    "Table_S4_Final_Ablation.csv": (7, 11),
    "Table_S5_Feature_Importance.csv": (10, 4),
    "Table_S6_Validation_Results.csv": (10, 10),
    "Table_S7_Experiment_Configuration.csv": (52, 5),
    "Table_S8_Temporal_Validation.csv": (8, 4),
    "Table_S9_Prediction_Diagnostics.csv": (21, 4),
    "Table_S10_Split_Validation.csv": (3, 4),
}

audit_rows = []

for filename, expected in expected_shapes.items():

    path = TABLE_DIR / filename
    df = pd.read_csv(path)

    actual = df.shape

    status = "PASS" if actual == expected else "FAIL"

    print(
        f"{status} | {filename:45s} | "
        f"expected={expected} | actual={actual}"
    )

    audit_rows.append({
        "Section": "Structure",
        "Table": filename,
        "Check": "shape",
        "Expected": str(expected),
        "Actual": str(actual),
        "Status": status,
    })


# =============================================================================
# 15. NUMERIC NaN / INF AUDIT
# =============================================================================

h("14. NUMERIC SANITY RE-AUDIT")

for filename in expected_shapes:

    path = TABLE_DIR / filename
    df = pd.read_csv(path)

    nums = numeric_columns(df)

    nan_count = int(df[nums].isna().sum().sum()) if nums else 0

    inf_count = 0

    if nums:
        values = df[nums].to_numpy(dtype=float)

        inf_count = int(
            np.isinf(values).sum()
        )

    status = (
        "PASS"
        if nan_count == 0 and inf_count == 0
        else "FAIL"
    )

    print(
        f"{status} | {filename:45s} | "
        f"numeric_columns={len(nums)}; "
        f"NaN={nan_count}; Inf={inf_count}"
    )

    audit_rows.append({
        "Section": "Numeric sanity",
        "Table": filename,
        "Check": "NaN_Inf",
        "Expected": "NaN=0; Inf=0",
        "Actual": f"NaN={nan_count}; Inf={inf_count}",
        "Status": status,
    })


# =============================================================================
# 16. DUPLICATE AUDIT
# =============================================================================

h("15. DUPLICATE RE-AUDIT")

for filename in expected_shapes:

    path = TABLE_DIR / filename
    df = pd.read_csv(path)

    duplicates = int(df.duplicated().sum())

    status = (
        "PASS"
        if duplicates == 0
        else "FAIL"
    )

    print(
        f"{status} | {filename:45s} | "
        f"duplicate_rows={duplicates}"
    )

    audit_rows.append({
        "Section": "Duplicate",
        "Table": filename,
        "Check": "duplicate_rows",
        "Expected": "0",
        "Actual": duplicates,
        "Status": status,
    })


# =============================================================================
# 17. SOURCE CORRECTION LOG
# =============================================================================

h("16. CORRECTION LOG")

all_changes = s3_changes + s6_changes

if all_changes:

    for change in all_changes:
        print(
            f"{change['Table']} | "
            f"row={change['Row']} | "
            f"{change['Column']} | "
            f"{change['Old_Value']} -> "
            f"{change['New_Value']} | "
            f"{change['Source']}"
        )

else:
    print("No values were changed.")


# =============================================================================
# 18. SAVE AUDIT
# =============================================================================

audit_df = pd.DataFrame(audit_rows)

if all_changes:

    correction_df = pd.DataFrame(all_changes)

    correction_df.insert(
        0,
        "Audit_Type",
        "Correction"
    )

    audit_export = pd.concat(
        [
            audit_df.assign(Audit_Type="Re-Audit"),
            correction_df,
        ],
        ignore_index=True,
        sort=False
    )

else:

    audit_export = audit_df.assign(
        Audit_Type="Re-Audit"
    )

audit_export.to_csv(
    AUDIT_FILE,
    index=False
)

print("\nAudit saved:")
print(AUDIT_FILE)


# =============================================================================
# 19. FINAL STATUS
# =============================================================================

h("STAGE 49.1 FINAL STATUS")

final_s3_nan = int(
    pd.read_csv(S3).isna().sum().sum()
)

final_s6_nan = int(
    pd.read_csv(S6).isna().sum().sum()
)

failed_checks = [
    x
    for x in audit_rows
    if x["Status"] == "FAIL"
]

print("Corrections applied :", len(all_changes))
print("Final S3 NaN        :", final_s3_nan)
print("Final S6 NaN        :", final_s6_nan)
print("Failed re-audit     :", len(failed_checks))

if final_s3_nan == 0 and final_s6_nan == 0 and not failed_checks:

    print("\nSTAGE 49.1 — PASS")
    print(
        "Supplementary Tables S1-S10 passed the "
        "correction and numerical re-audit."
    )

else:

    print("\nSTAGE 49.1 — REVIEW REQUIRED")

    if final_s3_nan > 0:
        print(
            f"WARNING: Table S3 still contains "
            f"{final_s3_nan} NaN value(s)."
        )

    if final_s6_nan > 0:
        print(
            f"WARNING: Table S6 still contains "
            f"{final_s6_nan} NaN value(s)."
        )

    if failed_checks:
        print(
            f"WARNING: {len(failed_checks)} "
            "re-audit check(s) failed."
        )

    print(
        "\nNo unresolved value was replaced with zero "
        "or otherwise invented."
    )

print("=" * 100)