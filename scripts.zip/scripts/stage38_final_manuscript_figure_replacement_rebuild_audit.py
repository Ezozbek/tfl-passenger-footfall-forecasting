# -*- coding: utf-8 -*-
"""Stage 38: replace Figures 1-4 in the final DOCX, rebuild PDF, audit, ZIP."""
from pathlib import Path
import shutil, subprocess, sys, re, zipfile, csv
from docx import Document
from docx.shared import Inches

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'STAGE36_FINAL_Q1_SUBMISSION_PACKAGE'
DOCX = PACKAGE / '01_Final_Manuscript.docx'
FIGDIR = PACKAGE / '03_High_Resolution_Figures'
BACKUP = PACKAGE / '_Stage38_Backup'
ZIPOUT = ROOT / 'FINAL_Q1_SUBMISSION_PACKAGE_STAGE38.zip'
MANIFEST = PACKAGE / 'STAGE38_FINAL_PACKAGE_MANIFEST.csv'
AUDIT = PACKAGE / 'STAGE38_FINAL_AUDIT.txt'

FIGURES = {
    1: FIGDIR / 'Figure_1_Feature_Importance.png',
    2: FIGDIR / 'Figure_2_Actual_vs_Predicted.png',
    3: FIGDIR / 'Figure_3_Residual_Diagnostics.png',
    4: FIGDIR / 'Figure_4_Model_Comparison.png',
}
LEGACY = ['61.998', '61.998%', '-5.48', 'mean bias = -5.48']
REQUIRED = ['1,400.3845','4,036.1222','0.980447','0.990215','1,490.7452','4,087.0080','0.979950','0.989932','20.0042%','19.7594%','16.0978%']


def h(s):
    print('='*100); print(s); print('='*100)

def fail(s):
    print('\n'+'='*100); print('STAGE 38 — FAIL'); print('='*100); print(s); sys.exit(1)

def norm(s): return re.sub(r'\s+', ' ', s.strip().lower())

def check_inputs():
    h('1. INPUT VALIDATION')
    if not PACKAGE.exists(): fail(f'Package not found: {PACKAGE}')
    if not DOCX.exists(): fail(f'DOCX not found: {DOCX}')
    for p in FIGURES.values():
        if not p.exists(): fail(f'Missing figure: {p}')
        if p.stat().st_size < 1000: fail(f'Suspiciously small figure: {p}')
        print(f'PASS | {p.name} | {p.stat().st_size/1024:.1f} KB')

def backup():
    h('2. BACKUP CURRENT MANUSCRIPT')
    BACKUP.mkdir(exist_ok=True)
    out = BACKUP/'01_Final_Manuscript_STAGE36_BACKUP.docx'
    shutil.copy2(DOCX, out); print(f'Backup: {out}')

def paragraph_has_drawing(p):
    return bool(p._p.xpath('.//w:drawing'))

def replace_image_blob_in_paragraph(p, new_image):
    """Replace image bytes for the first image relationship in paragraph, preserving size/layout."""
    drawings = p._p.xpath('.//w:drawing')
    if not drawings: return False
    blips = drawings[0].xpath('.//a:blip')
    if not blips: return False
    rid = blips[0].get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
    if not rid: return False
    rel = p.part.rels[rid]
    if not hasattr(rel, 'target_part'): return False
    target = rel.target_part
    if not hasattr(target, '_blob'): return False
    target._blob = new_image.read_bytes()
    return True

def find_caption(paragraphs, n):
    pats = [f'figure {n}', f'fig. {n}', f'fig {n}']
    for i,p in enumerate(paragraphs):
        t=norm(p.text)
        if any(t.startswith(x) for x in pats): return i
    return None

def replace_figures():
    h('3. FINAL MANUSCRIPT FIGURE REPLACEMENT')
    doc=Document(DOCX); paragraphs=list(doc.paragraphs); done={}
    for n,img in FIGURES.items():
        idx=find_caption(paragraphs,n)
        if idx is None:
            fail(f'Figure {n} caption was not found in DOCX top-level paragraphs.')
        candidates=[]
        for j in range(max(0,idx-4), idx):
            if paragraph_has_drawing(paragraphs[j]): candidates.append(paragraphs[j])
        if candidates:
            target=candidates[-1]
            if not replace_image_blob_in_paragraph(target,img):
                fail(f'Could not replace image blob for Figure {n}.')
            done[n]='existing embedded image replaced'
        else:
            # Insert a new paragraph immediately before caption as a fallback.
            cap=paragraphs[idx]
            newp=cap.insert_paragraph_before()
            newp.alignment=1
            newp.add_run().add_picture(str(img), width=Inches(6.4))
            done[n]='new image inserted before caption'
    doc.save(DOCX)
    for n in range(1,5): print(f'Figure {n}: {done.get(n)}')

def count_images():
    h('4. DOCX IMAGE VALIDATION')
    doc=Document(DOCX)
    count=sum(1 for p in doc.paragraphs if paragraph_has_drawing(p))
    # Include table paragraphs too.
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                count += sum(1 for p in cell.paragraphs if paragraph_has_drawing(p))
    print(f'Paragraphs containing drawings: {count}')
    if count < 4: fail('Fewer than four figure-bearing paragraphs found in DOCX.')

def soffice():
    for x in [shutil.which('soffice'), shutil.which('libreoffice'), r'C:\Program Files\LibreOffice\program\soffice.exe', r'C:\Program Files (x86)\LibreOffice\program\soffice.exe']:
        if x and Path(x).exists(): return x
    return None

def docx_text():
    doc=Document(DOCX); chunks=[]
    chunks += [p.text for p in doc.paragraphs if p.text.strip()]
    for t in doc.tables:
        for row in t.rows:
            chunks.append(' | '.join(c.text for c in row.cells))
    return '\n'.join(chunks)

def audit_docx():
    h('6. FINAL DOCX TEXT AUDIT')
    text=docx_text().lower()
    bad=[x for x in LEGACY if x.lower() in text]
    if bad: fail('Legacy values found in DOCX: '+', '.join(bad))
    missing=[x for x in REQUIRED if x.lower() not in text]
    if missing: fail('Required verified values missing from DOCX: '+', '.join(missing))
    for n in range(1,5):
        if not re.search(rf'\bfigure\s*{n}\b',text): fail(f'Figure {n} reference missing from DOCX.')
    print('Legacy values: NONE'); print('Verified values: PASS'); print('Figure 1-4 references: PASS')

def audit_figures():
    h('8. FINAL FIGURE AUDIT')
    for n,p in FIGURES.items():
        for q in [p, p.with_suffix('.pdf')]:
            if not q.exists() or q.stat().st_size<1000: fail(f'Missing/small figure file: {q}')
            print(f'PASS | {q.name} | {q.stat().st_size/1024:.1f} KB')

def manifest():
    h('9. PACKAGE MANIFEST')
    files=[]
    for p in PACKAGE.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(PACKAGE)
        if str(rel).startswith('_Stage38_Backup') or str(rel).startswith('_stage38_pdf_build'): continue
        files.append(rel)
    with MANIFEST.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['relative_path','size_bytes','size_kb'])
        for rel in sorted(files):
            s=(PACKAGE/rel).stat().st_size; w.writerow([str(rel),s,round(s/1024,2)])
    required=['01_Final_Manuscript.docx']+[f'03_High_Resolution_Figures/{p.name}' for p in FIGURES.values()]+['05_Supplementary_Material/Figure_2_3_Paired_Test_Predictions.csv']
    missing=[x for x in required if not (PACKAGE/x).exists()]
    if missing: fail('Required package files missing:\n'+'\n'.join(missing))
    print(f'Package files: {len(files)}'); print('Required package content: PASS')

def zip_package():
    h('10. FINAL ZIP')
    if ZIPOUT.exists(): ZIPOUT.unlink()
    with zipfile.ZipFile(ZIPOUT,'w',zipfile.ZIP_DEFLATED) as z:
        for p in PACKAGE.rglob('*'):
            if not p.is_file(): continue
            rel=p.relative_to(PACKAGE)
            if str(rel).startswith('_Stage38_Backup') or str(rel).startswith('_stage38_pdf_build'): continue
            z.write(p,arcname=str(rel))
    with zipfile.ZipFile(ZIPOUT) as z:
        if z.testzip() is not None: fail('ZIP integrity failure.')
    print(f'ZIP: {ZIPOUT}'); print(f'Size: {ZIPOUT.stat().st_size/1024/1024:.2f} MB'); print('ZIP integrity: PASS')

def final_report():
    report='''STAGE 38 — FINAL SUBMISSION AUDIT\nSTATUS: PASS\n\nFigure replacement: PASS\nDOCX rebuild: PASS\nPDF rebuild: PASS\nDOCX legacy-value audit: PASS\nDOCX verified-value audit: PASS\nPDF legacy-value audit: PASS\nPDF verified-value audit: PASS\nFigure 1-4 audit: PASS\nPackage content audit: PASS\nZIP integrity: PASS\n'''
    AUDIT.write_text(report,encoding='utf-8')
    h('11. STAGE 38 FINAL STATUS')
    print(report)
    print(f'Final DOCX: {DOCX}')
    print(f'Final PDF : {PDF}')
    print(f'Final ZIP : {ZIPOUT}')
    print('\nSTAGE 38 — PASS')
    print('\nNext stage: Stage 39 → Final ZIP Content Inspection + Submission Readiness Check.')

def main():
    h('STAGE 38 — FINAL MANUSCRIPT FIGURE REPLACEMENT + DOCX/PDF REBUILD + FINAL SUBMISSION AUDIT')
    check_inputs(); backup(); replace_figures(); count_images(); rebuild_pdf(); audit_docx(); audit_pdf(); audit_figures(); manifest(); zip_package(); final_report()

if __name__=='__main__': main()
