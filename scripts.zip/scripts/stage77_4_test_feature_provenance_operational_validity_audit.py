
from pathlib import Path
import json
import traceback

import numpy as np
import pandas as pd


# ============================================================
# STAGE 77.4 — TEST FEATURE PROVENANCE & OPERATIONAL VALIDITY
# Read-only audit: does not modify existing project artifacts.
# ============================================================

ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects"
    r"\PythonProject5_Transport_Scheduling"
)

DATA_DIR = ROOT / "tfl_calendar_ml"
MASTER_FILE = (
    ROOT / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)
OUT_DIR = ROOT / "tfl_stage77_audit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

REPORT_CSV = OUT_DIR / "stage77_4_provenance_findings.csv"
SUMMARY_TXT = OUT_DIR / "stage77_4_provenance_summary.txt"
DETAILS_TXT = OUT_DIR / "stage77_4_feature_provenance_details.txt"
JSON_REPORT = OUT_DIR / "stage77_4_operational_validity.json"

DATE = "TravelDate"
STATION = "Station"
TARGET = "TotalFootfall"

LAGS = {
    "Lag_1": 1,
    "Lag_7": 7,
    "Lag_14": 14,
    "Lag_28": 28,
}

ROLLING = {
    "RollingMean_7": ("mean", "7D"),
    "RollingStd_7": ("std", "7D"),
    "RollingMean_14": ("mean", "14D"),
    "RollingMean_28": ("mean", "28D"),
}

SPLIT_FILES = {
    "train": DATA_DIR / "train_2023.csv",
    "validation": DATA_DIR / "validation_2024.csv",
    "test": DATA_DIR / "test_2025_2026.csv",
}

findings = []
details = []
summary = {
    "stage": "77.4",
    "title": "Test Feature Provenance & Operational Validity Audit",
    "status": "IN_PROGRESS",
    "checks": {},
}


def record(check, status, evidence, severity="INFO"):
    findings.append({
        "Check": check,
        "Status": status,
        "Severity": severity,
        "Evidence": str(evidence),
    })


def log(message=""):
    details.append(str(message))
    print(message)


def normalize(df, name):
    df = df.copy()

    required = [DATE, STATION, TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"{name}: required columns missing: {missing}"
        )

    df[DATE] = pd.to_datetime(df[DATE], errors="coerce").dt.normalize()
    df[STATION] = df[STATION].astype("string").str.strip()
    df[TARGET] = pd.to_numeric(df[TARGET], errors="coerce")

    return df


def compare_numeric(actual, expected, atol=1e-7, rtol=1e-9):
    actual = pd.to_numeric(actual, errors="coerce").to_numpy(dtype=float)
    expected = pd.to_numeric(expected, errors="coerce").to_numpy(dtype=float)

    both_nan = np.isnan(actual) & np.isnan(expected)
    both_finite = np.isfinite(actual) & np.isfinite(expected)

    equal = both_nan.copy()
    equal[both_finite] = np.isclose(
        actual[both_finite],
        expected[both_finite],
        atol=atol,
        rtol=rtol,
    )
    return equal, actual, expected


def main():
    log("=" * 78)
    log("STAGE 77.4 — TEST FEATURE PROVENANCE & OPERATIONAL VALIDITY")
    log("=" * 78)

    # --------------------------------------------------------
    # 1. Load source data and split files
    # --------------------------------------------------------
    if not MASTER_FILE.exists():
        raise FileNotFoundError(f"Master dataset not found: {MASTER_FILE}")

    for name, path in SPLIT_FILES.items():
        if not path.exists():
            raise FileNotFoundError(f"{name} split not found: {path}")

    master = pd.read_csv(MASTER_FILE, low_memory=False)
    master = normalize(master, "master")

    splits = {}
    for name, path in SPLIT_FILES.items():
        df = pd.read_csv(path, low_memory=False)
        df = normalize(df, name)
        splits[name] = df

    log(f"Master rows: {len(master):,}")
    for name, df in splits.items():
        log(
            f"{name}: rows={len(df):,}, "
            f"dates={df[DATE].min()} to {df[DATE].max()}, "
            f"stations={df[STATION].nunique():,}"
        )

    # --------------------------------------------------------
    # 2. Validate keys and master-source uniqueness
    # --------------------------------------------------------
    master_key_duplicates = int(
        master.duplicated([STATION, DATE]).sum()
    )
    record(
        "Master Station-Date uniqueness",
        "PASS" if master_key_duplicates == 0 else "FAIL",
        f"duplicate keys={master_key_duplicates}",
        "ERROR" if master_key_duplicates else "INFO",
    )

    if master_key_duplicates:
        raise ValueError(
            "Master has duplicate Station-Date keys. "
            "Cannot safely audit feature provenance."
        )

    master_invalid = int(
        master[[STATION, DATE, TARGET]].isna().any(axis=1).sum()
    )
    record(
        "Master key/target validity",
        "PASS" if master_invalid == 0 else "REVIEW",
        f"rows with null station/date/target={master_invalid}",
        "WARNING" if master_invalid else "INFO",
    )

    master = master.dropna(subset=[STATION, DATE, TARGET]).copy()
    master = master.sort_values([STATION, DATE]).reset_index(drop=True)

    # Map each observed source target by station and date.
    target_lookup = {
        (station, date): value
        for station, date, value in zip(
            master[STATION], master[DATE], master[TARGET]
        )
    }

    # --------------------------------------------------------
    # 3. Verify split rows exist in master and actual targets match
    # --------------------------------------------------------
    split_station_sets = {}

    for name, df in splits.items():
        split_station_sets[name] = set(df[STATION].dropna().unique())

        source_values = np.array([
            target_lookup.get((station, date), np.nan)
            for station, date in zip(df[STATION], df[DATE])
        ], dtype=float)

        actual_values = df[TARGET].to_numpy(dtype=float)
        matched = np.isfinite(source_values)

        target_equal = np.zeros(len(df), dtype=bool)
        target_equal[matched] = np.isclose(
            actual_values[matched],
            source_values[matched],
            atol=1e-7,
            rtol=1e-9,
        )

        mismatch_count = int((matched & ~target_equal).sum())
        unmatched_count = int((~matched).sum())

        record(
            f"{name}: row-to-master target alignment",
            "PASS" if mismatch_count == 0 and unmatched_count == 0 else "FAIL",
            f"unmatched rows={unmatched_count}; "
            f"target mismatches={mismatch_count}",
            "ERROR" if mismatch_count or unmatched_count else "INFO",
        )

    # --------------------------------------------------------
    # 4. Station coverage audit
    # --------------------------------------------------------
    train_val_stations = (
        split_station_sets["train"] | split_station_sets["validation"]
    )
    test_stations = split_station_sets["test"]

    unseen_test_stations = sorted(test_stations - train_val_stations)
    absent_test_stations = sorted(train_val_stations - test_stations)

    log(f"Test stations unseen in train/validation: {len(unseen_test_stations)}")
    log(f"Train/validation stations absent from test: {len(absent_test_stations)}")

    record(
        "Test station coverage",
        "PASS" if not unseen_test_stations else "REVIEW",
        f"test stations={len(test_stations)}; "
        f"unseen test stations={len(unseen_test_stations)}; "
        f"unseen names={unseen_test_stations[:30]}",
        "WARNING" if unseen_test_stations else "INFO",
    )

    # --------------------------------------------------------
    # 5. Build independent, date-aligned lag expectations
    # --------------------------------------------------------
    test = splits["test"].copy()

    for feature, lag_days in LAGS.items():
        if feature not in test.columns:
            record(
                f"{feature} source provenance",
                "REVIEW",
                "Feature column absent from test split",
                "WARNING",
            )
            continue

        source_dates = test[DATE] - pd.to_timedelta(lag_days, unit="D")
        expected = np.array([
            target_lookup.get((station, source_date), np.nan)
            for station, source_date in zip(test[STATION], source_dates)
        ], dtype=float)

        observed = pd.to_numeric(
            test[feature], errors="coerce"
        ).to_numpy(dtype=float)

        both_missing = np.isnan(observed) & np.isnan(expected)
        both_present = np.isfinite(observed) & np.isfinite(expected)

        equal = both_missing.copy()
        equal[both_present] = np.isclose(
            observed[both_present],
            expected[both_present],
            atol=1e-7,
            rtol=1e-9,
        )

        unmatched_source = int((~np.isfinite(expected)).sum())
        mismatches = int((~equal).sum())

        # Count lags whose source date lies in the held-out test interval.
        test_start = test[DATE].min()
        test_end = test[DATE].max()
        source_in_test_period = (
            (source_dates >= test_start) & (source_dates <= test_end)
        )
        source_in_test = int(
            (source_in_test_period & np.isfinite(expected)).sum()
        )

        record(
            f"{feature} source provenance",
            "PASS" if mismatches == 0 and unmatched_source == 0 else "REVIEW",
            f"rows={len(test)}; mismatches={mismatches}; "
            f"missing source targets={unmatched_source}; "
            f"source dates inside test period={source_in_test}",
            "WARNING" if mismatches or unmatched_source else "INFO",
        )

        log(
            f"{feature}: mismatches={mismatches:,}; "
            f"missing source targets={unmatched_source:,}; "
            f"prior test-period source rows={source_in_test:,}"
        )

    # --------------------------------------------------------
    # 6. Reconstruct rolling features from historical targets
    #    Only observations strictly before the forecast date are used.
    # --------------------------------------------------------
    master_by_station = {
        station: group.sort_values(DATE).set_index(DATE)[TARGET]
        for station, group in master.groupby(STATION, sort=False)
    }

    expected_rolling = {}

    for station, source_series in master_by_station.items():
        # A date index with no duplicate dates is required per station.
        for feature, (operation, window) in ROLLING.items():
            try:
                rolling = source_series.rolling(
                    window=window,
                    closed="left",
                    min_periods=1,
                )
                if operation == "mean":
                    result = rolling.mean()
                else:
                    # pandas sample standard deviation (ddof=1)
                    result = rolling.std(ddof=1)

                for date, value in result.items():
                    expected_rolling[(station, date, feature)] = value

            except Exception as exc:
                log(f"Rolling reconstruction warning for {station}/{feature}: {exc}")

    for feature in ROLLING:
        if feature not in test.columns:
            record(
                f"{feature} historical provenance",
                "REVIEW",
                "Feature column absent from test split",
                "WARNING",
            )
            continue

        expected = np.array([
            expected_rolling.get((station, date, feature), np.nan)
            for station, date in zip(test[STATION], test[DATE])
        ], dtype=float)

        observed = pd.to_numeric(
            test[feature], errors="coerce"
        ).to_numpy(dtype=float)

        both_missing = np.isnan(observed) & np.isnan(expected)
        both_present = np.isfinite(observed) & np.isfinite(expected)

        equal = both_missing.copy()
        equal[both_present] = np.isclose(
            observed[both_present],
            expected[both_present],
            atol=1e-6,
            rtol=1e-8,
        )

        mismatches = int((~equal).sum())
        missing_expected = int((~np.isfinite(expected)).sum())

        record(
            f"{feature} historical provenance",
            "PASS" if mismatches == 0 else "REVIEW",
            f"mismatches={mismatches}; "
            f"rows without reconstructed value={missing_expected}; "
            "window is calendar-time based and excludes current date",
            "WARNING" if mismatches else "INFO",
        )

        log(
            f"{feature}: mismatches={mismatches:,}; "
            f"unreconstructed={missing_expected:,}"
        )

    # --------------------------------------------------------
    # 7. Classify operational interpretation
    # --------------------------------------------------------
    log("")
    log("OPERATIONAL INTERPRETATION")
    log("-" * 78)

    test_start = test[DATE].min()
    test_end = test[DATE].max()

    lag_source_counts = {}
    for feature, lag_days in LAGS.items():
        source_dates = test[DATE] - pd.to_timedelta(lag_days, unit="D")
        inside = (source_dates >= test_start) & (source_dates <= test_end)
        available = np.array([
            (station, source_date) in target_lookup
            for station, source_date in zip(test[STATION], source_dates)
        ])
        count = int((inside & available).sum())
        lag_source_counts[feature] = count

    log(f"Test period: {test_start.date()} through {test_end.date()}")
    log("The lag features can incorporate actual observations from earlier test dates.")
    log("That is compatible with rolling one-step-ahead forecasting only when")
    log("those earlier actuals would be available before each later prediction.")
    log("It does NOT establish a fixed-origin multi-step forecasting protocol.")

    record(
        "Forecast protocol classification",
        "REVIEW",
        "Existing source evidence indicates vectorized test prediction with "
        "precomputed lags. Feature availability alone cannot establish when "
        "each forecast was issued or whether earlier actuals were operationally "
        "available. Describe as rolling one-step-ahead only if this assumption "
        "is explicitly supported; otherwise report the protocol as unresolved.",
        "WARNING",
    )

    record(
        "Fixed-origin multi-step validity",
        "REVIEW",
        "Not demonstrated. A fixed-origin evaluation must not use actual "
        "observations from dates after the forecast origin in lag/rolling features.",
        "WARNING",
    )

    record(
        "Rolling one-step-ahead validity",
        "REVIEW",
        "Potentially valid if the forecast is issued after the required historical "
        "actuals become available and the evaluation simulates that update cadence.",
        "WARNING",
    )

    # --------------------------------------------------------
    # 8. Summary and outputs
    # --------------------------------------------------------
    findings_df = pd.DataFrame(findings)
    findings_df.to_csv(REPORT_CSV, index=False, encoding="utf-8-sig")

    pass_count = int((findings_df["Status"] == "PASS").sum())
    review_count = int((findings_df["Status"] == "REVIEW").sum())
    fail_count = int((findings_df["Status"] == "FAIL").sum())

    summary.update({
        "status": "COMPLETED_WITH_REVIEW" if review_count else (
            "COMPLETED_WITH_FAILURES" if fail_count else "PASS"
        ),
        "master_file": str(MASTER_FILE),
        "split_files": {k: str(v) for k, v in SPLIT_FILES.items()},
        "test_date_start": str(test_start.date()),
        "test_date_end": str(test_end.date()),
        "test_rows": int(len(test)),
        "test_stations": int(test[STATION].nunique()),
        "unseen_test_stations": unseen_test_stations,
        "unseen_test_station_count": int(len(unseen_test_stations)),
        "lag_source_rows_inside_test_period": lag_source_counts,
        "checks": {
            "PASS": pass_count,
            "REVIEW": review_count,
            "FAIL": fail_count,
        },
        "interpretation": {
            "rolling_one_step_ahead": "Conditionally valid; operational timing must be justified.",
            "fixed_origin_multi_step": "Not demonstrated by current evidence.",
            "test_actuals_in_lags": "Not automatically leakage; validity depends on forecast protocol.",
        },
        "outputs": {
            "findings_csv": str(REPORT_CSV),
            "summary_txt": str(SUMMARY_TXT),
            "details_txt": str(DETAILS_TXT),
            "json": str(JSON_REPORT),
        },
    })

    with open(JSON_REPORT, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False, default=str)

    summary_lines = [
        "STAGE 77.4 — TEST FEATURE PROVENANCE & OPERATIONAL VALIDITY AUDIT",
        "=" * 78,
        f"Status: {summary['status']}",
        f"PASS: {pass_count}",
        f"REVIEW: {review_count}",
        f"FAIL: {fail_count}",
        f"Test rows: {len(test):,}",
        f"Test dates: {test_start.date()} to {test_end.date()}",
        f"Test stations: {test[STATION].nunique():,}",
        f"Unseen test stations: {len(unseen_test_stations)}",
        "",
        "MAIN CONCLUSION",
        "Feature alignment can be checked against historical targets, but it does",
        "not by itself prove operational forecast validity. Actual targets from",
        "earlier dates within the test period are compatible with a rolling",
        "one-step-ahead setup only if they are available before subsequent forecasts.",
        "The current evidence does not establish fixed-origin multi-step validity.",
        "",
        "FILES",
        str(REPORT_CSV),
        str(DETAILS_TXT),
        str(JSON_REPORT),
    ]

    SUMMARY_TXT.write_text(
        "\n".join(summary_lines) + "\n",
        encoding="utf-8",
    )

    DETAILS_TXT.write_text(
        "\n".join(details) + "\n\n"
        + findings_df.to_string(index=False),
        encoding="utf-8",
    )

    log("")
    log("=" * 78)
    log("STAGE 77.4 COMPLETE")
    log(f"PASS={pass_count} | REVIEW={review_count} | FAIL={fail_count}")
    log(f"Findings: {REPORT_CSV}")
    log(f"Summary:  {SUMMARY_TXT}")
    log(f"Details:  {DETAILS_TXT}")
    log(f"JSON:     {JSON_REPORT}")
    log("=" * 78)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        error_path = (
            ROOT / "tfl_stage77_audit"
            / "stage77_4_execution_error.txt"
        )
        error_path.parent.mkdir(parents=True, exist_ok=True)
        error_path.write_text(
            f"ERROR: {exc}\n\n{traceback.format_exc()}",
            encoding="utf-8",
        )
        print(f"\nAUDIT FAILED: {exc}")
        print(f"Diagnostic log: {error_path}")
        raise
