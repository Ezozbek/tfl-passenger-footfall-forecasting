from pathlib import Path
import pandas as pd
import numpy as np
import re
import json

# ============================================================
# STAGE 35 — FINAL Q1 MANUSCRIPT CONSISTENCY AUDIT
# ============================================================

ROOT = Path(__file__).resolve().parent

BASE = ROOT / "tfl_baseline_results"
ADV = ROOT / "tfl_advanced_results"
ABL = ROOT / "tfl_ablation_results_v3"
SCI = ROOT / "scientific_validation_results"
FIG = ROOT / "figures"

OUT = SCI / "stage35_audit"
OUT.mkdir(parents=True, exist_ok=True)

print("=" * 100)
print("STAGE 35 — FINAL Q1 MANUSCRIPT CONSISTENCY AUDIT")
print("=" * 100)
print(f"Project root: {ROOT}")
print(f"Audit output: {OUT}")

# ============================================================
# 1. FINAL SOURCE-OF-TRUTH VALUES
# ============================================================

EXPECTED = {
    "initial_rows": 549122,
    "initial_stations": 437,
    "final_ml_rows": 516819,
    "final_ml_stations": 434,

    "train_rows": 140157,
    "validation_rows": 151509,
    "test_rows": 225153,

    "features": 17,

    "extratrees_mae": 1400.3844781891,
    "extratrees_rmse": 4036.1221687711,
    "extratrees_r2": 0.9804465419,
    "extratrees_pearson": 0.9902146576,
    "extratrees_bias": 26.3903403536,
    "extratrees_median_bias": 32.6876261385,

    "xgb_mae": 1490.7452392578125,
    "xgb_rmse": 4087.0079520353274,
    "xgb_r2": 0.9799503684,
    "xgb_pearson": 0.98993228,

    "lag28": 20.004240,
    "lag7": 19.759367,
    "lag14": 16.097803,
}

REJECTED_VALUES = [
    "61.998",
    "61.998%",
    "-5.48",
    "mean bias = -5.48",
    "Mean Bias = -5.48",
]

print("\n" + "=" * 100)
print("1. FINAL SOURCE-OF-TRUTH")
print("=" * 100)

for k, v in EXPECTED.items():
    print(f"{k:30s}: {v}")


# ============================================================
# 2. LOAD FINAL MODEL RESULTS
# ============================================================

print("\n" + "=" * 100)
print("2. VERIFY FINAL MODEL RESULTS")
print("=" * 100)

model_file = SCI / "FINAL_MANUSCRIPT_MODEL_RESULTS.csv"

if not model_file.exists():
    print("[FAIL] FINAL_MANUSCRIPT_MODEL_RESULTS.csv not found")
    raise SystemExit(1)

model_df = pd.read_csv(model_file)

print(model_df.to_string(index=False))

checks = []

def check_close(name, actual, expected, tolerance=1e-6):
    ok = np.isclose(actual, expected, atol=tolerance, rtol=1e-6)

    checks.append({
        "Check": name,
        "Expected": expected,
        "Actual": actual,
        "Status": "PASS" if ok else "FAIL"
    })

    return ok


# Flexible column detection
def find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


model_col = find_col(model_df, ["Model", "model"])

if model_col is None:
    print("[FAIL] Model column not found")
else:

    for _, row in model_df.iterrows():

        model_name = str(row[model_col]).lower()

        if "extratrees" in model_name:

            mae_col = find_col(model_df, ["MAE", "Test_MAE"])
            rmse_col = find_col(model_df, ["RMSE", "Test_RMSE"])
            r2_col = find_col(model_df, ["R2", "Test_R2"])
            pearson_col = find_col(model_df, ["Pearson_r", "Test_Pearson_r"])
            bias_col = find_col(model_df, ["Mean_Bias", "Bias"])

            if mae_col:
                check_close(
                    "ExtraTrees MAE",
                    float(row[mae_col]),
                    EXPECTED["extratrees_mae"]
                )

            if rmse_col:
                check_close(
                    "ExtraTrees RMSE",
                    float(row[rmse_col]),
                    EXPECTED["extratrees_rmse"]
                )

            if r2_col:
                check_close(
                    "ExtraTrees R2",
                    float(row[r2_col]),
                    EXPECTED["extratrees_r2"]
                )

            if pearson_col:
                check_close(
                    "ExtraTrees Pearson",
                    float(row[pearson_col]),
                    EXPECTED["extratrees_pearson"]
                )

            if bias_col:
                check_close(
                    "ExtraTrees Mean Bias",
                    float(row[bias_col]),
                    EXPECTED["extratrees_bias"]
                )

        elif "xgboost" in model_name:

            mae_col = find_col(model_df, ["MAE", "Test_MAE"])
            rmse_col = find_col(model_df, ["RMSE", "Test_RMSE"])
            r2_col = find_col(model_df, ["R2", "Test_R2"])
            pearson_col = find_col(model_df, ["Pearson_r", "Test_Pearson_r"])

            if mae_col:
                check_close(
                    "XGBoost MAE",
                    float(row[mae_col]),
                    EXPECTED["xgb_mae"]
                )

            if rmse_col:
                check_close(
                    "XGBoost RMSE",
                    float(row[rmse_col]),
                    EXPECTED["xgb_rmse"]
                )

            if r2_col:
                check_close(
                    "XGBoost R2",
                    float(row[r2_col]),
                    EXPECTED["xgb_r2"]
                )

            if pearson_col:
                check_close(
                    "XGBoost Pearson",
                    float(row[pearson_col]),
                    EXPECTED["xgb_pearson"]
                )


# ============================================================
# 3. FEATURE IMPORTANCE AUDIT
# ============================================================

print("\n" + "=" * 100)
print("3. FEATURE IMPORTANCE AUDIT")
print("=" * 100)

fi_file = SCI / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"

if not fi_file.exists():
    print("[FAIL] Feature importance file not found")
else:

    fi = pd.read_csv(fi_file)

    print(fi.to_string(index=False))

    feature_col = find_col(fi, ["Feature"])
    importance_col = find_col(fi, ["Percentage", "Importance"])

    if feature_col and importance_col:

        fi_dict = {}

        for _, row in fi.iterrows():

            feature = str(row[feature_col])

            value = float(row[importance_col])

            if importance_col == "Importance" and value < 1:
                value *= 100

            fi_dict[feature] = value

        def get_feature(name):
            for k, v in fi_dict.items():
                if name.lower() in k.lower():
                    return v
            return None

        for name, expected_key in [
            ("Lag_28", "lag28"),
            ("Lag_7", "lag7"),
            ("Lag_14", "lag14")
        ]:

            actual = get_feature(name)

            if actual is not None:
                check_close(
                    f"Feature importance {name}",
                    actual,
                    EXPECTED[expected_key],
                    tolerance=1e-4
                )


# ============================================================
# 4. ADVANCED XGBOOST AUDIT
# ============================================================

print("\n" + "=" * 100)
print("4. ADVANCED XGBOOST AUDIT")
print("=" * 100)

advanced_file = ADV / "baseline_vs_advanced.csv"

if not advanced_file.exists():
    print("[FAIL] baseline_vs_advanced.csv not found")
else:

    adv = pd.read_csv(advanced_file)

    print(adv.to_string(index=False))

    for _, row in adv.iterrows():

        model = str(row["Model"]).lower()

        if "extratrees" in model:

            check_close(
                "Advanced file ExtraTrees MAE",
                float(row["Test_MAE"]),
                EXPECTED["extratrees_mae"]
            )

            check_close(
                "Advanced file ExtraTrees RMSE",
                float(row["Test_RMSE"]),
                EXPECTED["extratrees_rmse"]
            )

        elif "xgboost" in model:

            check_close(
                "Advanced file XGBoost MAE",
                float(row["Test_MAE"]),
                EXPECTED["xgb_mae"]
            )

            check_close(
                "Advanced file XGBoost RMSE",
                float(row["Test_RMSE"]),
                EXPECTED["xgb_rmse"]
            )


# ============================================================
# 5. LEGACY VALUE SCAN
# ============================================================

print("\n" + "=" * 100)
print("5. LEGACY MANUSCRIPT VALUE SCAN")
print("=" * 100)

legacy_results = []

scan_extensions = {".py", ".txt", ".md", ".csv", ".json", ".tex"}

for path in ROOT.rglob("*"):

    if not path.is_file():
        continue

    if path.suffix.lower() not in scan_extensions:
        continue

    # Avoid scanning virtual environment and cache
    if ".venv" in path.parts:
        continue

    if "__pycache__" in path.parts:
        continue

    try:
        text_content = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )
    except Exception:
        continue

    for legacy in REJECTED_VALUES:

        if legacy.lower() in text_content.lower():

            legacy_results.append({
                "File": str(path.relative_to(ROOT)),
                "Rejected_Value": legacy
            })


if legacy_results:

    legacy_df = pd.DataFrame(legacy_results)

    print("[WARNING] Legacy values detected:")

    print(legacy_df.to_string(index=False))

else:

    legacy_df = pd.DataFrame(
        columns=["File", "Rejected_Value"]
    )

    print("[PASS] No rejected manuscript values found.")


legacy_df.to_csv(
    OUT / "legacy_value_scan.csv",
    index=False
)


# ============================================================
# 6. FIGURE AUDIT
# ============================================================

print("\n" + "=" * 100)
print("6. FIGURE FILE AUDIT")
print("=" * 100)

required_figures = [
    "Figure_1_Feature_Importance.png",
    "Figure_1_Feature_Importance.pdf",

    "Figure_2_Actual_vs_Predicted.png",
    "Figure_2_Actual_vs_Predicted.pdf",

    "Figure_3_Residual_Diagnostics.png",
    "Figure_3_Residual_Diagnostics.pdf",

    "Figure_4_Model_Comparison.png",
    "Figure_4_Model_Comparison.pdf",
]

figure_results = []

for filename in required_figures:

    path = FIG / filename

    exists = path.exists()

    figure_results.append({
        "Figure": filename,
        "Exists": exists,
        "Size_bytes": path.stat().st_size if exists else 0,
        "Status": "PASS" if exists else "FAIL"
    })

    print(
        f"[{'PASS' if exists else 'FAIL'}] "
        f"{filename}"
    )

figure_df = pd.DataFrame(figure_results)

figure_df.to_csv(
    OUT / "figure_file_audit.csv",
    index=False
)


# ============================================================
# 7. MANUSCRIPT NUMBER CONSISTENCY TEMPLATE
# ============================================================

print("\n" + "=" * 100)
print("7. MANUSCRIPT NUMBER CONSISTENCY CHECKLIST")
print("=" * 100)

number_checks = [
    ("549,122", "Initial dataset observations"),
    ("437", "Initial stations"),
    ("516,819", "Final ML observations"),
    ("434", "Final ML stations"),
    ("140,157", "Training observations"),
    ("151,509", "Validation observations"),
    ("225,153", "Test observations"),
    ("1,400.3845", "ExtraTrees MAE"),
    ("4,036.1222", "ExtraTrees RMSE"),
    ("0.980447", "ExtraTrees R2"),
    ("0.990215", "ExtraTrees Pearson"),
    ("26.3903", "ExtraTrees mean residual"),
    ("1,490.7452", "XGBoost MAE"),
    ("4,087.0080", "XGBoost RMSE"),
    ("0.979950", "XGBoost R2"),
    ("0.989932", "XGBoost Pearson"),
    ("20.0042%", "Lag_28 importance"),
    ("19.7594%", "Lag_7 importance"),
    ("16.0978%", "Lag_14 importance"),
]

checklist_df = pd.DataFrame(
    number_checks,
    columns=["Expected_Value", "Description"]
)

checklist_df["Status"] = "MANUAL_VERIFY"

checklist_df.to_csv(
    OUT / "manuscript_number_checklist.csv",
    index=False
)

print(checklist_df.to_string(index=False))


# ============================================================
# 8. CALCULATE MODEL DIFFERENCES
# ============================================================

print("\n" + "=" * 100)
print("8. MODEL COMPARISON DELTAS")
print("=" * 100)

mae_change = (
    EXPECTED["xgb_mae"] /
    EXPECTED["extratrees_mae"] - 1
) * 100

rmse_change = (
    EXPECTED["xgb_rmse"] /
    EXPECTED["extratrees_rmse"] - 1
) * 100

r2_difference = (
    EXPECTED["xgb_r2"] -
    EXPECTED["extratrees_r2"]
)

pearson_difference = (
    EXPECTED["xgb_pearson"] -
    EXPECTED["extratrees_pearson"]
)

comparison = pd.DataFrame([{
    "Metric": "MAE",
    "ExtraTrees": EXPECTED["extratrees_mae"],
    "XGBoost": EXPECTED["xgb_mae"],
    "XGBoost_relative_change_percent": mae_change
}, {
    "Metric": "RMSE",
    "ExtraTrees": EXPECTED["extratrees_rmse"],
    "XGBoost": EXPECTED["xgb_rmse"],
    "XGBoost_relative_change_percent": rmse_change
}, {
    "Metric": "R2",
    "ExtraTrees": EXPECTED["extratrees_r2"],
    "XGBoost": EXPECTED["xgb_r2"],
    "XGBoost_relative_change_percent": np.nan
}, {
    "Metric": "Pearson_r",
    "ExtraTrees": EXPECTED["extratrees_pearson"],
    "XGBoost": EXPECTED["xgb_pearson"],
    "XGBoost_relative_change_percent": np.nan
}])

comparison.to_csv(
    OUT / "model_comparison_deltas.csv",
    index=False
)

print(comparison.to_string(index=False))

print(f"\nR2 difference       : {r2_difference:.8f}")
print(f"Pearson difference : {pearson_difference:.8f}")


# ============================================================
# 9. FINAL AUDIT STATUS
# ============================================================

print("\n" + "=" * 100)
print("9. FINAL AUDIT STATUS")
print("=" * 100)

check_df = pd.DataFrame(checks)

if not check_df.empty:
    print(check_df.to_string(index=False))

metric_failures = (
    int((check_df["Status"] == "FAIL").sum())
    if not check_df.empty
    else 0
)

legacy_failures = len(legacy_results)

figure_failures = int(
    (figure_df["Status"] == "FAIL").sum()
)

total_failures = (
    metric_failures +
    legacy_failures +
    figure_failures
)

summary = {
    "Metric_check_failures": metric_failures,
    "Legacy_value_hits": legacy_failures,
    "Figure_file_failures": figure_failures,
    "Total_failures": total_failures,
    "Overall_status": (
        "PASS"
        if total_failures == 0
        else "REVIEW_REQUIRED"
    )
}

summary_df = pd.DataFrame([summary])

summary_df.to_csv(
    OUT / "STAGE35_FINAL_AUDIT_SUMMARY.csv",
    index=False
)

print(json.dumps(summary, indent=4))

print("\n" + "=" * 100)

if total_failures == 0:

    print("STAGE 35 — PASS")
    print("All automated consistency checks passed.")
    print("No rejected legacy manuscript values detected.")
    print("All required figure files are present.")

else:

    print("STAGE 35 — REVIEW REQUIRED")
    print(f"Total detected issues: {total_failures}")

print("=" * 100)

print("\nGenerated audit files:")
print("  stage35_audit/STAGE35_FINAL_AUDIT_SUMMARY.csv")
print("  stage35_audit/legacy_value_scan.csv")
print("  stage35_audit/figure_file_audit.csv")
print("  stage35_audit/manuscript_number_checklist.csv")
print("  stage35_audit/model_comparison_deltas.csv")

print("\nNEXT STAGE:")
print("STAGE 36 -> FINAL Q1 SUBMISSION PACKAGE")
print("=" * 100)