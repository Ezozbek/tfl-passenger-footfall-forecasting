# ============================================================
# ablation_tfl_forecasting_v2.py
# ============================================================
#
# TfL Forecasting - Leakage-Controlled Ablation Study v2
#
# Main improvements over v1:
#   1. Uses fixed chronological train/validation/test boundaries
#      BEFORE dropping lag/rolling NaNs.
#   2. Each ablation has its own valid rows, but the temporal
#      boundaries remain identical.
#   3. Checks whether removed feature groups actually change
#      the feature matrix.
#   4. Checks whether different ablations produce identical
#      predictions.
#   5. Saves feature diagnostics.
#   6. Saves model-level metrics and component contribution.
#   7. Keeps all experiments reproducible.
#
# Dataset currently detected from the project:
#   Journeys_2025_2026 .csv
#
# Expected columns:
#   TravelDate
#   TubeJourneyCount
#   BusJourneyCount
#
# Output:
#   tfl_ablation_results_v2/
#       ablation_results_v2.csv
#       ablation_predictions_v2.csv
#       feature_summary_v2.csv
#       feature_diagnostics_v2.csv
#       split_summary_v2.csv
#
# ============================================================

from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd

from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

warnings.filterwarnings("ignore")


# ============================================================
# 1. CONFIGURATION
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent

# ------------------------------------------------------------
# Dataset
# ------------------------------------------------------------

DATA_FILE = PROJECT_DIR / "Journeys_2025_2026 .csv"

# If the exact file is not found, automatic CSV discovery
# will be used.
AUTO_DISCOVER_DATASET = True

# ------------------------------------------------------------
# Output
# ------------------------------------------------------------

OUTPUT_DIR = (
    PROJECT_DIR
    / "tfl_ablation_results_v2"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

# ------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------

RANDOM_STATE = 42

# ------------------------------------------------------------
# Temporal split
# ------------------------------------------------------------

TRAIN_RATIO = 0.70
VALIDATION_RATIO = 0.15
TEST_RATIO = 0.15

assert abs(
    TRAIN_RATIO
    + VALIDATION_RATIO
    + TEST_RATIO
    - 1.0
) < 1e-9


# ============================================================
# 2. COLUMN DETECTION
# ============================================================

TIME_CANDIDATES = [
    "TravelDate",
    "Timestamp",
    "timestamp",
    "Datetime",
    "datetime",
    "DateTime",
    "date_time",
    "Date",
    "date",
]

TARGET_CANDIDATES = [
    "TubeJourneyCount",
    "Demand",
    "demand",
    "Trips",
    "trips",
    "Entry_Count",
    "entry_count",
    "Volume",
    "volume",
]


# ============================================================
# 3. PRINT UTILITIES
# ============================================================

def print_header(title):

    print("\n")
    print("=" * 100)
    print(title)
    print("=" * 100)


def print_section(title):

    print("\n")
    print("-" * 100)
    print(title)
    print("-" * 100)


# ============================================================
# 4. COLUMN FINDING
# ============================================================

def find_column(
    df,
    candidates,
    required=True
):

    lower_map = {
        str(c).strip().lower(): c
        for c in df.columns
    }

    for candidate in candidates:

        key = candidate.strip().lower()

        if key in lower_map:
            return lower_map[key]

    if required:

        raise ValueError(
            "\nRequired column was not found.\n"
            f"Candidates: {candidates}\n"
            f"Available columns: {list(df.columns)}"
        )

    return None


def detect_time_column(df):

    col = find_column(
        df,
        TIME_CANDIDATES,
        required=False
    )

    if col is not None:
        return col

    for c in df.columns:

        name = str(c).lower()

        if (
            "traveldate" in name
            or "timestamp" in name
            or "datetime" in name
            or name == "date"
        ):
            return c

    raise ValueError(
        "Could not detect datetime column."
    )


def detect_target_column(df):

    col = find_column(
        df,
        TARGET_CANDIDATES,
        required=False
    )

    if col is not None:
        return col

    for c in df.columns:

        name = str(c).lower()

        if (
            "tube" in name
            and "count" in name
        ):
            return c

        if "demand" in name:
            return c

        if "journey" in name:
            return c

    raise ValueError(
        "Could not detect target column."
    )


# ============================================================
# 5. DATASET DISCOVERY
# ============================================================

print_header(
    "TF L FORECASTING - ABLATION STUDY V2"
)

print_section(
    "LOADING MASTER DATASET"
)

if not DATA_FILE.exists():

    print(
        f"WARNING: {DATA_FILE.name} was not found."
    )

    if not AUTO_DISCOVER_DATASET:

        raise FileNotFoundError(
            DATA_FILE
        )

    csv_files = sorted(
        PROJECT_DIR.glob("*.csv")
    )

    if not csv_files:

        raise FileNotFoundError(
            "No CSV files found in project directory."
        )

    print(
        "Available CSV files:"
    )

    for f in csv_files:
        print(
            "  -",
            f.name
        )

    # Prefer journey-related files.
    preferred = [
        f
        for f in csv_files
        if (
            "journey" in f.name.lower()
            or "tfl" in f.name.lower()
        )
    ]

    if preferred:

        DATA_FILE = preferred[0]

    else:

        DATA_FILE = csv_files[0]


print(
    "Dataset:",
    DATA_FILE
)

df = pd.read_csv(
    DATA_FILE
)

print(
    f"Rows    : {len(df):,}"
)

print(
    f"Columns : {len(df.columns)}"
)

print(
    "\nColumns:"
)

for c in df.columns:

    print(
        "  -",
        c
    )


# ============================================================
# 6. DETECT IMPORTANT COLUMNS
# ============================================================

TIME_COL = detect_time_column(df)

TARGET_COL = detect_target_column(df)

print_section(
    "DETECTED COLUMNS"
)

print(
    "Time   :",
    TIME_COL
)

print(
    "Target :",
    TARGET_COL
)


# ============================================================
# 7. DATETIME PREPARATION
# ============================================================

print_section(
    "PREPARING TIME INDEX"
)

df[TIME_COL] = pd.to_datetime(
    df[TIME_COL],
    errors="coerce"
)

invalid_time = df[TIME_COL].isna().sum()

if invalid_time > 0:

    print(
        "Removing invalid timestamps:",
        invalid_time
    )

    df = df.dropna(
        subset=[TIME_COL]
    ).copy()


# ------------------------------------------------------------
# Target numeric conversion
# ------------------------------------------------------------

df[TARGET_COL] = pd.to_numeric(
    df[TARGET_COL],
    errors="coerce"
)

invalid_target = df[TARGET_COL].isna().sum()

if invalid_target > 0:

    print(
        "Removing invalid target rows:",
        invalid_target
    )

    df = df.dropna(
        subset=[TARGET_COL]
    ).copy()


# ------------------------------------------------------------
# Sort chronologically
# ------------------------------------------------------------

df = (
    df
    .sort_values(
        TIME_COL
    )
    .reset_index(
        drop=True
    )
)


# ============================================================
# 8. DUPLICATE TIMESTAMPS
# ============================================================

duplicate_count = (
    df
    .duplicated(
        subset=[TIME_COL]
    )
    .sum()
)

print(
    "\nDuplicate timestamps:",
    duplicate_count
)

if duplicate_count > 0:

    print(
        "WARNING: duplicate timestamps detected."
    )

    numeric_columns = (
        df
        .select_dtypes(
            include=[np.number]
        )
        .columns
        .tolist()
    )

    aggregation = {
        c: "mean"
        for c in numeric_columns
    }

    df = (
        df
        .groupby(
            TIME_COL,
            as_index=False
        )
        .agg(
            aggregation
        )
        .sort_values(
            TIME_COL
        )
        .reset_index(
            drop=True
        )
    )


# ============================================================
# 9. CREATE FIXED TEMPORAL SPLIT
# ============================================================

print_section(
    "CREATING FIXED TEMPORAL SPLIT"
)

n_total = len(df)

train_end = int(
    n_total * TRAIN_RATIO
)

validation_end = int(
    n_total
    * (TRAIN_RATIO + VALIDATION_RATIO)
)

# IMPORTANT:
# These boundaries are created BEFORE feature-specific
# NaN removal. Therefore every ablation experiment uses
# exactly the same temporal periods.

df["_split"] = "test"

df.loc[
    :train_end - 1,
    "_split"
] = "train"

df.loc[
    train_end:validation_end - 1,
    "_split"
] = "validation"


train_raw = df[
    df["_split"] == "train"
].copy()

validation_raw = df[
    df["_split"] == "validation"
].copy()

test_raw = df[
    df["_split"] == "test"
].copy()


print(
    f"Total      : {len(df):,}"
)

print(
    f"Train      : {len(train_raw):,}"
)

print(
    f"Validation : {len(validation_raw):,}"
)

print(
    f"Test       : {len(test_raw):,}"
)

print(
    "\nTrain period:"
)

print(
    train_raw[TIME_COL].min(),
    "->",
    train_raw[TIME_COL].max()
)

print(
    "\nValidation period:"
)

print(
    validation_raw[TIME_COL].min(),
    "->",
    validation_raw[TIME_COL].max()
)

print(
    "\nTest period:"
)

print(
    test_raw[TIME_COL].min(),
    "->",
    test_raw[TIME_COL].max()
)


# ============================================================
# 10. SAVE SPLIT SUMMARY
# ============================================================

split_summary = pd.DataFrame(
    [
        {
            "Split": "Train",
            "Rows": len(train_raw),
            "Start": train_raw[TIME_COL].min(),
            "End": train_raw[TIME_COL].max(),
        },
        {
            "Split": "Validation",
            "Rows": len(validation_raw),
            "Start": validation_raw[TIME_COL].min(),
            "End": validation_raw[TIME_COL].max(),
        },
        {
            "Split": "Test",
            "Rows": len(test_raw),
            "Start": test_raw[TIME_COL].min(),
            "End": test_raw[TIME_COL].max(),
        },
    ]
)

split_summary.to_csv(
    OUTPUT_DIR
    / "split_summary_v2.csv",
    index=False
)


# ============================================================
# 11. FEATURE ENGINEERING
# ============================================================

print_section(
    "CREATING LEAKAGE-CONTROLLED FEATURES"
)

# ------------------------------------------------------------
# Calendar features
# ------------------------------------------------------------

df["year"] = (
    df[TIME_COL].dt.year
)

df["month"] = (
    df[TIME_COL].dt.month
)

df["day"] = (
    df[TIME_COL].dt.day
)

df["day_of_week"] = (
    df[TIME_COL].dt.dayofweek
)

df["day_of_year"] = (
    df[TIME_COL].dt.dayofyear
)

df["week_of_year"] = (
    df[TIME_COL]
    .dt.isocalendar()
    .week
    .astype(int)
)

df["hour"] = (
    df[TIME_COL].dt.hour
)

df["minute"] = (
    df[TIME_COL].dt.minute
)

df["is_weekend"] = (
    df["day_of_week"] >= 5
).astype(int)

df["is_month_start"] = (
    df[TIME_COL]
    .dt.is_month_start
    .astype(int)
)

df["is_month_end"] = (
    df[TIME_COL]
    .dt.is_month_end
    .astype(int)
)


# ------------------------------------------------------------
# Cyclic features
# ------------------------------------------------------------

df["hour_sin"] = np.sin(
    2
    * np.pi
    * df["hour"]
    / 24
)

df["hour_cos"] = np.cos(
    2
    * np.pi
    * df["hour"]
    / 24
)

df["dow_sin"] = np.sin(
    2
    * np.pi
    * df["day_of_week"]
    / 7
)

df["dow_cos"] = np.cos(
    2
    * np.pi
    * df["day_of_week"]
    / 7
)

df["month_sin"] = np.sin(
    2
    * np.pi
    * df["month"]
    / 12
)

df["month_cos"] = np.cos(
    2
    * np.pi
    * df["month"]
    / 12
)


# ============================================================
# 12. LAG FEATURES
# ============================================================

LAG_VALUES = [
    1,
    2,
    3,
    6,
    12,
    24,
    48,
    72,
    168,
]

LAG_FEATURES = []

for lag in LAG_VALUES:

    feature_name = (
        f"lag_{lag}"
    )

    df[feature_name] = (
        df[TARGET_COL]
        .shift(lag)
    )

    LAG_FEATURES.append(
        feature_name
    )


# ============================================================
# 13. ROLLING FEATURES
# ============================================================

ROLLING_WINDOWS = [
    3,
    6,
    12,
    24,
    48,
    168,
]

ROLLING_FEATURES = []

# IMPORTANT:
# shift(1) ensures that rolling statistics never include
# the current target value.

shifted_target = (
    df[TARGET_COL]
    .shift(1)
)

for window in ROLLING_WINDOWS:

    mean_name = (
        f"rolling_mean_{window}"
    )

    std_name = (
        f"rolling_std_{window}"
    )

    df[mean_name] = (
        shifted_target
        .rolling(
            window=window,
            min_periods=window
        )
        .mean()
    )

    df[std_name] = (
        shifted_target
        .rolling(
            window=window,
            min_periods=window
        )
        .std()
    )

    ROLLING_FEATURES.extend(
        [
            mean_name,
            std_name,
        ]
    )


# ============================================================
# 14. EXOGENOUS FEATURES
# ============================================================

print_section(
    "IDENTIFYING EXOGENOUS FEATURES"
)

CALENDAR_FEATURES = [
    "year",
    "month",
    "day",
    "day_of_week",
    "day_of_year",
    "week_of_year",
    "hour",
    "minute",
    "is_weekend",
    "is_month_start",
    "is_month_end",
    "hour_sin",
    "hour_cos",
    "dow_sin",
    "dow_cos",
    "month_sin",
    "month_cos",
]

GENERATED_FEATURES = set(
    CALENDAR_FEATURES
    + LAG_FEATURES
    + ROLLING_FEATURES
)

excluded_columns = {
    TIME_COL,
    TARGET_COL,
    "_split",
}

numeric_columns = (
    df
    .select_dtypes(
        include=[np.number]
    )
    .columns
    .tolist()
)

EXOGENOUS_FEATURES = [
    c
    for c in numeric_columns
    if (
        c not in excluded_columns
        and c not in GENERATED_FEATURES
    )
]

print(
    "Exogenous features:"
)

if EXOGENOUS_FEATURES:

    for c in EXOGENOUS_FEATURES:

        print(
            "  -",
            c
        )

else:

    print(
        "  None"
    )


# ============================================================
# 15. FEATURE GROUP SUMMARY
# ============================================================

FULL_FEATURES = list(
    dict.fromkeys(
        CALENDAR_FEATURES
        + LAG_FEATURES
        + ROLLING_FEATURES
        + EXOGENOUS_FEATURES
    )
)


print_section(
    "FEATURE GROUPS"
)

print(
    "Calendar:",
    len(CALENDAR_FEATURES)
)

print(
    "Lag:",
    len(LAG_FEATURES)
)

print(
    "Rolling:",
    len(ROLLING_FEATURES)
)

print(
    "Exogenous:",
    len(EXOGENOUS_FEATURES)
)

print(
    "Full:",
    len(FULL_FEATURES)
)


# ============================================================
# 16. ABLATION EXPERIMENT DEFINITIONS
# ============================================================

EXPERIMENTS = {

    "A0_Full": {
        "description":
            "Full calendar + lag + rolling + exogenous",
        "features":
            FULL_FEATURES,
    },

    "A1_No_Calendar": {
        "description":
            "Without calendar and cyclic features",
        "features":
            (
                LAG_FEATURES
                + ROLLING_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A2_No_Lag": {
        "description":
            "Without autoregressive lag features",
        "features":
            (
                CALENDAR_FEATURES
                + ROLLING_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A3_No_Rolling": {
        "description":
            "Without rolling statistical features",
        "features":
            (
                CALENDAR_FEATURES
                + LAG_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A4_No_Exogenous": {
        "description":
            "Without external numerical variables",
        "features":
            (
                CALENDAR_FEATURES
                + LAG_FEATURES
                + ROLLING_FEATURES
            ),
    },

    "A5_Minimal_AR": {
        "description":
            "Only lag and rolling demand features",
        "features":
            (
                LAG_FEATURES
                + ROLLING_FEATURES
            ),
    },

    "A6_Calendar_Only": {
        "description":
            "Only calendar and cyclic time features",
        "features":
            CALENDAR_FEATURES,
    },
}


# ============================================================
# 17. MODEL
# ============================================================

def build_model():

    return HistGradientBoostingRegressor(

        learning_rate=0.05,

        max_iter=400,

        max_leaf_nodes=31,

        max_depth=None,

        min_samples_leaf=20,

        l2_regularization=0.1,

        random_state=RANDOM_STATE,
    )


# ============================================================
# 18. METRIC FUNCTIONS
# ============================================================

def calculate_rmse(
    y_true,
    y_pred
):

    return float(
        np.sqrt(
            mean_squared_error(
                y_true,
                y_pred
            )
        )
    )


def calculate_mape(
    y_true,
    y_pred
):

    y_true = np.asarray(
        y_true,
        dtype=float
    )

    y_pred = np.asarray(
        y_pred,
        dtype=float
    )

    mask = (
        np.abs(y_true)
        > 1e-8
    )

    if mask.sum() == 0:
        return np.nan

    return float(
        np.mean(
            np.abs(
                (
                    y_true[mask]
                    - y_pred[mask]
                )
                / y_true[mask]
            )
        )
        * 100
    )


def calculate_smape(
    y_true,
    y_pred
):

    y_true = np.asarray(
        y_true,
        dtype=float
    )

    y_pred = np.asarray(
        y_pred,
        dtype=float
    )

    denominator = (
        np.abs(y_true)
        + np.abs(y_pred)
    )

    mask = (
        denominator
        > 1e-8
    )

    if mask.sum() == 0:
        return np.nan

    return float(
        np.mean(
            2
            * np.abs(
                y_pred[mask]
                - y_true[mask]
            )
            / denominator[mask]
        )
        * 100
    )


def evaluate_predictions(
    y_true,
    y_pred
):

    return {

        "MAE":
            mean_absolute_error(
                y_true,
                y_pred
            ),

        "RMSE":
            calculate_rmse(
                y_true,
                y_pred
            ),

        "R2":
            r2_score(
                y_true,
                y_pred
            ),

        "MAPE_percent":
            calculate_mape(
                y_true,
                y_pred
            ),

        "sMAPE_percent":
            calculate_smape(
                y_true,
                y_pred
            ),

        "Mean_Bias":
            float(
                np.mean(
                    y_pred
                    - y_true
                )
            ),

        "Median_Bias":
            float(
                np.median(
                    y_pred
                    - y_true
                )
            ),
    }


# ============================================================
# 19. PREPARE EXPERIMENT DATA
# ============================================================

def prepare_experiment_data(
    feature_list
):

    feature_list = [
        c
        for c in feature_list
        if c in df.columns
    ]

    # --------------------------------------------------------
    # Work from the FULL chronological dataframe.
    # Do NOT create split after dropping NaNs.
    # --------------------------------------------------------

    work = df[
        [
            TIME_COL,
            TARGET_COL,
            "_split",
        ]
        + feature_list
    ].copy()

    work = work.replace(
        [np.inf, -np.inf],
        np.nan
    )

    # --------------------------------------------------------
    # Train / validation / test
    # --------------------------------------------------------

    train = work[
        work["_split"] == "train"
    ].copy()

    validation = work[
        work["_split"] == "validation"
    ].copy()

    test = work[
        work["_split"] == "test"
    ].copy()

    # --------------------------------------------------------
    # Train-only medians
    # --------------------------------------------------------

    medians = (
        train[feature_list]
        .median()
    )

    train_features = (
        train[feature_list]
        .fillna(medians)
    )

    validation_features = (
        validation[feature_list]
        .fillna(medians)
    )

    test_features = (
        test[feature_list]
        .fillna(medians)
    )

    # --------------------------------------------------------
    # Target
    # --------------------------------------------------------

    y_train = (
        train[TARGET_COL]
        .values
    )

    y_validation = (
        validation[TARGET_COL]
        .values
    )

    y_test = (
        test[TARGET_COL]
        .values
    )

    return (
        train,
        validation,
        test,
        train_features,
        validation_features,
        test_features,
        y_train,
        y_validation,
        y_test,
    )


# ============================================================
# 20. FEATURE DIAGNOSTICS
# ============================================================

print_section(
    "FEATURE DIAGNOSTICS"
)

feature_diagnostics = []

for experiment_name, config in EXPERIMENTS.items():

    features = [
        c
        for c in config["features"]
        if c in df.columns
    ]

    train_part = df[
        df["_split"] == "train"
    ].copy()

    valid_part = df[
        df["_split"] == "validation"
    ].copy()

    test_part = df[
        df["_split"] == "test"
    ].copy()

    missing_total = int(
        df[features]
        .isna()
        .sum()
        .sum()
    )

    constant_features = []

    for feature in features:

        unique_values = (
            df[feature]
            .nunique(
                dropna=True
            )
        )

        if unique_values <= 1:

            constant_features.append(
                feature
            )

    diagnostics_row = {

        "Experiment":
            experiment_name,

        "Feature_Count":
            len(features),

        "Missing_Cells_Total":
            missing_total,

        "Constant_Feature_Count":
            len(constant_features),

        "Constant_Features":
            ";".join(
                constant_features
            ),

        "Train_Rows":
            len(train_part),

        "Validation_Rows":
            len(valid_part),

        "Test_Rows":
            len(test_part),
    }

    feature_diagnostics.append(
        diagnostics_row
    )

    print(
        f"{experiment_name:25s}"
        f" features={len(features):3d}"
        f" missing={missing_total:5d}"
        f" constants={len(constant_features):2d}"
    )


feature_diagnostics_df = pd.DataFrame(
    feature_diagnostics
)

feature_diagnostics_df.to_csv(
    OUTPUT_DIR
    / "feature_diagnostics_v2.csv",
    index=False
)


# ============================================================
# 21. RUN EXPERIMENTS
# ============================================================

print_header(
    "RUNNING ABLATION EXPERIMENTS V2"
)

all_results = []

all_predictions = []

feature_summary = []


for experiment_name, config in EXPERIMENTS.items():

    print_section(
        f"EXPERIMENT: {experiment_name}"
    )

    features = [
        c
        for c in config["features"]
        if c in df.columns
    ]

    print(
        "Description:",
        config["description"]
    )

    print(
        "Feature count:",
        len(features)
    )

    print(
        "Features:"
    )

    for feature in features:

        print(
            "  -",
            feature
        )

    if not features:

        print(
            "SKIPPED: no features."
        )

        continue


    # --------------------------------------------------------
    # Prepare
    # --------------------------------------------------------

    (
        train,
        validation,
        test,
        X_train,
        X_validation,
        X_test,
        y_train,
        y_validation,
        y_test,
    ) = prepare_experiment_data(
        features
    )


    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    model = build_model()

    start_time = time.perf_counter()

    model.fit(
        X_train,
        y_train
    )

    training_time = (
        time.perf_counter()
        - start_time
    )


    # --------------------------------------------------------
    # Predictions
    # --------------------------------------------------------

    validation_prediction = (
        model.predict(
            X_validation
        )
    )

    test_prediction = (
        model.predict(
            X_test
        )
    )


    # --------------------------------------------------------
    # Metrics
    # --------------------------------------------------------

    validation_metrics = (
        evaluate_predictions(
            y_validation,
            validation_prediction
        )
    )

    test_metrics = (
        evaluate_predictions(
            y_test,
            test_prediction
        )
    )


    # --------------------------------------------------------
    # Results
    # --------------------------------------------------------

    result = {

        "Experiment":
            experiment_name,

        "Description":
            config["description"],

        "Feature_Count":
            len(features),

        "Train_Rows":
            len(X_train),

        "Validation_Rows":
            len(X_validation),

        "Test_Rows":
            len(X_test),

        "Validation_MAE":
            validation_metrics["MAE"],

        "Validation_RMSE":
            validation_metrics["RMSE"],

        "Validation_R2":
            validation_metrics["R2"],

        "Validation_MAPE_percent":
            validation_metrics[
                "MAPE_percent"
            ],

        "Validation_sMAPE_percent":
            validation_metrics[
                "sMAPE_percent"
            ],

        "Validation_Mean_Bias":
            validation_metrics[
                "Mean_Bias"
            ],

        "Validation_Median_Bias":
            validation_metrics[
                "Median_Bias"
            ],

        "Test_MAE":
            test_metrics["MAE"],

        "Test_RMSE":
            test_metrics["RMSE"],

        "Test_R2":
            test_metrics["R2"],

        "Test_MAPE_percent":
            test_metrics[
                "MAPE_percent"
            ],

        "Test_sMAPE_percent":
            test_metrics[
                "sMAPE_percent"
            ],

        "Test_Mean_Bias":
            test_metrics[
                "Mean_Bias"
            ],

        "Test_Median_Bias":
            test_metrics[
                "Median_Bias"
            ],

        "Training_Time_sec":
            training_time,
    }

    all_results.append(
        result
    )


    # --------------------------------------------------------
    # Feature summary
    # --------------------------------------------------------

    feature_summary.append(
        {
            "Experiment":
                experiment_name,

            "Feature_Count":
                len(features),

            "Features":
                ";".join(features),
        }
    )


    # --------------------------------------------------------
    # Test predictions
    # --------------------------------------------------------

    prediction_frame = pd.DataFrame(
        {
            "Experiment":
                experiment_name,

            "Timestamp":
                test[TIME_COL].values,

            "Actual":
                y_test,

            "Predicted":
                test_prediction,

            "Residual":
                (
                    test_prediction
                    - y_test
                ),
        }
    )

    all_predictions.append(
        prediction_frame
    )


    # --------------------------------------------------------
    # Console
    # --------------------------------------------------------

    print(
        "\nValidation:"
    )

    print(
        f"  MAE  = "
        f"{validation_metrics['MAE']:.4f}"
    )

    print(
        f"  RMSE = "
        f"{validation_metrics['RMSE']:.4f}"
    )

    print(
        f"  R2   = "
        f"{validation_metrics['R2']:.4f}"
    )

    print(
        "\nTest:"
    )

    print(
        f"  MAE  = "
        f"{test_metrics['MAE']:.4f}"
    )

    print(
        f"  RMSE = "
        f"{test_metrics['RMSE']:.4f}"
    )

    print(
        f"  R2   = "
        f"{test_metrics['R2']:.4f}"
    )

    print(
        f"  MAPE = "
        f"{test_metrics['MAPE_percent']:.4f}%"
    )

    print(
        f"  sMAPE = "
        f"{test_metrics['sMAPE_percent']:.4f}%"
    )

    print(
        f"\nTraining time = "
        f"{training_time:.3f} sec"
    )


# ============================================================
# 22. RESULTS DATAFRAME
# ============================================================

print_header(
    "BUILDING FINAL ABLATION TABLE"
)

results_df = pd.DataFrame(
    all_results
)

predictions_df = pd.concat(
    all_predictions,
    ignore_index=True
)

feature_summary_df = pd.DataFrame(
    feature_summary
)


# ============================================================
# 23. CALCULATE ABLATION CONTRIBUTIONS
# ============================================================

print_section(
    "CALCULATING COMPONENT CONTRIBUTIONS"
)

if not results_df.empty:

    full_rows = results_df[
        results_df["Experiment"]
        == "A0_Full"
    ]

    if len(full_rows) == 1:

        full_rmse = float(
            full_rows[
                "Test_RMSE"
            ].iloc[0]
        )

        full_mae = float(
            full_rows[
                "Test_MAE"
            ].iloc[0]
        )

        full_r2 = float(
            full_rows[
                "Test_R2"
            ].iloc[0]
        )

        full_mape = float(
            full_rows[
                "Test_MAPE_percent"
            ].iloc[0]
        )

        results_df[
            "Delta_RMSE_vs_Full"
        ] = (
            results_df["Test_RMSE"]
            - full_rmse
        )

        results_df[
            "Delta_MAE_vs_Full"
        ] = (
            results_df["Test_MAE"]
            - full_mae
        )

        results_df[
            "Delta_R2_vs_Full"
        ] = (
            results_df["Test_R2"]
            - full_r2
        )

        results_df[
            "Delta_MAPE_vs_Full"
        ] = (
            results_df[
                "Test_MAPE_percent"
            ]
            - full_mape
        )

        # ----------------------------------------------------
        # Percentage RMSE change
        # ----------------------------------------------------

        results_df[
            "RMSE_Change_percent_vs_Full"
        ] = (
            (
                results_df["Test_RMSE"]
                - full_rmse
            )
            / full_rmse
            * 100
        )

        # ----------------------------------------------------
        # Positive value means removing a component caused
        # RMSE to increase relative to full model.
        # ----------------------------------------------------

        results_df[
            "RMSE_Degradation_percent"
        ] = (
            (
                results_df["Test_RMSE"]
                - full_rmse
            )
            / full_rmse
            * 100
        )


# ============================================================
# 24. IDENTICAL PREDICTION DIAGNOSTICS
# ============================================================

print_section(
    "IDENTICAL-PREDICTION DIAGNOSTICS"
)

prediction_diagnostics = []

experiment_names = (
    predictions_df[
        "Experiment"
    ]
    .unique()
    .tolist()
)

for i in range(
    len(experiment_names)
):

    for j in range(
        i + 1,
        len(experiment_names)
    ):

        exp_a = (
            experiment_names[i]
        )

        exp_b = (
            experiment_names[j]
        )

        pred_a = (
            predictions_df[
                predictions_df[
                    "Experiment"
                ] == exp_a
            ]
            .sort_values(
                "Timestamp"
            )["Predicted"]
            .values
        )

        pred_b = (
            predictions_df[
                predictions_df[
                    "Experiment"
                ] == exp_b
            ]
            .sort_values(
                "Timestamp"
            )["Predicted"]
            .values
        )

        if len(pred_a) != len(pred_b):

            continue

        max_difference = float(
            np.max(
                np.abs(
                    pred_a
                    - pred_b
                )
            )
        )

        identical = bool(
            np.allclose(
                pred_a,
                pred_b,
                rtol=1e-10,
                atol=1e-10
            )
        )

        prediction_diagnostics.append(
            {
                "Experiment_A":
                    exp_a,

                "Experiment_B":
                    exp_b,

                "Identical_Predictions":
                    identical,

                "Max_Absolute_Difference":
                    max_difference,
            }
        )

        if identical:

            print(
                f"WARNING: "
                f"{exp_a} and {exp_b} "
                f"have identical predictions."
            )

        else:

            print(
                f"OK: "
                f"{exp_a} vs {exp_b} "
                f"max difference = "
                f"{max_difference:.10f}"
            )


prediction_diagnostics_df = pd.DataFrame(
    prediction_diagnostics
)

prediction_diagnostics_df.to_csv(
    OUTPUT_DIR
    / "prediction_diagnostics_v2.csv",
    index=False
)


# ============================================================
# 25. SORT RESULTS
# ============================================================

if not results_df.empty:

    results_df = (
        results_df
        .sort_values(
            "Test_RMSE",
            ascending=True
        )
        .reset_index(
            drop=True
        )
    )


# ============================================================
# 26. SAVE RESULTS
# ============================================================

print_header(
    "SAVING ABLATION RESULTS"
)

results_file = (
    OUTPUT_DIR
    / "ablation_results_v2.csv"
)

predictions_file = (
    OUTPUT_DIR
    / "ablation_predictions_v2.csv"
)

features_file = (
    OUTPUT_DIR
    / "feature_summary_v2.csv"
)


results_df.to_csv(
    results_file,
    index=False
)

predictions_df.to_csv(
    predictions_file,
    index=False
)

feature_summary_df.to_csv(
    features_file,
    index=False
)


# ============================================================
# 27. FINAL SUMMARY
# ============================================================

print_header(
    "FINAL ABLATION SUMMARY V2"
)

if not results_df.empty:

    summary_columns = [

        "Experiment",

        "Feature_Count",

        "Validation_RMSE",

        "Test_MAE",

        "Test_RMSE",

        "Test_R2",

        "Test_MAPE_percent",

        "Test_sMAPE_percent",

        "Delta_RMSE_vs_Full",

        "RMSE_Degradation_percent",
    ]

    available_columns = [
        c
        for c in summary_columns
        if c in results_df.columns
    ]

    print(
        results_df[
            available_columns
        ].to_string(
            index=False,
            float_format=lambda x:
                f"{x:.4f}"
        )
    )

else:

    print(
        "No experiments completed."
    )


# ============================================================
# 28. COMPONENT ANALYSIS
# ============================================================

print_section(
    "COMPONENT-LEVEL ANALYSIS"
)

if not results_df.empty:

    for _, row in results_df.iterrows():

        experiment = (
            row["Experiment"]
        )

        if experiment == "A0_Full":
            continue

        delta_rmse = row.get(
            "Delta_RMSE_vs_Full",
            np.nan
        )

        degradation = row.get(
            "RMSE_Degradation_percent",
            np.nan
        )

        print(
            f"{experiment:25s}"
            f" Delta RMSE = "
            f"{delta_rmse:+.4f}"
            f" | Change = "
            f"{degradation:+.2f}%"
        )


# ============================================================
# 29. DATASET INFORMATION
# ============================================================

print_section(
    "DATASET INFORMATION"
)

print(
    "Dataset file:",
    DATA_FILE.name
)

print(
    "Total observations:",
    len(df)
)

print(
    "Target:",
    TARGET_COL
)

print(
    "Time column:",
    TIME_COL
)

print(
    "Target mean:",
    f"{df[TARGET_COL].mean():.4f}"
)

print(
    "Target std:",
    f"{df[TARGET_COL].std():.4f}"
)

print(
    "Target min:",
    f"{df[TARGET_COL].min():.4f}"
)

print(
    "Target max:",
    f"{df[TARGET_COL].max():.4f}"
)


# ============================================================
# 30. OUTPUT FILES
# ============================================================

print_header(
    "OUTPUT FILES"
)

print(
    "1.",
    results_file
)

print(
    "2.",
    predictions_file
)

print(
    "3.",
    features_file
)

print(
    "4.",
    OUTPUT_DIR
    / "feature_diagnostics_v2.csv"
)

print(
    "5.",
    OUTPUT_DIR
    / "prediction_diagnostics_v2.csv"
)

print(
    "6.",
    OUTPUT_DIR
    / "split_summary_v2.csv"
)


# ============================================================
# 31. COMPLETION
# ============================================================

print_header(
    "ABLATION STUDY V2 COMPLETED"
)

print(
    "The experiment finished successfully."
)

print(
    "Use ablation_results_v2.csv for the final "
    "ablation table after verification."
)

print(
    "Do NOT manually modify the numerical results."
)

print(
    "=" * 100
)