from pathlib import Path
import sys
import math
import itertools

import numpy as np
import pandas as pd


# =============================================================================
# CONFIGURATION
# =============================================================================

PROJECT_DIR = Path(__file__).resolve().parent

DATASET_PATH = PROJECT_DIR / "Journeys_2025_2026 .csv"
RESULTS_DIR = PROJECT_DIR / "tfl_ablation_results_v3"

EXPECTED_ROWS = 627

EXPECTED_START = pd.Timestamp("2025-01-01")
EXPECTED_END = pd.Timestamp("2026-09-19")

EXPECTED_SPLIT = {
    "Train": 438,
    "Validation": 94,
    "Test": 95,
}

EXPECTED_EXPERIMENTS = [
    "A0_Full",
    "A1_No_Calendar",
    "A2_No_Lag",
    "A3_No_Rolling",
    "A4_No_Exogenous",
    "A5_Minimal_AR",
    "A6_Calendar_Only",
]

EXPECTED_FEATURE_COUNTS = {
    "A0_Full": 35,
    "A1_No_Calendar": 22,
    "A2_No_Lag": 26,
    "A3_No_Rolling": 23,
    "A4_No_Exogenous": 34,
    "A5_Minimal_AR": 21,
    "A6_Calendar_Only": 13,
}

EXPECTED_NUMBERS = {
    "A0_Full": {
        "Validation_RMSE": 304115.9629,
        "Test_MAE": 122992.8835,
        "Test_RMSE": 162913.3525,
        "Test_R2": 0.8945,
    },
    "A1_No_Calendar": {
        "Validation_RMSE": 304466.4615,
        "Test_MAE": 112264.5886,
        "Test_RMSE": 142564.1887,
        "Test_R2": 0.9192,
    },
    "A2_No_Lag": {
        "Validation_RMSE": 344015.6989,
        "Test_MAE": 141651.3304,
        "Test_RMSE": 191072.4667,
        "Test_R2": 0.8548,
    },
    "A3_No_Rolling": {
        "Validation_RMSE": 286820.3981,
        "Test_MAE": 120734.2516,
        "Test_RMSE": 151573.3266,
        "Test_R2": 0.9086,
    },
    "A4_No_Exogenous": {
        "Validation_RMSE": 360413.0259,
        "Test_MAE": 177242.6063,
        "Test_RMSE": 246106.6856,
        "Test_R2": 0.7592,
    },
    "A5_Minimal_AR": {
        "Validation_RMSE": 424534.4888,
        "Test_MAE": 207047.6376,
        "Test_RMSE": 264677.1106,
        "Test_R2": 0.7214,
    },
    "A6_Calendar_Only": {
        "Validation_RMSE": 410610.6455,
        "Test_MAE": 245690.3867,
        "Test_RMSE": 583663.7013,
        "Test_R2": -0.3546,
    },
}


# IMPORTANT:
# These are the 13 calendar features that are actually intended to be used
# by the A6_Calendar_Only experiment.
EXPECTED_CALENDAR_FEATURES = [
    "year",
    "month",
    "day",
    "day_of_week",
    "day_of_year",
    "week_of_year",
    "is_weekend",
    "is_month_start",
    "is_month_end",
    "dow_sin",
    "dow_cos",
    "month_sin",
    "month_cos",
]

# These four diagnostics exist in the generated diagnostic file, but are
# constant because the dataset is daily and every timestamp is midnight.
EXPECTED_CONSTANT_CALENDAR_FEATURES = [
    "hour",
    "minute",
    "hour_sin",
    "hour_cos",
]

TOLERANCE = 0.1


# =============================================================================
# VERIFICATION STATE
# =============================================================================

PASS_COUNT = 0
WARNING_COUNT = 0
FAIL_COUNT = 0


def passed(message):
    global PASS_COUNT
    PASS_COUNT += 1
    print(f"[PASS] {message}")


def warning(message):
    global WARNING_COUNT
    WARNING_COUNT += 1
    print(f"[WARNING] {message}")


def failed(message):
    global FAIL_COUNT
    FAIL_COUNT += 1
    print(f"[FAIL] {message}")


def section(title):
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


def check_close(actual, expected, label, tolerance=TOLERANCE):
    if pd.isna(actual):
        failed(f"{label}: actual value is NaN.")
        return False

    if abs(float(actual) - float(expected)) <= tolerance:
        passed(
            f"{label}: {float(actual):.4f} vs expected {float(expected):.4f}."
        )
        return True

    failed(
        f"{label}: {float(actual):.4f} vs expected {float(expected):.4f}."
    )
    return False


def require_file(path, label):
    if path.exists():
        passed(f"{label} exists.")
        return True

    failed(f"{label} does not exist: {path}")
    return False


# =============================================================================
# START
# =============================================================================

print()
print("=" * 100)
print("TfL FORECASTING - ABLATION STUDY V3 VERIFICATION")
print("=" * 100)

print(f"Project directory : {PROJECT_DIR}")
print(f"Dataset           : {DATASET_PATH}")
print(f"Results directory : {RESULTS_DIR}")

if not require_file(DATASET_PATH, "Master dataset"):
    sys.exit(1)

if not RESULTS_DIR.exists():
    failed("V3 result directory does not exist.")
    sys.exit(1)

passed("V3 result directory exists.")


# =============================================================================
# 1. MASTER DATASET VERIFICATION
# =============================================================================

section("1. MASTER DATASET VERIFICATION")

try:
    df = pd.read_csv(DATASET_PATH)
except Exception as exc:
    failed(f"Could not load master dataset: {exc}")
    sys.exit(1)

print(f"Rows    : {len(df)}")
print(f"Columns : {len(df.columns)}")
print(f"Columns : {list(df.columns)}")

if len(df) == EXPECTED_ROWS:
    passed(f"Dataset row count = {len(df)}; expected {EXPECTED_ROWS}.")
else:
    failed(
        f"Dataset row count = {len(df)}; expected {EXPECTED_ROWS}."
    )

time_candidates = ["TravelDate", "Timestamp", "Date", "date"]
target_candidates = [
    "TubeJourneyCount",
    "tube_journey_count",
    "Target",
    "target",
]

time_col = next(
    (c for c in time_candidates if c in df.columns),
    None
)

target_col = next(
    (c for c in target_candidates if c in df.columns),
    None
)

if time_col:
    passed(f"Time column detected: {time_col}")
else:
    failed("Time column could not be detected.")

if target_col:
    passed(f"Target column detected: {target_col}")
else:
    failed("Target column could not be detected.")

if time_col is None or target_col is None:
    sys.exit(1)


# =============================================================================
# 2. DATE VALIDATION
# =============================================================================

section("2. DATE VALIDATION")

raw_dates = df[time_col].astype(str).str.strip()

parsed_dates = pd.to_datetime(
    raw_dates,
    format="%Y%m%d",
    errors="coerce"
)

parse_success = parsed_dates.notna().mean() * 100

print(f"Parse success rate : {parse_success:.2f}%")
print(f"Minimum date       : {parsed_dates.min()}")
print(f"Maximum date       : {parsed_dates.max()}")

if parse_success == 100:
    passed(f"YYYYMMDD parse success = {parse_success:.2f}%.")
else:
    failed(f"YYYYMMDD parse success = {parse_success:.2f}%.")

if parsed_dates.min() == EXPECTED_START:
    passed(
        f"Minimum date = {EXPECTED_START.date()}; "
        f"expected {EXPECTED_START.date()}."
    )
else:
    failed(
        f"Minimum date = {parsed_dates.min()}; "
        f"expected {EXPECTED_START.date()}."
    )

if parsed_dates.max() == EXPECTED_END:
    passed(
        f"Maximum date = {EXPECTED_END.date()}; "
        f"expected {EXPECTED_END.date()}."
    )
else:
    failed(
        f"Maximum date = {parsed_dates.max()}; "
        f"expected {EXPECTED_END.date()}."
    )

duplicate_count = parsed_dates.duplicated().sum()

print(f"Duplicate dates : {duplicate_count}")

if duplicate_count == 0:
    passed("Duplicate timestamps = 0.")
else:
    failed(f"Duplicate timestamps = {duplicate_count}.")

ordered = parsed_dates.is_monotonic_increasing

if ordered:
    passed("Dates are chronologically ordered.")
else:
    failed("Dates are not chronologically ordered.")

intervals = parsed_dates.sort_values().diff().dropna()

print()
print("Date interval distribution:")
print(intervals.value_counts().sort_index())

large_gaps = (intervals > pd.Timedelta(days=1)).sum()

print()
print(f"Gaps larger than one day: {large_gaps}")

if large_gaps == 0:
    passed("No gaps larger than one day were detected.")
else:
    failed(f"{large_gaps} gaps larger than one day were detected.")


# =============================================================================
# 3. TARGET VALIDATION
# =============================================================================

section("3. TARGET VALIDATION")

target_numeric = pd.to_numeric(df[target_col], errors="coerce")

target_mean = target_numeric.mean()
target_std = target_numeric.std()
target_min = target_numeric.min()
target_max = target_numeric.max()
missing_target = target_numeric.isna().sum()
zero_target = (target_numeric == 0).sum()
negative_target = (target_numeric < 0).sum()

print(f"Target mean : {target_mean:.4f}")
print(f"Target std  : {target_std:.4f}")
print(f"Target min  : {target_min:.4f}")
print(f"Target max  : {target_max:.4f}")
print(f"Missing     : {missing_target}")
print(f"Zeros       : {zero_target}")

if missing_target == 0:
    passed("Target contains no missing values.")
else:
    failed(f"Target contains {missing_target} missing values.")

if negative_target == 0:
    passed("Target contains no negative values.")
else:
    failed(f"Target contains {negative_target} negative values.")

if abs(target_mean - 3171084.5295) < 0.01:
    passed(
        f"Target mean matches V3 reported value: {target_mean:.4f}."
    )
else:
    failed(
        f"Target mean = {target_mean:.4f}; "
        f"expected 3171084.5295."
    )

if target_min == 0:
    passed("Target minimum is 0.")
else:
    failed(f"Target minimum = {target_min}; expected 0.")

if target_max == 4324000:
    passed("Target maximum is 4,324,000.")
else:
    failed(
        f"Target maximum = {target_max}; expected 4,324,000."
    )


# =============================================================================
# 4. TEMPORAL SPLIT VERIFICATION
# =============================================================================

section("4. TEMPORAL SPLIT VERIFICATION")

train_end = pd.Timestamp("2026-03-14")
validation_start = pd.Timestamp("2026-03-15")
validation_end = pd.Timestamp("2026-06-16")
test_start = pd.Timestamp("2026-06-17")

train_mask = parsed_dates <= train_end
validation_mask = (
    (parsed_dates >= validation_start)
    & (parsed_dates <= validation_end)
)
test_mask = parsed_dates >= test_start

train_df = df.loc[train_mask]
validation_df = df.loc[validation_mask]
test_df = df.loc[test_mask]

print(f"Train      : {len(train_df)}")
print(f"Validation : {len(validation_df)}")
print(f"Test       : {len(test_df)}")

print()
print("Train:")
print(f"  {parsed_dates[train_mask].min()} -> {parsed_dates[train_mask].max()}")

print()
print("Validation:")
print(
    f"  {parsed_dates[validation_mask].min()} -> "
    f"{parsed_dates[validation_mask].max()}"
)

print()
print("Test:")
print(f"  {parsed_dates[test_mask].min()} -> {parsed_dates[test_mask].max()}")

for split_name, actual, expected in [
    ("Training", len(train_df), EXPECTED_SPLIT["Train"]),
    ("Validation", len(validation_df), EXPECTED_SPLIT["Validation"]),
    ("Test", len(test_df), EXPECTED_SPLIT["Test"]),
]:
    if actual == expected:
        passed(
            f"{split_name} observations = {actual}; expected {expected}."
        )
    else:
        failed(
            f"{split_name} observations = {actual}; expected {expected}."
        )

if len(train_df) + len(validation_df) + len(test_df) == len(df):
    passed("Train + validation + test = total observations.")
else:
    failed("Train + validation + test != total observations.")

if train_end < validation_start:
    passed("Training period ends before validation period.")
else:
    failed("Training and validation periods overlap.")

if validation_end < test_start:
    passed("Validation period ends before test period.")
else:
    failed("Validation and test periods overlap.")

if train_end < test_start:
    passed("No temporal overlap between train and test.")
else:
    failed("Temporal overlap exists between train and test.")


# =============================================================================
# LOAD RESULT FILES
# =============================================================================

ablation_path = RESULTS_DIR / "ablation_results_v3.csv"
predictions_path = RESULTS_DIR / "ablation_predictions_v3.csv"
feature_diag_path = RESULTS_DIR / "feature_diagnostics_v3.csv"
calendar_diag_path = RESULTS_DIR / "calendar_feature_diagnostics_v3.csv"
split_path = RESULTS_DIR / "split_summary_v3.csv"
date_validation_path = RESULTS_DIR / "date_validation_v3.csv"


# =============================================================================
# 5. ABLATION RESULTS FILE
# =============================================================================

section("5. ABLATION RESULTS FILE")

if not require_file(ablation_path, "ablation_results_v3.csv"):
    sys.exit(1)

ablation = pd.read_csv(ablation_path)

print(
    f"[PASS] Loaded ablation_results_v3.csv: "
    f"{ablation.shape[0]} rows x {ablation.shape[1]} columns"
)

print()
print("Result columns:")
for col in ablation.columns:
    print(f"  - {col}")

required_columns = [
    "Experiment",
    "Feature_Count",
    "Test_RMSE",
    "Validation_RMSE",
    "Test_R2",
    "Test_MAE",
]

for col in required_columns:
    if col in ablation.columns:
        passed(f"{col} column exists.")
    else:
        failed(f"{col} column is missing.")


# =============================================================================
# 6. EXPERIMENT COVERAGE
# =============================================================================

section("6. EXPERIMENT COVERAGE")

found_experiments = ablation["Experiment"].astype(str).tolist()

print("Experiments found:")
for exp in found_experiments:
    print(f"  - {exp}")

missing_experiments = [
    exp for exp in EXPECTED_EXPERIMENTS
    if exp not in found_experiments
]

unexpected_experiments = [
    exp for exp in found_experiments
    if exp not in EXPECTED_EXPERIMENTS
]

if not missing_experiments:
    passed("No expected experiments are missing: [].")
else:
    failed(
        f"Missing expected experiments: {missing_experiments}"
    )

if not unexpected_experiments:
    passed("No unexpected experiments found: [].")
else:
    failed(
        f"Unexpected experiments found: {unexpected_experiments}"
    )

if len(found_experiments) == 7:
    passed("Experiment count = 7; expected 7.")
else:
    failed(
        f"Experiment count = {len(found_experiments)}; expected 7."
    )


# =============================================================================
# 7. FEATURE COUNT VERIFICATION
# =============================================================================

section("7. FEATURE COUNT VERIFICATION")

for experiment, expected_count in EXPECTED_FEATURE_COUNTS.items():

    row = ablation.loc[
        ablation["Experiment"] == experiment
    ]

    if row.empty:
        failed(
            f"{experiment}: experiment row not found."
        )
        continue

    actual_count = int(row.iloc[0]["Feature_Count"])

    if actual_count == expected_count:
        passed(
            f"{experiment}: feature count = "
            f"{actual_count}; expected {expected_count}."
        )
    else:
        failed(
            f"{experiment}: feature count = "
            f"{actual_count}; expected {expected_count}."
        )


# =============================================================================
# 8. NUMERICAL SANITY CHECKS
# =============================================================================

section("8. NUMERICAL SANITY CHECKS")

numeric_columns = [
    "Validation_RMSE",
    "Test_MAE",
    "Test_RMSE",
    "Test_R2",
]

for col in numeric_columns:

    numeric = pd.to_numeric(
        ablation[col],
        errors="coerce"
    )

    if numeric.notna().all():
        passed(f"{col}: all values are numeric.")
    else:
        failed(f"{col}: non-numeric values detected.")

    if np.isfinite(numeric).all():
        passed(f"{col}: all values are finite.")
    else:
        failed(f"{col}: non-finite values detected.")

test_r2 = pd.to_numeric(
    ablation["Test_R2"],
    errors="coerce"
)

print()
print("Test R2 range:")
print(f"  Min = {test_r2.min():.4f}")
print(f"  Max = {test_r2.max():.4f}")

if (test_r2 <= 1).all():
    passed("All Test R2 values <= 1.")
else:
    failed("At least one Test R2 value is > 1.")


# =============================================================================
# 9. VERIFY REPORTED V3 NUMBERS
# =============================================================================

section("9. VERIFY REPORTED V3 NUMBERS")

for experiment, expected_values in EXPECTED_NUMBERS.items():

    row = ablation.loc[
        ablation["Experiment"] == experiment
    ]

    if row.empty:
        failed(
            f"{experiment}: row missing from ablation results."
        )
        continue

    row = row.iloc[0]

    for metric, expected in expected_values.items():
        actual = float(row[metric])

        check_close(
            actual,
            expected,
            f"{experiment} {metric}"
        )


# =============================================================================
# 10. DELTA RMSE VERIFICATION
# =============================================================================

section("10. DELTA RMSE VERIFICATION")

full_row = ablation.loc[
    ablation["Experiment"] == "A0_Full"
].iloc[0]

full_rmse = float(full_row["Test_RMSE"])

print(f"A0_Full Test RMSE = {full_rmse:.4f}")

for _, row in ablation.iterrows():

    experiment = row["Experiment"]

    actual_rmse = float(row["Test_RMSE"])

    stored_delta = float(
        row["Delta_RMSE_vs_Full"]
    )

    recalculated_delta = actual_rmse - full_rmse

    if abs(stored_delta - recalculated_delta) <= TOLERANCE:
        passed(
            f"{experiment}: Delta RMSE = "
            f"{stored_delta:.4f}; recalculated = "
            f"{recalculated_delta:.4f}."
        )
    else:
        failed(
            f"{experiment}: Delta RMSE = "
            f"{stored_delta:.4f}; recalculated = "
            f"{recalculated_delta:.4f}."
        )

    stored_change = float(
        row["RMSE_Change_percent_vs_Full"]
    )

    if full_rmse != 0:
        recalculated_change = (
            (actual_rmse - full_rmse)
            / full_rmse
            * 100
        )
    else:
        recalculated_change = np.nan

    if abs(stored_change - recalculated_change) <= TOLERANCE:
        passed(
            f"{experiment}: RMSE change = "
            f"{stored_change:.4f}%; recalculated = "
            f"{recalculated_change:.4f}%."
        )
    else:
        failed(
            f"{experiment}: RMSE change = "
            f"{stored_change:.4f}%; recalculated = "
            f"{recalculated_change:.4f}%."
        )


# =============================================================================
# 11. PREDICTION FILE VERIFICATION
# =============================================================================

section("11. PREDICTION FILE VERIFICATION")

if not require_file(
    predictions_path,
    "ablation_predictions_v3.csv"
):
    sys.exit(1)

predictions = pd.read_csv(predictions_path)

print(
    f"[PASS] Loaded ablation_predictions_v3.csv: "
    f"{predictions.shape[0]} rows x "
    f"{predictions.shape[1]} columns"
)

print()
print("Prediction columns:")
for col in predictions.columns:
    print(f"  - {col}")

required_prediction_columns = [
    "Experiment",
    "Timestamp",
    "Actual",
    "Predicted",
    "Residual",
]

for col in required_prediction_columns:
    if col in predictions.columns:
        passed(
            f"Prediction file contains {col} column."
        )
    else:
        failed(
            f"Prediction file is missing {col} column."
        )

prediction_experiments = sorted(
    predictions["Experiment"].unique()
)

expected_sorted = sorted(EXPECTED_EXPERIMENTS)

if prediction_experiments == expected_sorted:
    passed(
        "Prediction file contains exactly the seven expected experiments."
    )
else:
    failed(
        "Prediction experiment set does not match expected experiments."
    )

print()
print("Prediction counts by experiment:")
print(predictions["Experiment"].value_counts())

for exp in EXPECTED_EXPERIMENTS:
    count = (
        predictions["Experiment"] == exp
    ).sum()

    if count == EXPECTED_SPLIT["Test"]:
        passed(
            f"{exp}: prediction count = {count}; "
            f"expected {EXPECTED_SPLIT['Test']}."
        )
    else:
        failed(
            f"{exp}: prediction count = {count}; "
            f"expected {EXPECTED_SPLIT['Test']}."
        )

actual_numeric = pd.to_numeric(
    predictions["Actual"],
    errors="coerce"
)

pred_numeric = pd.to_numeric(
    predictions["Predicted"],
    errors="coerce"
)

if actual_numeric.notna().all():
    passed(
        "Actual values contain no missing/non-numeric values."
    )
else:
    failed(
        "Actual values contain missing/non-numeric values."
    )

if pred_numeric.notna().all():
    passed(
        "Predictions contain no missing/non-numeric values."
    )
else:
    failed(
        "Predictions contain missing/non-numeric values."
    )

if np.isfinite(pred_numeric).all():
    passed("Predictions contain only finite values.")
else:
    failed("Predictions contain non-finite values.")

prediction_dates = pd.to_datetime(
    predictions["Timestamp"],
    errors="coerce"
)

if prediction_dates.notna().all():
    passed("Prediction dates are parseable.")
else:
    failed("Prediction dates contain unparseable values.")

print(
    f"Prediction date range: "
    f"{prediction_dates.min()} -> "
    f"{prediction_dates.max()}"
)


# =============================================================================
# 12. IDENTICAL-PREDICTION CHECK
# =============================================================================

section("12. IDENTICAL-PREDICTION CHECK")

prediction_pivot = predictions.pivot(
    index="Timestamp",
    columns="Experiment",
    values="Predicted"
)

for exp1, exp2 in itertools.combinations(
    EXPECTED_EXPERIMENTS,
    2
):

    if exp1 not in prediction_pivot.columns:
        continue

    if exp2 not in prediction_pivot.columns:
        continue

    difference = (
        prediction_pivot[exp1]
        - prediction_pivot[exp2]
    ).abs()

    max_difference = difference.max()

    if max_difference > 1e-9:
        passed(
            f"{exp1} vs {exp2}: "
            f"max difference = {max_difference:.6f}"
        )
    else:
        warning(
            f"{exp1} vs {exp2}: predictions are identical."
        )


# =============================================================================
# 13. FEATURE DIAGNOSTICS
# =============================================================================

section("13. FEATURE DIAGNOSTICS")

if not require_file(
    feature_diag_path,
    "feature_diagnostics_v3.csv"
):
    sys.exit(1)

feature_diag = pd.read_csv(feature_diag_path)

print(
    f"[PASS] Loaded feature_diagnostics_v3.csv: "
    f"{feature_diag.shape[0]} rows x "
    f"{feature_diag.shape[1]} columns"
)

print()
print("Feature diagnostic columns:")
for col in feature_diag.columns:
    print(f"  - {col}")

required_feature_diag_columns = [
    "Experiment",
    "Feature_Count",
    "Variable_Feature_Count",
    "Constant_Feature_Count",
    "Constant_Features",
    "Missing_Cells",
    "Train_Rows",
    "Validation_Rows",
    "Test_Rows",
]

for col in required_feature_diag_columns:
    if col in feature_diag.columns:
        continue

    failed(
        f"Feature diagnostic column missing: {col}"
    )

print()
print("Feature diagnostics:")
print(feature_diag.to_string(index=False))

if (
    "Constant_Feature_Count" in feature_diag.columns
    and
    (feature_diag["Constant_Feature_Count"] == 0).all()
):
    passed(
        "No constant features are reported in V3 diagnostics."
    )
else:
    failed(
        "One or more constant features are reported in V3 diagnostics."
    )

if (
    "Missing_Cells" in feature_diag.columns
    and
    (feature_diag["Missing_Cells"] >= 0).all()
):
    passed(
        "Missing-value diagnostic counts are non-negative."
    )
else:
    failed(
        "Negative missing-value diagnostic count detected."
    )


# =============================================================================
# 14. CALENDAR FEATURE DIAGNOSTICS
# =============================================================================

section("14. CALENDAR FEATURE DIAGNOSTICS")

if not require_file(
    calendar_diag_path,
    "calendar_feature_diagnostics_v3.csv"
):
    sys.exit(1)

calendar_diag = pd.read_csv(calendar_diag_path)

print(
    f"[PASS] Loaded calendar_feature_diagnostics_v3.csv: "
    f"{calendar_diag.shape[0]} rows x "
    f"{calendar_diag.shape[1]} columns"
)

required_calendar_columns = [
    "Feature",
    "Unique_Values",
    "Minimum",
    "Maximum",
    "Constant",
]

for col in required_calendar_columns:
    if col in calendar_diag.columns:
        continue

    failed(
        f"Calendar diagnostic column missing: {col}"
    )

print()
print("Calendar diagnostics:")
print(calendar_diag.to_string(index=False))


# -----------------------------------------------------------------------------
# FIXED V3 CALENDAR VERIFICATION
# -----------------------------------------------------------------------------
#
# The diagnostic file contains 17 generated calendar variables.
# Four are constant because the data are daily observations at midnight:
#
#   hour       = 0
#   minute     = 0
#   hour_sin   = 0
#   hour_cos   = 1
#
# Therefore:
#
#   17 diagnostic calendar variables
# -  4 constant variables
# = 13 effective calendar features
#
# A6_Calendar_Only uses these 13 non-constant features.
# -----------------------------------------------------------------------------

calendar_features_found = (
    calendar_diag["Feature"]
    .astype(str)
    .tolist()
)

constant_features = calendar_diag.loc[
    calendar_diag["Constant"] == True,
    "Feature"
].astype(str).tolist()

variable_features = calendar_diag.loc[
    calendar_diag["Constant"] == False,
    "Feature"
].astype(str).tolist()

print()
print(
    f"Calendar diagnostic features found : "
    f"{len(calendar_features_found)}"
)

print(
    f"Constant calendar features         : "
    f"{len(constant_features)}"
)

print(
    f"Variable calendar features         : "
    f"{len(variable_features)}"
)

print()
print("Constant calendar features:")
for feature in constant_features:
    print(f"  - {feature}")

print()
print("Effective calendar features:")
for feature in variable_features:
    print(f"  - {feature}")


# Check total generated calendar diagnostics.
if len(calendar_features_found) == 17:
    passed(
        "Calendar diagnostic file contains 17 generated calendar variables."
    )
else:
    failed(
        f"Calendar diagnostic feature count = "
        f"{len(calendar_features_found)}; expected 17."
    )


# Check constant features exactly.
if set(constant_features) == set(
    EXPECTED_CONSTANT_CALENDAR_FEATURES
):
    passed(
        "The four expected constant calendar features are correctly "
        "identified."
    )
else:
    failed(
        "Constant calendar feature set does not match the expected "
        "four features."
    )


# Check effective variable calendar feature set.
if set(variable_features) == set(
    EXPECTED_CALENDAR_FEATURES
):
    passed(
        "Effective calendar feature list matches the expected "
        "V3 13-feature set."
    )
else:
    missing_calendar = [
        x for x in EXPECTED_CALENDAR_FEATURES
        if x not in variable_features
    ]

    unexpected_calendar = [
        x for x in variable_features
        if x not in EXPECTED_CALENDAR_FEATURES
    ]

    failed(
        "Effective calendar feature list does not match the expected "
        f"V3 13-feature set. "
        f"Missing={missing_calendar}; "
        f"Unexpected={unexpected_calendar}"
    )


# Check that A6 really has 13 features.
a6_row = ablation.loc[
    ablation["Experiment"] == "A6_Calendar_Only"
]

if not a6_row.empty:
    a6_count = int(a6_row.iloc[0]["Feature_Count"])

    if a6_count == len(EXPECTED_CALENDAR_FEATURES):
        passed(
            "A6_Calendar_Only feature count is consistent with "
            "the 13 effective calendar features."
        )
    else:
        failed(
            f"A6_Calendar_Only feature count = {a6_count}; "
            f"expected {len(EXPECTED_CALENDAR_FEATURES)}."
        )


# =============================================================================
# 15. SPLIT SUMMARY VERIFICATION
# =============================================================================

section("15. SPLIT SUMMARY VERIFICATION")

if not require_file(
    split_path,
    "split_summary_v3.csv"
):
    sys.exit(1)

split_summary = pd.read_csv(split_path)

print(
    f"[PASS] Loaded split_summary_v3.csv: "
    f"{split_summary.shape[0]} rows x "
    f"{split_summary.shape[1]} columns"
)

print()
print("Split summary:")
print(split_summary.to_string(index=False))

for split_name, expected_rows in EXPECTED_SPLIT.items():

    row = split_summary.loc[
        split_summary["Split"] == split_name
    ]

    if row.empty:
        failed(
            f"Split summary missing {split_name}."
        )
        continue

    actual_rows = int(row.iloc[0]["Rows"])

    if actual_rows == expected_rows:
        passed(
            f"Split summary contains the expected "
            f"{split_name.lower()} size ({expected_rows})."
        )
    else:
        failed(
            f"Split summary {split_name} size = "
            f"{actual_rows}; expected {expected_rows}."
        )


# =============================================================================
# 16. DATE VALIDATION OUTPUT
# =============================================================================

section("16. DATE VALIDATION OUTPUT")

if not require_file(
    date_validation_path,
    "date_validation_v3.csv"
):
    sys.exit(1)

date_validation = pd.read_csv(date_validation_path)

print(
    f"[PASS] Loaded date_validation_v3.csv: "
    f"{date_validation.shape[0]} rows x "
    f"{date_validation.shape[1]} columns"
)

print()
print("Date validation:")
print(date_validation.head(20).to_string(index=False))

if len(date_validation) == EXPECTED_ROWS:
    passed(
        f"Date validation row count = {len(date_validation)}; "
        f"expected {EXPECTED_ROWS}."
    )
else:
    failed(
        f"Date validation row count = {len(date_validation)}; "
        f"expected {EXPECTED_ROWS}."
    )

raw_date_strings = (
    date_validation.iloc[:, 0]
    .astype(str)
    .str.strip()
)

parsed_validation_dates = pd.to_datetime(
    date_validation.iloc[:, 1],
    errors="coerce"
)

if EXPECTED_START.strftime("%Y-%m-%d") in (
    parsed_validation_dates.dt.strftime("%Y-%m-%d").tolist()
):
    passed("Date validation contains expected start date.")
else:
    failed(
        "Date validation does not contain expected start date."
    )

if EXPECTED_END.strftime("%Y-%m-%d") in (
    parsed_validation_dates.dt.strftime("%Y-%m-%d").tolist()
):
    passed("Date validation contains expected end date.")
else:
    failed(
        "Date validation does not contain expected end date."
    )


# =============================================================================
# 17. MANUSCRIPT-READY ABLATION TABLE
# =============================================================================

section("17. MANUSCRIPT-READY ABLATION TABLE")

manuscript_columns = [
    "Experiment",
    "Feature_Count",
    "Validation_RMSE",
    "Validation_R2",
    "Test_MAE",
    "Test_RMSE",
    "Test_R2",
    "Test_MAPE_percent",
    "Test_sMAPE_percent",
    "Delta_RMSE_vs_Full",
    "RMSE_Change_percent_vs_Full",
]

available_columns = [
    col for col in manuscript_columns
    if col in ablation.columns
]

manuscript_table = (
    ablation[available_columns]
    .copy()
    .sort_values("Test_RMSE")
)

print(
    manuscript_table.to_string(index=False)
)

manuscript_path = (
    RESULTS_DIR /
    "MANUSCRIPT_ABLATION_TABLE_V3.csv"
)

manuscript_table.to_csv(
    manuscript_path,
    index=False
)

print()
print("[INFO] Manuscript table created:")
print(manuscript_path)


# =============================================================================
# 18. INTERPRETATION CHECKS
# =============================================================================

section("18. INTERPRETATION CHECKS")

rmse_order = (
    ablation[
        ["Experiment", "Test_RMSE"]
    ]
    .sort_values("Test_RMSE")
)

print()
print("Test RMSE by experiment:")
print(
    rmse_order
    .set_index("Experiment")
    .to_string()
)

a0_rmse = float(
    ablation.loc[
        ablation["Experiment"] == "A0_Full",
        "Test_RMSE"
    ].iloc[0]
)

a1_rmse = float(
    ablation.loc[
        ablation["Experiment"] == "A1_No_Calendar",
        "Test_RMSE"
    ].iloc[0]
)

a3_rmse = float(
    ablation.loc[
        ablation["Experiment"] == "A3_No_Rolling",
        "Test_RMSE"
    ].iloc[0]
)

print()
print("Important V3 observations:")
print(f"  A0 Full RMSE            : {a0_rmse:.4f}")
print(f"  A1 No Calendar RMSE     : {a1_rmse:.4f}")
print(f"  A3 No Rolling RMSE      : {a3_rmse:.4f}")

if a1_rmse < a0_rmse:
    print(
        "  [INFO] A1_No_Calendar has lower test RMSE than A0_Full."
    )

if a3_rmse < a0_rmse:
    print(
        "  [INFO] A3_No_Rolling has lower test RMSE than A0_Full."
    )

print()
print(
    "  These are empirical ablation results. They should be "
    "reported descriptively rather than claiming that every "
    "component necessarily improves the model."
)


# =============================================================================
# FINAL REPORT
# =============================================================================

section("FINAL VERIFICATION REPORT")

print(f"PASS checks    : {PASS_COUNT}")
print(f"WARNING checks : {WARNING_COUNT}")
print(f"FAIL checks    : {FAIL_COUNT}")

print()
print("Verification status:")

if FAIL_COUNT == 0:
    print("  STATUS: PASS")
    print()
    print(
        "All critical V3 verification checks passed."
    )
    print(
        "The V3 numerical results and generated diagnostic files "
        "are internally consistent."
    )
else:
    print("  STATUS: FAIL")
    print()
    print(
        "One or more critical verification checks failed."
    )
    print(
        "Do NOT use the V3 numerical results in the manuscript "
        "until the failed checks are investigated."
    )


print()
print("=" * 100)
print("VERIFICATION OUTPUT")
print("=" * 100)

print()
print("Original V3 files were NOT modified.")

print()
print("V3 result files:")

if RESULTS_DIR.exists():
    for path in sorted(RESULTS_DIR.iterdir()):
        if path.is_file():
            print(f"  - {path.name}")

print()
print("Verification completed.")

if FAIL_COUNT > 0:
    sys.exit(1)

sys.exit(0)