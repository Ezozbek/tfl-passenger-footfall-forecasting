from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# 1. PATHS
# ============================================================

BASE_DIR = Path(
    r"c:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

MASTER_FILE = (
    BASE_DIR
    / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)

OUTPUT_DIR = BASE_DIR / "tfl_calendar_ml"
OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 2. LOAD ORIGINAL MASTER
# ============================================================

print("=" * 100)
print("LOADING MASTER DATASET")
print("=" * 100)

df = pd.read_csv(
    MASTER_FILE,
    parse_dates=["TravelDate"],
    low_memory=False
)

print(f"Rows    : {len(df):,}")
print(f"Stations: {df['Station'].nunique():,}")
print(
    f"Date    : "
    f"{df['TravelDate'].min().date()} "
    f"-> "
    f"{df['TravelDate'].max().date()}"
)


# ============================================================
# 3. KEEP CORE VARIABLES
# ============================================================

CORE_COLUMNS = [
    "TravelDate",
    "Station",
    "DayOfWeek",
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",
    "EntryTapCount",
    "ExitTapCount",
    "TotalFootfall",
]

df = df[CORE_COLUMNS].copy()


# ============================================================
# 4. SORT
# ============================================================

df = df.sort_values(
    ["Station", "TravelDate"]
).reset_index(drop=True)


# ============================================================
# 5. CHECK DUPLICATE STATION-DATE
# ============================================================

duplicates = df.duplicated(
    subset=["Station", "TravelDate"]
).sum()

print("\nDuplicate Station-Date rows:", duplicates)

if duplicates > 0:
    raise ValueError(
        "Duplicate Station-Date records detected."
    )


# ============================================================
# 6. CREATE CALENDAR-AWARE LAGS
# ============================================================

print("\nCreating calendar-aware lag features...")

# ------------------------------------------------------------
# Create a lookup table:
#
# (Station, TravelDate) -> TotalFootfall
# ------------------------------------------------------------

target_lookup = (
    df[
        [
            "Station",
            "TravelDate",
            "TotalFootfall"
        ]
    ]
    .rename(
        columns={
            "TotalFootfall": "PreviousFootfall"
        }
    )
)


# ------------------------------------------------------------
# Lag 1
# ------------------------------------------------------------

for lag_days in [1, 7, 14, 28]:

    lag_table = target_lookup.copy()

    lag_table["TravelDate"] = (
        lag_table["TravelDate"]
        + pd.Timedelta(days=lag_days)
    )

    lag_table = lag_table.rename(
        columns={
            "PreviousFootfall":
                f"Lag_{lag_days}"
        }
    )

    df = df.merge(
        lag_table,
        on=["Station", "TravelDate"],
        how="left"
    )


# ============================================================
# 7. CALENDAR-AWARE ROLLING FEATURES
# ============================================================

print("Creating calendar-aware rolling features...")

# We calculate rolling values from actual previous
# calendar observations only.

daily_index = (
    df[
        [
            "Station",
            "TravelDate",
            "TotalFootfall"
        ]
    ]
    .set_index("TravelDate")
)

rolling_results = []

for station, station_df in df.groupby("Station"):

    station_df = station_df[
        [
            "TravelDate",
            "TotalFootfall"
        ]
    ].copy()

    station_df = station_df.set_index(
        "TravelDate"
    )

    # Shift one day in observation time:
    # today's target is NEVER included.
    previous_day = station_df[
        "TotalFootfall"
    ].shift(1)

    rolling = pd.DataFrame(index=station_df.index)

    rolling["RollingMean_7"] = (
        previous_day
        .rolling(
            "7D",
            min_periods=3
        )
        .mean()
    )

    rolling["RollingStd_7"] = (
        previous_day
        .rolling(
            "7D",
            min_periods=3
        )
        .std()
    )

    rolling["RollingMean_14"] = (
        previous_day
        .rolling(
            "14D",
            min_periods=5
        )
        .mean()
    )

    rolling["RollingMean_28"] = (
        previous_day
        .rolling(
            "28D",
            min_periods=7
        )
        .mean()
    )

    rolling["Station"] = station
    rolling["TravelDate"] = rolling.index

    rolling_results.append(
        rolling.reset_index(drop=True)
    )


rolling_df = pd.concat(
    rolling_results,
    ignore_index=True
)


# ============================================================
# 8. MERGE ROLLING FEATURES
# ============================================================

rolling_df = rolling_df[
    [
        "Station",
        "TravelDate",
        "RollingMean_7",
        "RollingStd_7",
        "RollingMean_14",
        "RollingMean_28",
    ]
]

df = df.merge(
    rolling_df,
    on=["Station", "TravelDate"],
    how="left"
)


# ============================================================
# 9. VERIFY LAGS MANUALLY
# ============================================================

print("\n" + "=" * 100)
print("VERIFYING CALENDAR-AWARE LAGS")
print("=" * 100)

test_station = (
    df["Station"]
    .value_counts()
    .index[0]
)

check = (
    df[df["Station"] == test_station]
    .sort_values("TravelDate")
    [
        [
            "TravelDate",
            "TotalFootfall",
            "Lag_1",
            "Lag_7",
            "Lag_14",
            "Lag_28"
        ]
    ]
    .head(40)
)

print(
    check.to_string(index=False)
)


# ============================================================
# 10. LAG AVAILABILITY
# ============================================================

print("\n" + "=" * 100)
print("LAG AVAILABILITY")
print("=" * 100)

lag_columns = [
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

lag_report = []

for col in lag_columns:

    missing = df[col].isna().sum()

    available = len(df) - missing

    lag_report.append(
        {
            "Feature": col,
            "Missing": missing,
            "Available": available,
            "Available_%": round(
                available / len(df) * 100,
                3
            )
        }
    )

lag_report = pd.DataFrame(
    lag_report
)

print(
    lag_report.to_string(
        index=False
    )
)

lag_report.to_csv(
    OUTPUT_DIR / "calendar_lag_report.csv",
    index=False
)


# ============================================================
# 11. REMOVE ROWS WITHOUT REQUIRED HISTORY
# ============================================================

REQUIRED_LAGS = [
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

ml_df = df.dropna(
    subset=REQUIRED_LAGS
).copy()


# ============================================================
# 12. TEMPORAL SPLIT
# ============================================================

train = ml_df[
    ml_df["TravelDate"].dt.year == 2023
].copy()

validation = ml_df[
    ml_df["TravelDate"].dt.year == 2024
].copy()

test = ml_df[
    ml_df["TravelDate"] >= pd.Timestamp(
        "2025-01-01"
    )
].copy()


# ============================================================
# 13. FINAL REPORT
# ============================================================

print("\n" + "=" * 100)
print("FINAL CALENDAR-AWARE ML DATASET")
print("=" * 100)

print(f"Total ML rows: {len(ml_df):,}")

print(
    f"Train      : {len(train):,}"
)

print(
    f"Validation : {len(validation):,}"
)

print(
    f"Test       : {len(test):,}"
)

print(
    f"Stations   : {ml_df['Station'].nunique():,}"
)

print(
    f"Date       : "
    f"{ml_df['TravelDate'].min().date()} "
    f"-> "
    f"{ml_df['TravelDate'].max().date()}"
)


# ============================================================
# 14. SAVE COMPLETE DATASET
# ============================================================

MASTER_OUTPUT = (
    OUTPUT_DIR
    / "TfL_CalendarAware_Master_2023_2026.csv"
)

ml_df.to_csv(
    MASTER_OUTPUT,
    index=False,
    encoding="utf-8"
)


# ============================================================
# 15. SAVE PARQUET
# ============================================================

PARQUET_OUTPUT = (
    OUTPUT_DIR
    / "TfL_CalendarAware_Master_2023_2026.parquet"
)

ml_df.to_parquet(
    PARQUET_OUTPUT,
    index=False
)


# ============================================================
# 16. SAVE TRAIN / VALIDATION / TEST
# ============================================================

train.to_csv(
    OUTPUT_DIR / "train_2023.csv",
    index=False
)

validation.to_csv(
    OUTPUT_DIR / "validation_2024.csv",
    index=False
)

test.to_csv(
    OUTPUT_DIR / "test_2025_2026.csv",
    index=False
)


# ============================================================
# 17. SAVE FEATURE CONFIGURATION
# ============================================================

FEATURES = [
    "Station",
    "DayOfWeek",
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

feature_config = pd.DataFrame({
    "Feature": FEATURES,
    "Type": [
        "Categorical",
        "Categorical",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Binary",
        "Lag",
        "Lag",
        "Lag",
        "Lag",
        "Rolling",
        "Rolling",
        "Rolling",
        "Rolling",
    ]
})

feature_config.to_csv(
    OUTPUT_DIR / "feature_configuration.csv",
    index=False
)


# ============================================================
# 18. COMPLETION
# ============================================================

print("\n" + "#" * 100)
print("CALENDAR-AWARE PREPARATION COMPLETED")
print("#" * 100)

print("\nMaster:")
print(MASTER_OUTPUT)

print("\nParquet:")
print(PARQUET_OUTPUT)

print("\nTrain:")
print(OUTPUT_DIR / "train_2023.csv")

print("\nValidation:")
print(OUTPUT_DIR / "validation_2024.csv")

print("\nTest:")
print(OUTPUT_DIR / "test_2025_2026.csv")

print("\nNEXT STEP:")
print(
    "Run baseline forecasting models "
    "using the calendar-aware dataset."
)