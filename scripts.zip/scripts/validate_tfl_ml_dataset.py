from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# 1. PATHS
# ============================================================

BASE_DIR = Path(
    r"c:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

MASTER_FILE = (
    BASE_DIR
    / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)

OUTPUT_DIR = BASE_DIR / "tfl_ml_validation"
OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 2. LOAD MASTER DATASET
# ============================================================

print("=" * 100)
print("LOADING MASTER DATASET")
print("=" * 100)

df = pd.read_csv(
    MASTER_FILE,
    parse_dates=["TravelDate"],
    low_memory=False
)

print(f"Rows    : {len(df):,}")
print(f"Columns : {len(df.columns)}")
print(f"Stations: {df['Station'].nunique():,}")
print(
    f"Date    : "
    f"{df['TravelDate'].min().date()} "
    f"-> "
    f"{df['TravelDate'].max().date()}"
)


# ============================================================
# 3. BASIC DATA INTEGRITY
# ============================================================

print("\n" + "=" * 100)
print("3. BASIC DATA INTEGRITY")
print("=" * 100)

duplicate_station_date = (
    df.duplicated(
        subset=["Station", "TravelDate"]
    )
    .sum()
)

print(
    f"Duplicate Station-Date rows: "
    f"{duplicate_station_date:,}"
)

negative_entries = (
    df["EntryTapCount"] < 0
).sum()

negative_exits = (
    df["ExitTapCount"] < 0
).sum()

negative_target = (
    df["TotalFootfall"] < 0
).sum()

print(f"Negative EntryTapCount : {negative_entries:,}")
print(f"Negative ExitTapCount  : {negative_exits:,}")
print(f"Negative TotalFootfall : {negative_target:,}")


# ============================================================
# 4. STATION-DATE CONTINUITY CHECK
# ============================================================

print("\n" + "=" * 100)
print("4. STATION-DATE CONTINUITY CHECK")
print("=" * 100)

df = df.sort_values(
    ["Station", "TravelDate"]
).reset_index(drop=True)

df["DateDiff"] = (
    df.groupby("Station")["TravelDate"]
    .diff()
    .dt.days
)

gap_rows = df[
    df["DateDiff"] > 1
].copy()

print(
    f"Rows immediately following a date gap: "
    f"{len(gap_rows):,}"
)

if len(gap_rows) > 0:

    gap_summary = (
        gap_rows.groupby("Station")
        .agg(
            Number_of_Gaps=("DateDiff", "count"),
            Max_Gap_Days=("DateDiff", "max")
        )
        .reset_index()
        .sort_values(
            "Number_of_Gaps",
            ascending=False
        )
    )

    print("\nStations with missing calendar dates:")
    print(
        gap_summary.head(20).to_string(
            index=False
        )
    )

    gap_summary.to_csv(
        OUTPUT_DIR / "station_date_gaps.csv",
        index=False
    )

else:

    print(
        "No calendar-date gaps detected "
        "within station histories."
    )


# ============================================================
# 5. OBSERVATIONS PER STATION
# ============================================================

print("\n" + "=" * 100)
print("5. OBSERVATIONS PER STATION")
print("=" * 100)

station_counts = (
    df.groupby("Station")
    .agg(
        Observations=("TravelDate", "size"),
        First_Date=("TravelDate", "min"),
        Last_Date=("TravelDate", "max")
    )
    .reset_index()
)

station_counts["Expected_Days"] = (
    station_counts["Last_Date"]
    - station_counts["First_Date"]
).dt.days + 1

station_counts["Coverage_Ratio"] = (
    station_counts["Observations"]
    / station_counts["Expected_Days"]
)

print(
    station_counts[
        [
            "Observations",
            "Expected_Days",
            "Coverage_Ratio"
        ]
    ].describe().to_string()
)

station_counts.to_csv(
    OUTPUT_DIR / "station_coverage.csv",
    index=False
)


# ============================================================
# 6. TARGET STATISTICS
# ============================================================

print("\n" + "=" * 100)
print("6. TARGET STATISTICS")
print("=" * 100)

target_stats = (
    df["TotalFootfall"]
    .describe()
)

print(target_stats.to_string())

print("\nTarget quantiles:")

print(
    df["TotalFootfall"]
    .quantile(
        [0.01, 0.05, 0.25, 0.50, 0.75, 0.95, 0.99]
    )
    .to_string()
)


# ============================================================
# 7. YEAR DISTRIBUTION
# ============================================================

print("\n" + "=" * 100)
print("7. YEAR DISTRIBUTION")
print("=" * 100)

year_distribution = (
    df.groupby("Year")
    .agg(
        Rows=("TotalFootfall", "size"),
        Stations=("Station", "nunique"),
        Mean_Demand=("TotalFootfall", "mean"),
        Median_Demand=("TotalFootfall", "median"),
        Total_Entries=("EntryTapCount", "sum"),
        Total_Exits=("ExitTapCount", "sum")
    )
    .reset_index()
)

print(
    year_distribution.to_string(
        index=False
    )
)

year_distribution.to_csv(
    OUTPUT_DIR / "year_distribution.csv",
    index=False
)


# ============================================================
# 8. TEMPORAL SPLIT
# ============================================================

print("\n" + "=" * 100)
print("8. TEMPORAL TRAIN / VALIDATION / TEST SPLIT")
print("=" * 100)

# ------------------------------------------------------------
# IMPORTANT:
# We use chronological splitting.
#
# Train      : 2023
# Validation : 2024
# Test       : 2025-01-01 -> 2026-07-04
#
# No future observations enter training.
# ------------------------------------------------------------

train = df[
    df["TravelDate"].dt.year == 2023
].copy()

validation = df[
    df["TravelDate"].dt.year == 2024
].copy()

test = df[
    df["TravelDate"] >= pd.Timestamp("2025-01-01")
].copy()

print("\nTRAIN")
print(
    f"Rows    : {len(train):,}"
)
print(
    f"Date    : "
    f"{train['TravelDate'].min().date()} "
    f"-> "
    f"{train['TravelDate'].max().date()}"
)
print(
    f"Stations: {train['Station'].nunique():,}"
)

print("\nVALIDATION")
print(
    f"Rows    : {len(validation):,}"
)
print(
    f"Date    : "
    f"{validation['TravelDate'].min().date()} "
    f"-> "
    f"{validation['TravelDate'].max().date()}"
)
print(
    f"Stations: {validation['Station'].nunique():,}"
)

print("\nTEST")
print(
    f"Rows    : {len(test):,}"
)
print(
    f"Date    : "
    f"{test['TravelDate'].min().date()} "
    f"-> "
    f"{test['TravelDate'].max().date()}"
)
print(
    f"Stations: {test['Station'].nunique():,}"
)


# ============================================================
# 9. TEMPORAL LEAKAGE CHECK
# ============================================================

print("\n" + "=" * 100)
print("9. TEMPORAL LEAKAGE CHECK")
print("=" * 100)

train_max = train["TravelDate"].max()
validation_min = validation["TravelDate"].min()

validation_max = validation["TravelDate"].max()
test_min = test["TravelDate"].min()

print(
    f"Train maximum date      : {train_max.date()}"
)

print(
    f"Validation minimum date : {validation_min.date()}"
)

print(
    f"Validation maximum date : {validation_max.date()}"
)

print(
    f"Test minimum date       : {test_min.date()}"
)

if train_max < validation_min:
    print(
        "\nPASS: Train does not contain "
        "future validation dates."
    )
else:
    print(
        "\nFAIL: Temporal overlap detected "
        "between train and validation."
    )

if validation_max < test_min:
    print(
        "PASS: Validation does not contain "
        "future test dates."
    )
else:
    print(
        "FAIL: Temporal overlap detected "
        "between validation and test."
    )


# ============================================================
# 10. STATION OVERLAP
# ============================================================

print("\n" + "=" * 100)
print("10. STATION OVERLAP")
print("=" * 100)

train_stations = set(
    train["Station"].unique()
)

validation_stations = set(
    validation["Station"].unique()
)

test_stations = set(
    test["Station"].unique()
)

print(
    f"Train stations      : {len(train_stations):,}"
)

print(
    f"Validation stations : {len(validation_stations):,}"
)

print(
    f"Test stations       : {len(test_stations):,}"
)

print(
    f"Train ∩ Validation  : "
    f"{len(train_stations & validation_stations):,}"
)

print(
    f"Train ∩ Test        : "
    f"{len(train_stations & test_stations):,}"
)

print(
    f"Validation ∩ Test   : "
    f"{len(validation_stations & test_stations):,}"
)

unseen_test_stations = (
    test_stations - train_stations
)

print(
    f"Test stations unseen during training: "
    f"{len(unseen_test_stations):,}"
)


# ============================================================
# 11. LAG FEATURE AVAILABILITY
# ============================================================

print("\n" + "=" * 100)
print("11. LAG FEATURE AVAILABILITY")
print("=" * 100)

lag_columns = [
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

lag_report = []

for col in lag_columns:

    missing = df[col].isna().sum()

    available = len(df) - missing

    lag_report.append({
        "Feature": col,
        "Missing": missing,
        "Available": available,
        "Available_%": round(
            available / len(df) * 100,
            3
        )
    })

lag_report = pd.DataFrame(
    lag_report
)

print(
    lag_report.to_string(
        index=False
    )
)

lag_report.to_csv(
    OUTPUT_DIR / "lag_feature_report.csv",
    index=False
)


# ============================================================
# 12. BUILD ML DATASETS
# ============================================================

print("\n" + "=" * 100)
print("12. BUILDING ML DATASETS")
print("=" * 100)

TARGET = "TotalFootfall"

# ------------------------------------------------------------
# Predictors
# ------------------------------------------------------------

FEATURES = [
    "Station",
    "DayOfWeek",
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

print("\nTarget:")
print(TARGET)

print("\nFeatures:")

for feature in FEATURES:
    print(f"  - {feature}")


# ============================================================
# 13. REMOVE ROWS WITHOUT LAG HISTORY
# ============================================================

ML_REQUIRED_COLUMNS = [
    TARGET,
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingMean_14",
    "RollingMean_28",
]

train_ml = train.dropna(
    subset=ML_REQUIRED_COLUMNS
).copy()

validation_ml = validation.dropna(
    subset=ML_REQUIRED_COLUMNS
).copy()

test_ml = test.dropna(
    subset=ML_REQUIRED_COLUMNS
).copy()


# ============================================================
# 14. FINAL ML SPLIT REPORT
# ============================================================

print("\n" + "=" * 100)
print("14. FINAL ML SPLIT")
print("=" * 100)

print(
    f"Train ML rows      : {len(train_ml):,}"
)

print(
    f"Validation ML rows : {len(validation_ml):,}"
)

print(
    f"Test ML rows       : {len(test_ml):,}"
)


# ============================================================
# 15. SAVE SPLITS
# ============================================================

train_file = (
    OUTPUT_DIR
    / "train_2023.csv"
)

validation_file = (
    OUTPUT_DIR
    / "validation_2024.csv"
)

test_file = (
    OUTPUT_DIR
    / "test_2025_2026.csv"
)

train_ml.to_csv(
    train_file,
    index=False,
    encoding="utf-8"
)

validation_ml.to_csv(
    validation_file,
    index=False,
    encoding="utf-8"
)

test_ml.to_csv(
    test_file,
    index=False,
    encoding="utf-8"
)


# ============================================================
# 16. SAVE FEATURE CONFIGURATION
# ============================================================

feature_config = pd.DataFrame({
    "Feature": FEATURES,
    "Role": [
        "Categorical",
        "Categorical",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Temporal",
        "Binary",
        "Lag",
        "Lag",
        "Lag",
        "Lag",
        "Rolling",
        "Rolling",
        "Rolling",
        "Rolling",
    ]
})

feature_config.to_csv(
    OUTPUT_DIR / "feature_configuration.csv",
    index=False
)


# ============================================================
# 17. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 100)
print("VALIDATION COMPLETED")
print("=" * 100)

print("\nOutput directory:")
print(OUTPUT_DIR)

print("\nGenerated files:")

print("  1. station_date_gaps.csv")
print("  2. station_coverage.csv")
print("  3. year_distribution.csv")
print("  4. lag_feature_report.csv")
print("  5. feature_configuration.csv")
print("  6. train_2023.csv")
print("  7. validation_2024.csv")
print("  8. test_2025_2026.csv")

print("\nTarget:")
print("  TotalFootfall")

print("\nTemporal protocol:")
print("  Train      = 2023")
print("  Validation = 2024")
print("  Test       = 2025-01-01 -> 2026-07-04")

print("\nNo random train/test split is used.")
print("This preserves the chronological forecasting setting.")

print("\nNEXT STEP:")
print("Run the baseline forecasting experiments.")