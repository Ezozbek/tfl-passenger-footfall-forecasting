# -*- coding: utf-8 -*-

"""
STAGE 39 — FINAL ZIP CONTENT INSPECTION + SUBMISSION READINESS CHECK
CORRECTED VERSION

Purpose:
    Inspect the existing Stage 38B DOCX-only ZIP using its ACTUAL
    internal member paths.

IMPORTANT:
    - Does NOT modify the ZIP.
    - Does NOT modify the manuscript.
    - Does NOT create PDF.
    - Does NOT require PDF.
    - Separates REQUIRED submission files from AUDIT/ARCHIVE files.
"""

from pathlib import Path
import zipfile
import hashlib
import csv
import re
import sys
from datetime import datetime

from docx import Document


# ============================================================================
# 0. PATHS
# ============================================================================

ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

PACKAGE = ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

ZIP_FILE = ROOT / "FINAL_Q1_SUBMISSION_PACKAGE_STAGE38B_DOCX_ONLY.zip"

LOCAL_DOCX = PACKAGE / "01_Final_Manuscript.docx"

FIGURE_DIR = PACKAGE / "03_High_Resolution_Figures"

SUPPLEMENTARY_DIR = PACKAGE / "05_Supplementary_Material"

AUDIT_FILE = (
    PACKAGE /
    "STAGE39_FINAL_ZIP_CONTENT_INSPECTION.txt"
)

MANIFEST_FILE = (
    PACKAGE /
    "STAGE39_FINAL_ZIP_CONTENT_MANIFEST.csv"
)


# ============================================================================
# 1. ACTUAL ZIP REQUIRED SUBMISSION CONTENT
# ============================================================================

REQUIRED_SUBMISSION_FILES = [
    "01_Final_Manuscript.docx",

    "03_High_Resolution_Figures/"
    "Figure_1_Feature_Importance.png",

    "03_High_Resolution_Figures/"
    "Figure_2_Actual_vs_Predicted.png",

    "03_High_Resolution_Figures/"
    "Figure_3_Residual_Diagnostics.png",

    "03_High_Resolution_Figures/"
    "Figure_4_Model_Comparison.png",

    "05_Supplementary_Material/"
    "Figure_2_3_Paired_Test_Predictions.csv",
]


# ============================================================================
# 2. AUDIT / ARCHIVE FILES
# ============================================================================

ALLOWED_AUDIT_FILES = [
    "STAGE38B_DOCX_ONLY_PACKAGE_MANIFEST.csv",
    "STAGE38B_DOCX_ONLY_FINAL_AUDIT.txt",
]


ARCHIVE_OR_INTERNAL_FILES = [
    "stage38b_docx_only_final_audit.py",
]


BACKUP_PREFIXES = [
    "_Stage38_Backup/",
    "_Stage38B_Backup/",
]


# ============================================================================
# 3. LEGACY VALUES
# ============================================================================

LEGACY_VALUES = [
    "61.998",
    "61.998%",
    "-5.48",
    "mean bias = -5.48",
]


# ============================================================================
# 4. VERIFIED SCIENTIFIC VALUES
# ============================================================================

REQUIRED_SCIENTIFIC_VALUES = [
    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",

    "1,490.7452",
    "4,087.0080",
    "0.979950",
    "0.989932",

    "20.0042%",
    "19.7594%",
    "16.0978%",
]


# ============================================================================
# 5. FIGURES
# ============================================================================

FIGURE_FILES = [
    "Figure_1_Feature_Importance.png",
    "Figure_2_Actual_vs_Predicted.png",
    "Figure_3_Residual_Diagnostics.png",
    "Figure_4_Model_Comparison.png",
]


# ============================================================================
# 6. HELPERS
# ============================================================================

def human_size(size_bytes):

    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"

    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.1f} KB"

    return f"{size_bytes} B"


def sha256_bytes(data):

    return hashlib.sha256(data).hexdigest()


def sha256_file(path):

    sha = hashlib.sha256()

    with open(path, "rb") as f:

        while True:

            chunk = f.read(1024 * 1024)

            if not chunk:
                break

            sha.update(chunk)

    return sha.hexdigest()


def normalize_text(text):

    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def print_section(number, title):

    print()
    print("=" * 100)
    print(f"{number}. {title}")
    print("=" * 100)


# ============================================================================
# 7. ZIP INSPECTION
# ============================================================================

def inspect_zip():

    if not ZIP_FILE.exists():

        print("FAIL | Final ZIP does not exist")

        return False, []

    print(
        f"PASS | ZIP exists | "
        f"{ZIP_FILE.name} | "
        f"{human_size(ZIP_FILE.stat().st_size)}"
    )

    try:

        with zipfile.ZipFile(ZIP_FILE, "r") as z:

            bad_member = z.testzip()

            if bad_member is not None:

                print(
                    f"FAIL | ZIP integrity error | {bad_member}"
                )

                return False, []

            members = z.namelist()

            print("PASS | ZIP integrity")

            print(
                f"ZIP members : {len(members)}"
            )

            for member in members:

                print(f"      {member}")

            return True, members

    except Exception as exc:

        print(
            f"FAIL | ZIP inspection error | {exc}"
        )

        return False, []


# ============================================================================
# 8. REQUIRED FILES
# ============================================================================

def check_required_files(members):

    member_set = set(members)

    missing = [
        item
        for item in REQUIRED_SUBMISSION_FILES
        if item not in member_set
    ]

    if missing:

        print("FAIL | Required submission files missing:")

        for item in missing:
            print(f"      - {item}")

        return False

    print(
        "PASS | Required submission files: ALL PRESENT"
    )

    return True


# ============================================================================
# 9. PDF EXCLUSION
# ============================================================================

def check_pdf_exclusion(members):

    pdfs = [
        item
        for item in members
        if item.lower().endswith(".pdf")
    ]

    if pdfs:

        print(
            "FAIL | PDF files found in DOCX-only ZIP:"
        )

        for item in pdfs:
            print(f"      - {item}")

        return False

    print(
        "PASS | PDF exclusion"
    )

    return True


# ============================================================================
# 10. INTERNAL / ARCHIVE FILE INSPECTION
# ============================================================================

def inspect_internal_files(members):

    internal = []

    for member in members:

        if member in ARCHIVE_OR_INTERNAL_FILES:
            internal.append(member)

        for prefix in BACKUP_PREFIXES:

            if member.startswith(prefix):
                internal.append(member)

    internal = sorted(set(internal))

    if internal:

        print(
            "NOTE | Internal/audit archive files detected:"
        )

        for item in internal:
            print(f"      - {item}")

        print()
        print(
            "These files are NOT treated as scientific-content failures."
        )

        return True

    print(
        "PASS | No internal/archive files detected"
    )

    return True


# ============================================================================
# 11. DOCX EXTRACTION
# ============================================================================

def extract_docx():

    target = "01_Final_Manuscript.docx"

    try:

        with zipfile.ZipFile(ZIP_FILE, "r") as z:

            data = z.read(target)

        temp_path = ROOT / "_stage39_temp_final_manuscript.docx"

        with open(temp_path, "wb") as f:
            f.write(data)

        return temp_path, data

    except Exception as exc:

        print(
            f"FAIL | DOCX extraction | {exc}"
        )

        return None, None


# ============================================================================
# 12. DOCX STRUCTURE
# ============================================================================

def validate_docx(path):

    if path is None:
        return False

    try:

        document = Document(path)

        paragraphs = len(document.paragraphs)
        tables = len(document.tables)

        print(
            "PASS | DOCX opens successfully"
        )

        print(
            f"      Paragraphs : {paragraphs}"
        )

        print(
            f"      Tables     : {tables}"
        )

        if paragraphs < 1:

            print(
                "FAIL | DOCX contains no paragraphs"
            )

            return False

        return True

    except Exception as exc:

        print(
            f"FAIL | DOCX structural validation | {exc}"
        )

        return False


# ============================================================================
# 13. DOCX EMBEDDED MEDIA
# ============================================================================

def validate_embedded_media(path):

    if path is None:
        return False

    try:

        with zipfile.ZipFile(path, "r") as z:

            media = [
                item
                for item in z.namelist()
                if item.startswith("word/media/")
            ]

        print(
            f"DOCX embedded media files : {len(media)}"
        )

        if len(media) < 4:

            print(
                "FAIL | Fewer than 4 embedded media files"
            )

            return False

        print(
            "PASS | Embedded figure media detected"
        )

        return True

    except Exception as exc:

        print(
            f"FAIL | Embedded media audit | {exc}"
        )

        return False


# ============================================================================
# 14. DOCX TEXT AUDIT
# ============================================================================

def audit_docx_text(path):

    if path is None:
        return False

    try:

        document = Document(path)

        parts = []

        for paragraph in document.paragraphs:

            parts.append(paragraph.text)

        for table in document.tables:

            for row in table.rows:

                for cell in row.cells:

                    parts.append(cell.text)

        text = normalize_text(
            " ".join(parts)
        )

        # Legacy
        legacy_found = []

        for value in LEGACY_VALUES:

            if value.lower() in text.lower():

                legacy_found.append(value)

        if legacy_found:

            print(
                "FAIL | Legacy / obsolete values found:"
            )

            for value in legacy_found:
                print(f"      - {value}")

            return False

        print(
            "PASS | Legacy / obsolete values: NONE"
        )

        # Scientific values
        missing = []

        for value in REQUIRED_SCIENTIFIC_VALUES:

            if value.lower() not in text.lower():

                missing.append(value)

        if missing:

            print(
                "FAIL | Scientific values missing:"
            )

            for value in missing:
                print(f"      - {value}")

            return False

        print(
            "PASS | Verified scientific values: ALL PRESENT"
        )

        # Figure references
        missing_figures = []

        for figure_number in range(1, 5):

            token = f"Figure {figure_number}"

            if token.lower() not in text.lower():

                missing_figures.append(token)

        if missing_figures:

            print(
                "FAIL | Figure references missing:"
            )

            for item in missing_figures:
                print(f"      - {item}")

            return False

        print(
            "PASS | Figure 1–4 textual references"
        )

        return True

    except Exception as exc:

        print(
            f"FAIL | DOCX text audit | {exc}"
        )

        return False


# ============================================================================
# 15. FIGURE AUDIT INSIDE ZIP
# ============================================================================

def audit_figures_in_zip(members):

    all_pass = True

    member_set = set(members)

    with zipfile.ZipFile(ZIP_FILE, "r") as z:

        for index, filename in enumerate(
            FIGURE_FILES,
            start=1
        ):

            member = (
                "03_High_Resolution_Figures/"
                + filename
            )

            if member not in member_set:

                print(
                    f"FAIL | Figure {index} missing from ZIP"
                )

                all_pass = False

                continue

            data = z.read(member)

            print(
                f"PASS | Figure {index} | "
                f"{filename}"
            )

            print(
                f"      ZIP size   : {human_size(len(data))}"
            )

            print(
                f"      ZIP SHA256 : {sha256_bytes(data)}"
            )

    return all_pass


# ============================================================================
# 16. SUPPLEMENTARY CSV
# ============================================================================

def audit_supplementary_in_zip(members):

    member = (
        "05_Supplementary_Material/"
        "Figure_2_3_Paired_Test_Predictions.csv"
    )

    if member not in set(members):

        print(
            "FAIL | Supplementary CSV missing"
        )

        return False

    try:

        with zipfile.ZipFile(ZIP_FILE, "r") as z:

            data = z.read(member)

        text = data.decode(
            "utf-8-sig",
            errors="replace"
        )

        lines = text.splitlines()

        if len(lines) < 2:

            print(
                "FAIL | Supplementary CSV has no data rows"
            )

            return False

        header = lines[0].split(",")

        print(
            "PASS | Supplementary CSV"
        )

        print(
            f"      Columns : {len(header)}"
        )

        print(
            f"      Rows    : {len(lines) - 1}"
        )

        print(
            f"      SHA256  : {sha256_bytes(data)}"
        )

        return True

    except Exception as exc:

        print(
            f"FAIL | Supplementary CSV audit | {exc}"
        )

        return False


# ============================================================================
# 17. LOCAL DOCX VS ZIP DOCX
# ============================================================================

def compare_local_docx(zip_docx_bytes):

    if not LOCAL_DOCX.exists():

        print(
            "FAIL | Local final DOCX does not exist"
        )

        return False

    local_hash = sha256_file(LOCAL_DOCX)
    zip_hash = sha256_bytes(zip_docx_bytes)

    print(
        f"Local DOCX SHA256 : {local_hash}"
    )

    print(
        f"ZIP DOCX SHA256   : {zip_hash}"
    )

    if local_hash != zip_hash:

        print(
            "FAIL | Local DOCX differs from ZIP DOCX"
        )

        return False

    print(
        "PASS | Local DOCX == ZIP DOCX"
    )

    return True


# ============================================================================
# 18. ZIP SHA256 AUDIT
# ============================================================================

def audit_zip_hashes(members):

    try:

        with zipfile.ZipFile(ZIP_FILE, "r") as z:

            for member in members:

                data = z.read(member)

                print(
                    f"PASS | {member}"
                )

                print(
                    f"      SHA256 : {sha256_bytes(data)}"
                )

        return True

    except Exception as exc:

        print(
            f"FAIL | ZIP SHA256 audit | {exc}"
        )

        return False


# ============================================================================
# 19. STAGE 39 MANIFEST
# ============================================================================

def create_manifest(members):

    rows = []

    with zipfile.ZipFile(ZIP_FILE, "r") as z:

        for member in members:

            info = z.getinfo(member)
            data = z.read(member)

            rows.append(
                {
                    "file": member,
                    "compressed_size":
                        info.compress_size,
                    "uncompressed_size":
                        info.file_size,
                    "compressed_size_human":
                        human_size(info.compress_size),
                    "uncompressed_size_human":
                        human_size(info.file_size),
                    "sha256":
                        sha256_bytes(data),
                }
            )

    with open(
        MANIFEST_FILE,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=[
                "file",
                "compressed_size",
                "uncompressed_size",
                "compressed_size_human",
                "uncompressed_size_human",
                "sha256",
            ],
        )

        writer.writeheader()
        writer.writerows(rows)

    print(
        f"PASS | Stage 39 manifest created:"
    )

    print(
        f"      {MANIFEST_FILE}"
    )

    return True


# ============================================================================
# 20. REPORT
# ============================================================================

def write_report(
    status,
    members,
    checks
):

    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )

    lines = []

    lines.append(
        "STAGE 39 — FINAL ZIP CONTENT INSPECTION"
    )

    lines.append(
        "=========================================="
    )

    lines.append("")

    lines.append(
        f"Timestamp: {timestamp}"
    )

    lines.append(
        "PDF requirement: NOT REQUIRED"
    )

    lines.append("")

    lines.append(
        "FINAL STATUS"
    )

    lines.append(
        "------------"
    )

    lines.append(
        status
    )

    lines.append("")

    lines.append(
        "CHECKS"
    )

    lines.append(
        "------"
    )

    for name, result in checks.items():

        lines.append(
            f"{name}: {result}"
        )

    lines.append("")

    lines.append(
        "ZIP MEMBERS"
    )

    lines.append(
        "-----------"
    )

    for member in members:

        lines.append(member)

    lines.append("")

    lines.append(
        "NOTE"
    )

    lines.append(
        "----"
    )

    lines.append(
        "The ZIP was inspected using its actual internal paths."
    )

    lines.append(
        "No PDF was generated or required."
    )

    lines.append(
        "No ZIP modification was performed."
    )

    lines.append("")

    lines.append(
        "NEXT STAGE"
    )

    lines.append(
        "----------"
    )

    lines.append(
        "Stage 40 → Final Manuscript Submission Package Review"
    )

    with open(
        AUDIT_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "\n".join(lines)
        )

    print(
        f"PASS | Audit report created:"
    )

    print(
        f"      {AUDIT_FILE}"
    )


# ============================================================================
# 21. MAIN
# ============================================================================

def main():

    print("=" * 100)
    print(
        "STAGE 39 — FINAL ZIP CONTENT INSPECTION + "
        "SUBMISSION READINESS CHECK"
    )
    print("=" * 100)

    checks = {}

    # ------------------------------------------------------------------------
    # 1
    # ------------------------------------------------------------------------

    print_section(
        1,
        "FINAL ZIP VALIDATION"
    )

    zip_ok, members = inspect_zip()

    checks["ZIP integrity"] = (
        "PASS" if zip_ok else "FAIL"
    )

    if not zip_ok:

        print(
            "\nSTAGE 39 — FAIL"
        )

        return 1

    # ------------------------------------------------------------------------
    # 2
    # ------------------------------------------------------------------------

    print_section(
        2,
        "REQUIRED SUBMISSION CONTENT"
    )

    required_ok = check_required_files(
        members
    )

    checks["Required submission content"] = (
        "PASS" if required_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 3
    # ------------------------------------------------------------------------

    print_section(
        3,
        "PDF EXCLUSION"
    )

    pdf_ok = check_pdf_exclusion(
        members
    )

    checks["PDF exclusion"] = (
        "PASS" if pdf_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 4
    # ------------------------------------------------------------------------

    print_section(
        4,
        "INTERNAL / ARCHIVE FILE INSPECTION"
    )

    internal_ok = inspect_internal_files(
        members
    )

    checks["Internal/archive inspection"] = (
        "PASS" if internal_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 5
    # ------------------------------------------------------------------------

    print_section(
        5,
        "FINAL DOCX EXTRACTION"
    )

    temp_docx, zip_docx_bytes = extract_docx()

    docx_extraction_ok = (
        temp_docx is not None
    )

    checks["DOCX extraction"] = (
        "PASS" if docx_extraction_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 6
    # ------------------------------------------------------------------------

    print_section(
        6,
        "DOCX STRUCTURAL VALIDATION"
    )

    docx_structure_ok = validate_docx(
        temp_docx
    )

    checks["DOCX structural validation"] = (
        "PASS" if docx_structure_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 7
    # ------------------------------------------------------------------------

    print_section(
        7,
        "DOCX EMBEDDED FIGURE VALIDATION"
    )

    embedded_ok = validate_embedded_media(
        temp_docx
    )

    checks["DOCX embedded figures"] = (
        "PASS" if embedded_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 8
    # ------------------------------------------------------------------------

    print_section(
        8,
        "DOCX SCIENTIFIC CONTENT AUDIT"
    )

    scientific_ok = audit_docx_text(
        temp_docx
    )

    checks["Scientific/text audit"] = (
        "PASS" if scientific_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 9
    # ------------------------------------------------------------------------

    print_section(
        9,
        "FIGURE 1–4 ZIP AUDIT"
    )

    figures_ok = audit_figures_in_zip(
        members
    )

    checks["Figure 1–4 ZIP audit"] = (
        "PASS" if figures_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 10
    # ------------------------------------------------------------------------

    print_section(
        10,
        "SUPPLEMENTARY MATERIAL ZIP AUDIT"
    )

    supplementary_ok = audit_supplementary_in_zip(
        members
    )

    checks["Supplementary CSV"] = (
        "PASS" if supplementary_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 11
    # ------------------------------------------------------------------------

    print_section(
        11,
        "LOCAL DOCX ↔ ZIP DOCX HASH"
    )

    hash_ok = False

    if zip_docx_bytes is not None:

        hash_ok = compare_local_docx(
            zip_docx_bytes
        )

    checks["DOCX hash consistency"] = (
        "PASS" if hash_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 12
    # ------------------------------------------------------------------------

    print_section(
        12,
        "ZIP MEMBER SHA256 AUDIT"
    )

    zip_hash_ok = audit_zip_hashes(
        members
    )

    checks["ZIP SHA256 audit"] = (
        "PASS" if zip_hash_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # 13
    # ------------------------------------------------------------------------

    print_section(
        13,
        "STAGE 39 MANIFEST"
    )

    manifest_ok = create_manifest(
        members
    )

    checks["Stage 39 manifest"] = (
        "PASS" if manifest_ok else "FAIL"
    )

    # ------------------------------------------------------------------------
    # TEMP CLEANUP
    # ------------------------------------------------------------------------

    if temp_docx is not None:

        try:
            temp_docx.unlink()
        except Exception:
            pass

    # ------------------------------------------------------------------------
    # FINAL STATUS
    # ------------------------------------------------------------------------

    critical = [
        zip_ok,
        required_ok,
        pdf_ok,
        docx_extraction_ok,
        docx_structure_ok,
        embedded_ok,
        scientific_ok,
        figures_ok,
        supplementary_ok,
        hash_ok,
        zip_hash_ok,
        manifest_ok,
    ]

    overall_pass = all(critical)

    print()
    print("=" * 100)
    print(
        "14. STAGE 39 FINAL SUBMISSION READINESS STATUS"
    )
    print("=" * 100)

    if overall_pass:

        status = "STAGE 39 — PASS"

        print()
        print(
            "STATUS: PASS"
        )

        print()
        print(
            "The final DOCX-only package passed "
            "the technical submission-readiness audit."
        )

        print()
        print(
            "NOTE: Internal backup/audit files may still exist "
            "inside the ZIP and are reported separately."
        )

        print()
        print(
            "PDF is intentionally excluded."
        )

    else:

        status = "STAGE 39 — FAIL"

        print()
        print(
            "STATUS: FAIL"
        )

        print()
        print(
            "One or more critical checks failed."
        )

    # ------------------------------------------------------------------------
    # REPORT
    # ------------------------------------------------------------------------

    print_section(
        15,
        "FINAL AUDIT REPORT"
    )

    write_report(
        status,
        members,
        checks
    )

    print()
    print("=" * 100)
    print(
        "STAGE 39 SUMMARY"
    )
    print("=" * 100)

    for name, result in checks.items():

        print(
            f"{name:<45} : {result}"
        )

    print()

    print(
        f"Final ZIP : {ZIP_FILE}"
    )

    print(
        f"ZIP size  : {human_size(ZIP_FILE.stat().st_size)}"
    )

    print(
        f"Manifest  : {MANIFEST_FILE}"
    )

    print(
        f"Audit     : {AUDIT_FILE}"
    )

    print()

    if overall_pass:

        print(
            "STAGE 39 — PASS"
        )

        print()
        print(
            "Next stage:"
        )

        print(
            "Stage 40 → Final Manuscript Submission Package Review"
        )

        return 0

    print(
        "STAGE 39 — FAIL"
    )

    print()
    print(
        "Do not proceed to Stage 40 until the critical "
        "failure is resolved."
    )

    return 1


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":

    sys.exit(main())