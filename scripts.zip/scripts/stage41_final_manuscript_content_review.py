from pathlib import Path
from docx import Document
import re
import hashlib
import sys
from datetime import datetime


# ============================================================
# STAGE 41
# FINAL MANUSCRIPT CONTENT REVIEW
# ============================================================

PROJECT_ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

PACKAGE_DIR = PROJECT_ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

MANUSCRIPT = PACKAGE_DIR / "01_Final_Manuscript.docx"

REPORT = PACKAGE_DIR / "STAGE41_FINAL_MANUSCRIPT_CONTENT_REVIEW.txt"


# ============================================================
# EXPECTED MANUSCRIPT STRUCTURE
# ============================================================

EXPECTED_SECTIONS = [
    "1. Introduction",
    "2. Related Work",
    "3. Proposed Forecasting Framework",
    "4. Mathematical Model",
    "5. Forecasting Algorithm",
    "6. Experimental Setup",
    "7. Results and Comparative Analysis",
    "8. Feature Ablation and Robustness Analysis",
    "9. Discussion",
    "10. Conclusion and Future Work",
]


EXPECTED_TABLES = [
    "Table 1.",
    "Table 2.",
    "Table 3.",
    "Table 4.",
    "Table 5.",
    "Table 6.",
]


EXPECTED_FIGURES = [
    "Figure 1.",
    "Figure 2.",
    "Figure 3.",
    "Figure 4.",
]


# ============================================================
# EXPECTED SCIENTIFIC VALUES
# ============================================================

EXPECTED_VALUES = {
    "final_dataset_rows": "516819",
    "final_stations": "434",

    "training_rows": "140157",
    "validation_rows": "151509",
    "test_rows": "225153",

    "extra_mae": "1400.3845",
    "extra_rmse": "4036.1222",
    "extra_r2": "0.980447",
    "extra_pearson": "0.990215",

    "xgb_mae": "1490.7452",
    "xgb_rmse": "4087.0080",
    "xgb_r2": "0.979950",
    "xgb_pearson": "0.989932",

    "lag28": "20.0042",
    "lag7": "19.7594",
    "lag14": "16.0978",

    "mean_residual": "26.3903",
    "median_residual": "32.6876",
}


# ============================================================
# IMPORTANT:
# Table 5 belongs to a separate ablation configuration.
# It is NOT expected to numerically match the primary model.
# ============================================================

ABLATION_VALUES = [
    "112264.588625",
    "142564.188709",
    "0.919183",

    "120734.251622",
    "151573.326631",
    "0.908646",

    "122992.883546",
    "162913.352530",
    "0.894465",

    "141651.330412",
    "191072.466700",
    "0.854829",

    "177242.606253",
    "246106.685570",
    "0.759159",

    "207047.637564",
    "264677.110584",
    "0.721442",

    "245690.386677",
    "583663.701327",
    "-0.354592",
]


# ============================================================
# LEGACY / OBSOLETE VALUES THAT SHOULD NOT APPEAR
# ============================================================

LEGACY_VALUES = [
    "8.8959",
    "12.2474",
    "0.9066",
    "Cap125",
    "C-MAPSS FD001",
    "W30",
    "W20",
    "CNN-LSTM",
    "Transformer",
]


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def sha256_file(path):
    h = hashlib.sha256()

    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)

            if not chunk:
                break

            h.update(chunk)

    return h.hexdigest()


def normalize(text):
    text = text.replace("\u00ad", "")
    text = text.replace("￾", "-")
    text = text.replace("–", "-")
    text = text.replace("—", "-")
    return text


def contains_value(text, value):
    return value in text


def add_pass(label):
    print(f"PASS | {label}")
    passed.append(label)


def add_fail(label):
    print(f"FAIL | {label}")
    failed.append(label)


def add_note(label):
    print(f"NOTE | {label}")
    notes.append(label)


# ============================================================
# START
# ============================================================

print("=" * 100)
print("STAGE 41 — FINAL MANUSCRIPT CONTENT REVIEW")
print("Q1 MANUSCRIPT / SCIENTIFIC CONSISTENCY / CONTENT AUDIT")
print("=" * 100)

start = datetime.now()

passed = []
failed = []
notes = []


# ============================================================
# 1. FILE EXISTENCE
# ============================================================

print("\n[1] MANUSCRIPT FILE")

if not MANUSCRIPT.exists():

    add_fail("Final manuscript DOCX exists")

    print("\nCannot continue.")
    sys.exit(1)

else:

    add_pass("Final manuscript DOCX exists")

    print(f"      {MANUSCRIPT}")

    print(
        f"      Size   : "
        f"{MANUSCRIPT.stat().st_size / (1024 * 1024):.2f} MB"
    )

    print(
        f"      SHA256 : "
        f"{sha256_file(MANUSCRIPT)}"
    )


# ============================================================
# 2. OPEN DOCX
# ============================================================

print("\n[2] DOCX OPEN / STRUCTURE")

try:

    doc = Document(MANUSCRIPT)

    add_pass("DOCX opens successfully")

    print(f"      Paragraphs : {len(doc.paragraphs)}")
    print(f"      Tables     : {len(doc.tables)}")

except Exception as e:

    add_fail("DOCX opens successfully")

    print(f"      ERROR: {e}")

    sys.exit(1)


# ============================================================
# 3. EXTRACT FULL TEXT
# ============================================================

paragraph_text = []

for p in doc.paragraphs:

    if p.text.strip():

        paragraph_text.append(p.text.strip())


table_text = []

for table in doc.tables:

    for row in table.rows:

        cells = []

        for cell in row.cells:

            cells.append(cell.text.strip())

        table_text.append(" | ".join(cells))


full_text = "\n".join(
    paragraph_text + table_text
)

full_text = normalize(full_text)


print("\n[3] TEXT EXTRACTION")

print(
    f"      Paragraph text lines : "
    f"{len(paragraph_text)}"
)

print(
    f"      Table text rows      : "
    f"{len(table_text)}"
)

print(
    f"      Total text length    : "
    f"{len(full_text):,} characters"
)

add_pass("Manuscript text successfully extracted")


# ============================================================
# 4. TITLE
# ============================================================

print("\n[4] TITLE")

title_expected = (
    "AI-Based Passenger Footfall Forecasting for "
    "Data-Driven Public Transport Scheduling Support"
)

if title_expected in full_text:

    add_pass("Final manuscript title present")

else:

    add_fail("Final manuscript title present")


# ============================================================
# 5. ABSTRACT
# ============================================================

print("\n[5] ABSTRACT")

if "Abstract" in full_text:

    add_pass("Abstract present")

else:

    add_fail("Abstract present")


abstract_keywords = [
    "516,819",
    "ExtraTrees",
    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",
    "2025",
    "2026",
]


for item in abstract_keywords:

    if item in full_text:

        add_pass(f"Abstract contains required evidence: {item}")

    else:

        add_fail(
            f"Abstract contains required evidence: {item}"
        )


# ============================================================
# 6. KEYWORDS
# ============================================================

print("\n[6] KEYWORDS")

if "Keywords:" in full_text:

    add_pass("Keywords present")

else:

    add_fail("Keywords present")


required_keywords = [
    "passenger footfall forecasting",
    "public transport",
    "Transport for London",
    "ExtraTrees",
    "XGBoost",
]


for keyword in required_keywords:

    if keyword.lower() in full_text.lower():

        add_pass(f"Keyword/topic present: {keyword}")

    else:

        add_fail(f"Keyword/topic present: {keyword}")


# ============================================================
# 7. SECTION STRUCTURE
# ============================================================

print("\n[7] MANUSCRIPT SECTION STRUCTURE")

for section in EXPECTED_SECTIONS:

    if section.lower() in full_text.lower():

        add_pass(section)

    else:

        add_fail(f"Missing section: {section}")


# ============================================================
# 8. TABLE STRUCTURE
# ============================================================

print("\n[8] TABLES")

for table in EXPECTED_TABLES:

    if table.lower() in full_text.lower():

        add_pass(f"{table} present")

    else:

        add_fail(f"{table} missing")


# ============================================================
# 9. FIGURE REFERENCES
# ============================================================

print("\n[9] FIGURE REFERENCES")

for figure in EXPECTED_FIGURES:

    if figure.lower() in full_text.lower():

        add_pass(f"{figure} reference present")

    else:

        add_fail(f"{figure} reference missing")


# ============================================================
# 10. DATASET CONSISTENCY
# ============================================================

print("\n[10] DATASET CONSISTENCY")

dataset_checks = [
    ("516,819", "Final ML-ready dataset = 516,819"),
    ("434", "Final station count = 434"),
    ("549,122", "Initial master dataset = 549,122"),
    ("437", "Initial station count = 437"),
    ("17 features", "17 predictors/features"),
]


for value, label in dataset_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 11. CHRONOLOGICAL PARTITION
# ============================================================

print("\n[11] CHRONOLOGICAL TRAIN / VALIDATION / TEST SPLIT")

partition_checks = [
    ("2023", "Training period 2023"),
    ("2024", "Validation period 2024"),
    ("2025-01-01", "Test starts 2025-01-01"),
    ("2026-07-04", "Test ends 2026-07-04"),
    ("140,157", "Training observations"),
    ("151,509", "Validation observations"),
    ("225,153", "Test observations"),
]


for value, label in partition_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 12. PRIMARY EXTRA TREES RESULTS
# ============================================================

print("\n[12] PRIMARY EXTRATREES RESULTS")

extra_checks = [
    ("1,400.3845", "ExtraTrees MAE"),
    ("4,036.1222", "ExtraTrees RMSE"),
    ("0.980447", "ExtraTrees R2"),
    ("0.990215", "ExtraTrees Pearson r"),
]


for value, label in extra_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 13. XGBOOST RESULTS
# ============================================================

print("\n[13] REGULARIZED XGBOOST RESULTS")

xgb_checks = [
    ("1,490.7452", "XGBoost MAE"),
    ("4,087.0080", "XGBoost RMSE"),
    ("0.979950", "XGBoost R2"),
    ("0.989932", "XGBoost Pearson r"),
]


for value, label in xgb_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 14. FEATURE IMPORTANCE
# ============================================================

print("\n[14] FEATURE IMPORTANCE")

importance_checks = [
    ("Lag_28", "Lag_28 feature"),
    ("20.0042%", "Lag_28 importance"),
    ("Lag_7", "Lag_7 feature"),
    ("19.7594%", "Lag_7 importance"),
    ("Lag_14", "Lag_14 feature"),
    ("16.0978%", "Lag_14 importance"),
    ("RollingMean_14", "RollingMean_14"),
    ("RollingMean_7", "RollingMean_7"),
    ("RollingMean_28", "RollingMean_28"),
]


for value, label in importance_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 15. RESIDUAL DEFINITION
# ============================================================

print("\n[15] RESIDUAL DEFINITION")

residual_checks = [
    ("Actual - Predicted", "Residual definition"),
    ("26.3903", "Mean residual"),
    ("32.6876", "Median residual"),
]


for value, label in residual_checks:

    if value in full_text:

        add_pass(label)

    else:

        add_fail(label)


# ============================================================
# 16. ABLATION EXPERIMENT
# ============================================================

print("\n[16] ABLATION EXPERIMENT")

if "Table 5. Separate feature-ablation experiment" in full_text:

    add_pass("Separate ablation experiment explicitly identified")

else:

    add_note(
        "Table 5 heading differs from expected exact wording; "
        "manual inspection recommended."
    )


if (
    "separate configuration" in full_text
    and "not combined with the main TotalFootfall results" in full_text
):

    add_pass(
        "Ablation/main-result separation explicitly documented"
    )

else:

    add_note(
        "Ablation separation wording should be manually reviewed."
    )


ablation_present = 0

for value in ABLATION_VALUES:

    if value in full_text:

        ablation_present += 1


print(
    f"      Ablation numeric values detected: "
    f"{ablation_present}/{len(ABLATION_VALUES)}"
)

if ablation_present == len(ABLATION_VALUES):

    add_pass("Ablation numerical result set preserved")

else:

    add_note(
        "Some ablation values were not detected; "
        "manual Table 5 verification recommended."
    )


# ============================================================
# 17. LEGACY / CROSS-PROJECT VALUE SCAN
# ============================================================

print("\n[17] LEGACY / CROSS-PROJECT VALUE SCAN")

legacy_found = []

for value in LEGACY_VALUES:

    if value.lower() in full_text.lower():

        legacy_found.append(value)


if not legacy_found:

    add_pass("No known legacy/cross-project values detected")

else:

    print("WARNING | Potential legacy values detected:")

    for value in legacy_found:

        print(f"      {value}")

    add_fail(
        "No known legacy/cross-project values detected"
    )


# ============================================================
# 18. CLAIM BOUNDARY CHECK
# ============================================================

print("\n[18] CLAIM BOUNDARY / OVERCLAIM CHECK")

claim_checks = [
    (
        "does not claim direct operational savings",
        "Operational savings limitation stated"
    ),
    (
        "does not directly optimize timetables",
        "No direct timetable optimization claim"
    ),
    (
        "does not quantify operational cost savings",
        "No unsupported cost-saving claim"
    ),
    (
        "should not be interpreted as a causal estimate",
        "Feature importance not presented as causal"
    ),
]


for phrase, label in claim_checks:

    if phrase.lower() in full_text.lower():

        add_pass(label)

    else:

        add_note(
            f"Manual review recommended: {label}"
        )


# ============================================================
# 19. REFERENCE SECTION
# ============================================================

print("\n[19] REFERENCES")

if "References" in full_text:

    add_pass("References section present")

else:

    add_fail("References section present")


reference_checks = [
    "Geurts",
    "Chen",
    "XGBoost",
    "Forecasting: Principles and Practice",
    "Transport for London",
]


for ref in reference_checks:

    if ref.lower() in full_text.lower():

        add_pass(f"Reference/source present: {ref}")

    else:

        add_note(
            f"Reference/source not detected: {ref}"
        )


# ============================================================
# 20. FIGURE / TABLE COUNT
# ============================================================

print("\n[20] FIGURE / TABLE OBJECT COUNT")

inline_shapes = len(doc.inline_shapes)

print(f"      Inline images/shapes : {inline_shapes}")

if inline_shapes >= 4:

    add_pass("At least four embedded figure objects detected")

else:

    add_fail(
        "At least four embedded figure objects detected"
    )


if len(doc.tables) >= 5:

    add_pass("At least five table objects detected")

else:

    add_fail(
        "At least five table objects detected"
    )


# ============================================================
# 21. PDF / INTERNAL PACKAGE TEXT
# ============================================================

print("\n[21] UNWANTED INTERNAL CONTENT")

unwanted_text = [
    "STAGE38",
    "STAGE39",
    "STAGE40",
    "FINAL_Q1_JOURNAL_SUBMISSION_PACKAGE_STAGE40",
    "FINAL_Q1_SUBMISSION_PACKAGE_STAGE38B_DOCX_ONLY",
]


found_unwanted = []

for item in unwanted_text:

    if item.lower() in full_text.lower():

        found_unwanted.append(item)


if not found_unwanted:

    add_pass("No internal Stage-package text detected in manuscript")

else:

    print("WARNING | Internal package references detected:")

    for item in found_unwanted:

        print(f"      {item}")

    add_note(
        "Internal package references should be manually reviewed."
    )


# ============================================================
# 22. ABSTRACT LENGTH
# ============================================================

print("\n[22] ABSTRACT LENGTH")

abstract_match = re.search(
    r"Abstract\s+(.*?)\s+Keywords:",
    full_text,
    flags=re.IGNORECASE | re.DOTALL
)

if abstract_match:

    abstract_text = abstract_match.group(1)

    abstract_words = re.findall(
        r"\b[\w'-]+\b",
        abstract_text
    )

    print(
        f"      Abstract word count : "
        f"{len(abstract_words)}"
    )

    if 120 <= len(abstract_words) <= 350:

        add_pass("Abstract length within general journal range")

    else:

        add_note(
            "Abstract length outside generic 120–350-word range; "
            "verify target journal requirements."
        )

else:

    add_note("Could not automatically isolate Abstract section")


# ============================================================
# 23. KEYWORD COUNT
# ============================================================

print("\n[23] KEYWORD COUNT")

keyword_match = re.search(
    r"Keywords:\s*(.*?)\s+1\.\s+Introduction",
    full_text,
    flags=re.IGNORECASE | re.DOTALL
)

if keyword_match:

    keyword_text = keyword_match.group(1)

    keyword_list = [
        x.strip()
        for x in re.split(r";|,", keyword_text)
        if x.strip()
    ]

    print(
        f"      Keyword count : "
        f"{len(keyword_list)}"
    )

    if 3 <= len(keyword_list) <= 10:

        add_pass("Keyword count reasonable")

    else:

        add_note(
            "Keyword count should be checked against target journal."
        )

else:

    add_note("Could not automatically isolate Keywords")


# ============================================================
# 24. SCIENTIFIC CONSISTENCY SUMMARY
# ============================================================

print("\n[24] SCIENTIFIC CONSISTENCY SUMMARY")

scientific_core = [
    "516,819",
    "140,157",
    "151,509",
    "225,153",
    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",
    "1,490.7452",
    "4,087.0080",
    "0.979950",
    "0.989932",
    "20.0042%",
    "19.7594%",
    "16.0978%",
]


scientific_found = [
    x for x in scientific_core
    if x in full_text
]


print(
    f"      Core scientific values detected: "
    f"{len(scientific_found)}/{len(scientific_core)}"
)


if len(scientific_found) == len(scientific_core):

    add_pass("All core scientific values detected")

else:

    add_fail("All core scientific values detected")


# ============================================================
# 25. FINAL ASSESSMENT
# ============================================================

print("\n" + "=" * 100)
print("STAGE 41 FINAL CONTENT REVIEW")
print("=" * 100)

print(f"PASS CHECKS : {len(passed)}")
print(f"FAIL CHECKS : {len(failed)}")
print(f"NOTES       : {len(notes)}")


# IMPORTANT:
# Notes do not automatically cause FAIL.
# Only actual failed checks do.

status = "PASS" if len(failed) == 0 else "FAIL"

print(f"\nSTATUS      : {status}")


# ============================================================
# WRITE REPORT
# ============================================================

report_lines = []

report_lines.append(
    "STAGE 41 — FINAL MANUSCRIPT CONTENT REVIEW"
)

report_lines.append("=" * 100)

report_lines.append(
    f"Date/time: {datetime.now().isoformat(timespec='seconds')}"
)

report_lines.append(
    f"Manuscript: {MANUSCRIPT}"
)

report_lines.append(
    f"SHA256: {sha256_file(MANUSCRIPT)}"
)

report_lines.append("")

report_lines.append(
    f"PASS CHECKS: {len(passed)}"
)

report_lines.append(
    f"FAIL CHECKS: {len(failed)}"
)

report_lines.append(
    f"NOTES: {len(notes)}"
)

report_lines.append("")

report_lines.append("STATUS:")
report_lines.append(status)

report_lines.append("")

report_lines.append("PASSED CHECKS:")

for item in passed:

    report_lines.append(
        f"PASS | {item}"
    )


report_lines.append("")

report_lines.append("FAILED CHECKS:")

if failed:

    for item in failed:

        report_lines.append(
            f"FAIL | {item}"
        )

else:

    report_lines.append("NONE")


report_lines.append("")

report_lines.append("MANUAL REVIEW NOTES:")

if notes:

    for item in notes:

        report_lines.append(
            f"NOTE | {item}"
        )

else:

    report_lines.append("NONE")


report_lines.append("")

report_lines.append(
    "IMPORTANT: Stage 41 is a manuscript-content audit. "
    "It does not determine journal acceptance."
)

report_lines.append(
    "Target-journal-specific requirements such as word limits, "
    "reference style, graphical abstract requirements, "
    "blinded-review rules, and submission-system fields "
    "must be checked separately."
)


REPORT.write_text(
    "\n".join(report_lines),
    encoding="utf-8"
)


print("\nREPORT")
print(REPORT)

print("\n" + "=" * 100)

if status == "PASS":

    print("STAGE 41 STATUS: PASS")
    print(
        "The manuscript passed the automated scientific/content "
        "consistency audit."
    )

else:

    print("STAGE 41 STATUS: FAIL")
    print(
        "Resolve the failed content checks before treating "
        "the manuscript as final."
    )

print("=" * 100)

duration = datetime.now() - start

print(f"Audit duration: {duration}")

sys.exit(0 if status == "PASS" else 1)