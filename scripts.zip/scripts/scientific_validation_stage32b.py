# ============================================================
# STAGE 32B — SCIENTIFIC VALIDATION & MANUSCRIPT CONSISTENCY
# ============================================================
#
# Purpose:
#   1. Validate current ExtraTrees test metrics
#   2. Validate residual/bias calculation
#   3. Validate feature importance
#   4. Search for the source of the previous Lag_7 = 61.998% claim
#   5. Search for the source of the previous Mean Bias = -5.48 claim
#   6. Validate Regularized XGBoost results
#   7. Compare manuscript numbers with actual CSV results
#   8. Validate A0-A6 ablation results
#
# No model training is performed.
# Only existing result files are inspected.
# ============================================================

from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

BASELINE_DIR = PROJECT_ROOT / "tfl_baseline_results"
ADVANCED_DIR = PROJECT_ROOT / "tfl_advanced_results"
ABLATION_DIR = PROJECT_ROOT / "tfl_ablation_results_v3"

OUTPUT_DIR = PROJECT_ROOT / "scientific_validation_results"

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

TOLERANCE = 1e-6


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def print_header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def find_csv_files(directory):
    if not directory.exists():
        return []

    return sorted(
        directory.rglob("*.csv")
    )


def safe_read_csv(path):
    try:
        return pd.read_csv(path)
    except Exception as e:
        print(f"[ERROR] Could not read: {path}")
        print(f"        {e}")
        return None


def find_columns(df, candidates):
    """
    Return the first matching column from candidates.
    """
    if df is None:
        return None

    for col in candidates:
        if col in df.columns:
            return col

    return None


def calculate_metrics(actual, predicted):

    actual = pd.to_numeric(
        actual,
        errors="coerce"
    )

    predicted = pd.to_numeric(
        predicted,
        errors="coerce"
    )

    mask = (
        actual.notna()
        & predicted.notna()
    )

    actual = actual[mask].to_numpy()
    predicted = predicted[mask].to_numpy()

    residual = actual - predicted

    mae = np.mean(
        np.abs(residual)
    )

    rmse = np.sqrt(
        np.mean(
            residual ** 2
        )
    )

    ss_res = np.sum(
        residual ** 2
    )

    ss_tot = np.sum(
        (actual - np.mean(actual)) ** 2
    )

    r2 = (
        1 - ss_res / ss_tot
        if ss_tot != 0
        else np.nan
    )

    pearson_r = np.corrcoef(
        actual,
        predicted
    )[0, 1]

    return {
        "N": len(actual),
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "Pearson_r": pearson_r,
        "Mean_Residual": np.mean(residual),
        "Median_Residual": np.median(residual),
        "Std_Residual": np.std(residual),
    }


# ============================================================
# START
# ============================================================

print_header(
    "STAGE 32B — SCIENTIFIC VALIDATION"
)

print(
    "Project root :",
    PROJECT_ROOT
)

print(
    "Baseline dir :",
    BASELINE_DIR
)

print(
    "Advanced dir :",
    ADVANCED_DIR
)

print(
    "Ablation dir :",
    ABLATION_DIR
)

print(
    "Output dir   :",
    OUTPUT_DIR
)


# ============================================================
# 1. CHECK DIRECTORY STRUCTURE
# ============================================================

print_header(
    "1. DIRECTORY AND SOURCE FILE CHECK"
)

directories = {
    "BASELINE": BASELINE_DIR,
    "ADVANCED": ADVANCED_DIR,
    "ABLATION": ABLATION_DIR,
}

for name, directory in directories.items():

    if directory.exists():

        files = find_csv_files(
            directory
        )

        print(
            f"[OK] {name}: {len(files)} CSV files"
        )

        for file in files:
            print(
                "     -",
                file.relative_to(PROJECT_ROOT)
            )

    else:

        print(
            f"[WARNING] {name} directory not found:"
        )

        print(
            "          ",
            directory
        )


# ============================================================
# 2. EXTRA TREES TEST PREDICTIONS
# ============================================================

print_header(
    "2. EXTRA TREES — TEST PREDICTION VALIDATION"
)

prediction_file = (
    BASELINE_DIR
    / "final_test_predictions.csv"
)

if not prediction_file.exists():

    print(
        "[FAIL] final_test_predictions.csv not found."
    )

    prediction_df = None

else:

    prediction_df = safe_read_csv(
        prediction_file
    )

    if prediction_df is not None:

        print(
            "[OK] Loaded:",
            prediction_file
        )

        print(
            "Rows:",
            len(prediction_df)
        )

        print(
            "Columns:",
            list(prediction_df.columns)
        )


# ============================================================
# 3. RECOMPUTE ALL EXTRA TREES METRICS
# ============================================================

print_header(
    "3. RECOMPUTE EXTRA TREES TEST METRICS"
)

if prediction_df is not None:

    actual_col = find_columns(
        prediction_df,
        [
            "TotalFootfall",
            "Actual",
            "y_true",
            "Actual_TotalFootfall"
        ]
    )

    predicted_col = find_columns(
        prediction_df,
        [
            "Predicted_TotalFootfall",
            "Predicted",
            "Prediction",
            "y_pred"
        ]
    )

    residual_col = find_columns(
        prediction_df,
        [
            "Residual",
            "residual"
        ]
    )

    print(
        "Actual column    :",
        actual_col
    )

    print(
        "Predicted column :",
        predicted_col
    )

    print(
        "Residual column  :",
        residual_col
    )

    if actual_col and predicted_col:

        metrics = calculate_metrics(
            prediction_df[actual_col],
            prediction_df[predicted_col]
        )

        for key, value in metrics.items():

            if key == "N":
                print(
                    f"{key:18s}: {value:,}"
                )

            else:
                print(
                    f"{key:18s}: {value:.10f}"
                )

    else:

        print(
            "[FAIL] Actual/predicted columns could not be detected."
        )


# ============================================================
# 4. VALIDATE STORED RESIDUAL COLUMN
# ============================================================

print_header(
    "4. RESIDUAL COLUMN VALIDATION"
)

if (
    prediction_df is not None
    and actual_col
    and predicted_col
    and residual_col
):

    calculated_residual = (
        pd.to_numeric(
            prediction_df[actual_col],
            errors="coerce"
        )
        -
        pd.to_numeric(
            prediction_df[predicted_col],
            errors="coerce"
        )
    )

    stored_residual = pd.to_numeric(
        prediction_df[residual_col],
        errors="coerce"
    )

    difference = (
        calculated_residual
        - stored_residual
    )

    max_difference = np.nanmax(
        np.abs(difference)
    )

    print(
        "Maximum residual difference:",
        max_difference
    )

    if max_difference <= TOLERANCE:

        print(
            "[PASS] Residual = Actual - Predicted"
        )

    else:

        print(
            "[FAIL] Stored residual does not match Actual - Predicted."
        )

    print(
        "\nStored residual statistics:"
    )

    print(
        "Mean   :",
        stored_residual.mean()
    )

    print(
        "Median :",
        stored_residual.median()
    )

    print(
        "Std    :",
        stored_residual.std()
    )


# ============================================================
# 5. SEARCH FOR PREVIOUS BIAS VALUE
# ============================================================

print_header(
    "5. BIAS VALIDATION — PREVIOUS MANUSCRIPT VALUE = -5.48"
)

if prediction_df is not None:

    residual = (
        pd.to_numeric(
            prediction_df[actual_col],
            errors="coerce"
        )
        -
        pd.to_numeric(
            prediction_df[predicted_col],
            errors="coerce"
        )
    )

    bias = residual.mean()

    print(
        "Current test-set mean bias:",
        f"{bias:.10f}"
    )

    print(
        "Previous manuscript value:",
        "-5.48"
    )

    difference = bias - (-5.48)

    print(
        "Difference:",
        f"{difference:.10f}"
    )

    if abs(difference) <= 0.01:

        print(
            "[PASS] Previous bias value is reproduced."
        )

    else:

        print(
            "[WARNING] Previous bias value is NOT reproduced."
        )

        print(
            "Current prediction file gives:",
            f"{bias:.6f}"
        )

        print(
            "Therefore -5.48 must NOT be used"
        )

        print(
            "until its original calculation source is identified."
        )


# ============================================================
# 6. FEATURE IMPORTANCE VALIDATION
# ============================================================

print_header(
    "6. FEATURE IMPORTANCE VALIDATION"
)

feature_file = (
    BASELINE_DIR
    / "feature_importance.csv"
)

if not feature_file.exists():

    print(
        "[FAIL] feature_importance.csv not found."
    )

    feature_df = None

else:

    feature_df = safe_read_csv(
        feature_file
    )

    if feature_df is not None:

        print(
            "[OK] Loaded feature importance."
        )

        print(
            "Rows:",
            len(feature_df)
        )

        print(
            "Columns:",
            list(feature_df.columns)
        )


# ============================================================
# 7. TOP FEATURES
# ============================================================

print_header(
    "7. TOP 20 FEATURE IMPORTANCES"
)

if feature_df is not None:

    feature_df["Importance"] = pd.to_numeric(
        feature_df["Importance"],
        errors="coerce"
    )

    feature_df = feature_df.dropna(
        subset=["Importance"]
    )

    feature_df = feature_df.sort_values(
        "Importance",
        ascending=False
    ).reset_index(
        drop=True
    )

    total_importance = (
        feature_df["Importance"].sum()
    )

    print(
        "Total importance:",
        f"{total_importance:.12f}"
    )

    print(
        "\nTop 20:"
    )

    top20 = feature_df.head(20).copy()

    top20["Percentage"] = (
        top20["Importance"]
        / total_importance
        * 100
    )

    print(
        top20[
            [
                "Feature",
                "Importance",
                "Percentage"
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 8. CHECK LAG_7 CLAIM
# ============================================================

print_header(
    "8. LAG_7 VALIDATION — PREVIOUS CLAIM = 61.998%"
)

if feature_df is not None:

    lag7 = feature_df[
        feature_df["Feature"]
        .astype(str)
        .str.contains(
            "Lag_7",
            case=False,
            regex=False
        )
    ]

    if len(lag7) > 0:

        row = lag7.iloc[0]

        lag7_importance = float(
            row["Importance"]
        )

        lag7_percentage = (
            lag7_importance
            / total_importance
            * 100
        )

        print(
            "Lag_7 feature:",
            row["Feature"]
        )

        print(
            "Raw importance:",
            f"{lag7_importance:.12f}"
        )

        print(
            "Normalized percentage:",
            f"{lag7_percentage:.6f}%"
        )

        print(
            "Previous manuscript claim:",
            "61.998%"
        )

        if abs(
            lag7_percentage - 61.998
        ) <= 0.01:

            print(
                "[PASS] Lag_7 = 61.998% reproduced."
            )

        else:

            print(
                "[WARNING] Lag_7 = 61.998% is NOT reproduced."
            )

            print(
                "Current file gives:",
                f"{lag7_percentage:.6f}%"
            )

            print(
                "DO NOT use 61.998% in the final manuscript"
            )

    else:

        print(
            "[FAIL] Lag_7 not found."
        )


# ============================================================
# 9. LAG FEATURE SUMMARY
# ============================================================

print_header(
    "9. LAG AND ROLLING FEATURE SUMMARY"
)

if feature_df is not None:

    lag_features = feature_df[
        feature_df["Feature"]
        .astype(str)
        .str.contains(
            "Lag_|Rolling",
            case=False,
            regex=True
        )
    ].copy()

    lag_features["Percentage"] = (
        lag_features["Importance"]
        / total_importance
        * 100
    )

    print(
        lag_features[
            [
                "Feature",
                "Importance",
                "Percentage"
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 10. BASELINE COMPARISON TABLE
# ============================================================

print_header(
    "10. BASELINE MODEL COMPARISON VALIDATION"
)

comparison_file = (
    BASELINE_DIR
    / "baseline_comparison_table.csv"
)

if not comparison_file.exists():

    print(
        "[FAIL] baseline_comparison_table.csv not found."
    )

    comparison_df = None

else:

    comparison_df = safe_read_csv(
        comparison_file
    )

    if comparison_df is not None:

        print(
            "[OK] Loaded baseline comparison table."
        )

        print(
            comparison_df.to_string(
                index=False
            )
        )


# ============================================================
# 11. EXTRA TREES VALIDATION AGAINST COMPARISON TABLE
# ============================================================

print_header(
    "11. EXTRA TREES — CROSS-CHECK"
)

if comparison_df is not None:

    et_rows = comparison_df[
        comparison_df["Model"]
        .astype(str)
        .str.lower()
        .eq("extratrees")
    ]

    if len(et_rows) > 0:

        et = et_rows.iloc[0]

        print(
            "Stored Test MAE :",
            et["Test_MAE"]
        )

        print(
            "Stored Test RMSE:",
            et["Test_RMSE"]
        )

        print(
            "Stored Test R²  :",
            et["Test_R2"]
        )

        print(
            "Stored Pearson r:",
            et["Test_Pearson_r"]
        )

        if prediction_df is not None:

            calculated = calculate_metrics(
                prediction_df[actual_col],
                prediction_df[predicted_col]
            )

            checks = {
                "MAE": (
                    calculated["MAE"],
                    float(et["Test_MAE"])
                ),
                "RMSE": (
                    calculated["RMSE"],
                    float(et["Test_RMSE"])
                ),
                "R2": (
                    calculated["R2"],
                    float(et["Test_R2"])
                ),
                "Pearson_r": (
                    calculated["Pearson_r"],
                    float(et["Test_Pearson_r"])
                ),
            }

            print("\nCross-check:")

            for metric, values in checks.items():

                calculated_value, stored_value = values

                diff = (
                    calculated_value
                    - stored_value
                )

                status = (
                    "PASS"
                    if abs(diff) <= 1e-5
                    else "FAIL"
                )

                print(
                    f"{metric:12s} "
                    f"calculated={calculated_value:.10f} "
                    f"stored={stored_value:.10f} "
                    f"diff={diff:.10f} "
                    f"[{status}]"
                )

    else:

        print(
            "[FAIL] ExtraTrees row not found."
        )


# ============================================================
# 12. SEARCH ADVANCED RESULTS
# ============================================================

print_header(
    "12. ADVANCED RESULTS — REGULARIZED XGBOOST SEARCH"
)

advanced_files = find_csv_files(
    ADVANCED_DIR
)

print(
    "Advanced CSV count:",
    len(advanced_files)
)

for file in advanced_files:

    print(
        "\nFILE:",
        file.relative_to(PROJECT_ROOT)
    )

    df = safe_read_csv(
        file
    )

    if df is None:
        continue

    print(
        "Columns:",
        list(df.columns)
    )

    # Search for rows mentioning XGBoost
    xgb_found = False

    for col in df.columns:

        if (
            df[col].dtype == "object"
            or str(df[col].dtype).startswith("string")
        ):

            mask = (
                df[col]
                .astype(str)
                .str.contains(
                    "xgboost|xgb",
                    case=False,
                    regex=True,
                    na=False
                )
            )

            if mask.any():

                xgb_found = True

                print(
                    "\n[XGBOOST FOUND]"
                )

                print(
                    df.loc[
                        mask
                    ].to_string(
                        index=False
                    )
                )

    if not xgb_found:

        print(
            "No explicit XGBoost row found."
        )


# ============================================================
# 13. SPECIFIC ADVANCED FILES
# ============================================================

print_header(
    "13. KEY ADVANCED RESULT FILES"
)

key_advanced_files = [
    "advanced_test_results.csv",
    "advanced_validation_results.csv",
    "baseline_vs_advanced.csv",
    "advanced_experiment_configuration.csv",
]

for filename in key_advanced_files:

    path = (
        ADVANCED_DIR
        / filename
    )

    if path.exists():

        print(
            "\n" + "-" * 80
        )

        print(
            "FILE:",
            filename
        )

        df = safe_read_csv(
            path
        )

        if df is not None:

            print(
                "Shape:",
                df.shape
            )

            print(
                "Columns:",
                list(df.columns)
            )

            print(
                df.head(20).to_string(
                    index=False
                )
            )

    else:

        print(
            f"[NOT FOUND] {filename}"
        )


# ============================================================
# 14. SEARCH FOR -5.48 AND 61.998 IN ALL CSV FILES
# ============================================================

print_header(
    "14. SEARCH ALL RESULT CSVs FOR PREVIOUS MANUSCRIPT VALUES"
)

all_search_dirs = [
    BASELINE_DIR,
    ADVANCED_DIR,
    ABLATION_DIR,
]

all_csvs = []

for directory in all_search_dirs:

    all_csvs.extend(
        find_csv_files(directory)
    )

# Remove duplicates
all_csvs = sorted(
    set(all_csvs)
)

print(
    "CSV files scanned:",
    len(all_csvs)
)

targets = [
    -5.48,
    61.998,
]

matches = []

for path in all_csvs:

    df = safe_read_csv(
        path
    )

    if df is None:
        continue

    for col in df.columns:

        numeric = pd.to_numeric(
            df[col],
            errors="coerce"
        )

        for target in targets:

            mask = np.isclose(
                numeric,
                target,
                atol=1e-4,
                rtol=0
            )

            if mask.any():

                for idx in df.index[mask]:

                    matches.append(
                        {
                            "File": str(
                                path.relative_to(
                                    PROJECT_ROOT
                                )
                            ),
                            "Column": col,
                            "Row": int(idx),
                            "Value": df.loc[
                                idx,
                                col
                            ],
                            "Target": target,
                        }
                    )


if matches:

    match_df = pd.DataFrame(
        matches
    )

    print(
        match_df.to_string(
            index=False
        )
    )

    match_df.to_csv(
        OUTPUT_DIR
        / "previous_claim_matches.csv",
        index=False
    )

    print(
        "\n[SAVED] previous_claim_matches.csv"
    )

else:

    print(
        "[INFO] No exact numeric matches found."
    )


# ============================================================
# 15. A0-A6 ABLATION VALIDATION
# ============================================================

print_header(
    "15. A0-A6 ABLATION VALIDATION"
)

ablation_candidates = [
    ABLATION_DIR
    / "MANUSCRIPT_ABLATION_TABLE_V3.csv",
]

ablation_file = None

for candidate in ablation_candidates:

    if candidate.exists():

        ablation_file = candidate
        break


if ablation_file is None:

    # Search automatically
    candidates = find_csv_files(
        ABLATION_DIR
    )

    for candidate in candidates:

        name = candidate.name.lower()

        if (
            "ablation" in name
            or "manuscript" in name
        ):

            ablation_file = candidate
            break


if ablation_file is None:

    print(
        "[WARNING] A0-A6 ablation CSV not found."
    )

    ablation_df = None

else:

    print(
        "[OK] Ablation file:",
        ablation_file
    )

    ablation_df = safe_read_csv(
        ablation_file
    )

    if ablation_df is not None:

        print(
            "Shape:",
            ablation_df.shape
        )

        print(
            "Columns:",
            list(ablation_df.columns)
        )

        print(
            "\nAblation table:"
        )

        print(
            ablation_df.to_string(
                index=False
            )
        )


# ============================================================
# 16. CHECK EXPECTED A0-A6 VALUES
# ============================================================

print_header(
    "16. A0-A6 EXPECTED VALUE CROSS-CHECK"
)

expected_ablation = {
    "A0": {
        "MAE": 122992.88,
        "RMSE": 162913.35,
        "R2": 0.894465,
        "Validation_RMSE": 304115.96,
    },

    "A1": {
        "MAE": 112264.59,
        "RMSE": 142564.19,
        "R2": 0.919183,
        "Validation_RMSE": 304466.46,
    },

    "A2": {
        "MAE": 141651.33,
        "RMSE": 191072.47,
        "R2": 0.854829,
        "Validation_RMSE": 344015.70,
    },

    "A3": {
        "MAE": 120734.25,
        "RMSE": 151573.33,
        "R2": 0.908646,
        "Validation_RMSE": 286820.40,
    },

    "A4": {
        "MAE": 177242.61,
        "RMSE": 246106.69,
        "R2": 0.759159,
        "Validation_RMSE": 360413.03,
    },

    "A5": {
        "MAE": 207047.64,
        "RMSE": 264677.11,
        "R2": 0.721442,
        "Validation_RMSE": 424534.49,
    },

    "A6": {
        "MAE": 245690.39,
        "RMSE": 583663.70,
        "R2": -0.354592,
        "Validation_RMSE": 410610.65,
    },
}

if ablation_df is not None:

    print(
        "Available columns:"
    )

    print(
        list(ablation_df.columns)
    )

    print(
        "\nRaw ablation data:"
    )

    print(
        ablation_df.to_string(
            index=False
        )
    )


# ============================================================
# 17. SAVE VALIDATION SUMMARY
# ============================================================

print_header(
    "17. SAVE SCIENTIFIC VALIDATION SUMMARY"
)

summary_rows = []

# ExtraTrees
if prediction_df is not None:

    metrics = calculate_metrics(
        prediction_df[actual_col],
        prediction_df[predicted_col]
    )

    summary_rows.append(
        {
            "Item": "ExtraTrees Test",
            "Metric": "MAE",
            "Value": metrics["MAE"],
            "Status": "VERIFIED",
        }
    )

    summary_rows.append(
        {
            "Item": "ExtraTrees Test",
            "Metric": "RMSE",
            "Value": metrics["RMSE"],
            "Status": "VERIFIED",
        }
    )

    summary_rows.append(
        {
            "Item": "ExtraTrees Test",
            "Metric": "R2",
            "Value": metrics["R2"],
            "Status": "VERIFIED",
        }
    )

    summary_rows.append(
        {
            "Item": "ExtraTrees Test",
            "Metric": "Pearson_r",
            "Value": metrics["Pearson_r"],
            "Status": "VERIFIED",
        }
    )

    summary_rows.append(
        {
            "Item": "ExtraTrees Test",
            "Metric": "Mean_Bias",
            "Value": metrics["Mean_Residual"],
            "Status": "CURRENT_FILE",
        }
    )


# Feature importance
if feature_df is not None:

    for _, row in feature_df.head(10).iterrows():

        summary_rows.append(
            {
                "Item": "Feature Importance",
                "Metric": row["Feature"],
                "Value": row["Importance"],
                "Status": "CURRENT_FILE",
            }
        )


summary_df = pd.DataFrame(
    summary_rows
)

summary_file = (
    OUTPUT_DIR
    / "scientific_validation_summary.csv"
)

summary_df.to_csv(
    summary_file,
    index=False
)

print(
    "[SAVED]",
    summary_file
)


# ============================================================
# 18. FINAL SCIENTIFIC STATUS
# ============================================================

print_header(
    "18. FINAL STAGE 32B STATUS"
)

print(
    "\nVerified from current files:"
)

if prediction_df is not None:

    metrics = calculate_metrics(
        prediction_df[actual_col],
        prediction_df[predicted_col]
    )

    print(
        f"  ExtraTrees MAE       = {metrics['MAE']:.4f}"
    )

    print(
        f"  ExtraTrees RMSE      = {metrics['RMSE']:.4f}"
    )

    print(
        f"  ExtraTrees R²        = {metrics['R2']:.6f}"
    )

    print(
        f"  ExtraTrees Pearson r = {metrics['Pearson_r']:.6f}"
    )

    print(
        f"  Mean bias             = {metrics['Mean_Residual']:.6f}"
    )


if feature_df is not None:

    top = feature_df.head(10).copy()

    print(
        "\nCurrent top features:"
    )

    for _, row in top.iterrows():

        print(
            f"  {row['Feature']:<45s}"
            f" {row['Importance']:.8f}"
        )


print(
    "\nIMPORTANT:"
)

print(
    "1. Do not use the old Lag_7 = 61.998% claim unless reproduced."
)

print(
    "2. Do not use the old Mean Bias = -5.48 unless its source is identified."
)

print(
    "3. Regularized XGBoost must be taken from the advanced results, not invented from baseline CSV."
)

print(
    "4. A0-A6 results must remain separate from the main TotalFootfall experiment."
)

print(
    "\n[SUCCESS] Stage 32B validation completed."
)

print(
    "\nNext stage:"
)

print(
    "STAGE 32C -> Final Scientific Reconciliation + Figure Correction"
)

print(
    "=" * 100
)