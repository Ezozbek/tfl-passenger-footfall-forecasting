# ============================================================
# ablation_tfl_forecasting_v3.py
# ============================================================
#
# TfL Tube Journey Forecasting
# Leakage-Controlled Ablation Study - Version 3
#
# Main corrections from V2:
#
#   1. Correctly parses TravelDate in YYYYMMDD format.
#   2. Validates the resulting chronological date range.
#   3. Uses the existing DayOfWeek column as a diagnostic check.
#   4. Creates calendar features from correctly parsed dates.
#   5. Removes constant calendar features automatically.
#   6. Keeps lag/rolling features leakage-controlled.
#   7. Uses fixed chronological train/validation/test boundaries.
#   8. Uses train-only median imputation.
#   9. Performs feature-variation diagnostics.
#  10. Performs identical-prediction diagnostics.
#  11. Calculates ablation contribution relative to Full model.
#
# Dataset:
#   Journeys_2025_2026 .csv
#
# Expected columns:
#   TravelDate
#   DayOfWeek
#   TubeJourneyCount
#   BusJourneyCount
#
# Output:
#
#   tfl_ablation_results_v3/
#
#       ablation_results_v3.csv
#       ablation_predictions_v3.csv
#       feature_summary_v3.csv
#       feature_diagnostics_v3.csv
#       prediction_diagnostics_v3.csv
#       split_summary_v3.csv
#       date_validation_v3.csv
#
# ============================================================


from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd

from sklearn.ensemble import HistGradientBoostingRegressor

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

warnings.filterwarnings("ignore")


# ============================================================
# 1. CONFIGURATION
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent

DATA_FILE = (
    PROJECT_DIR
    / "Journeys_2025_2026 .csv"
)

OUTPUT_DIR = (
    PROJECT_DIR
    / "tfl_ablation_results_v3"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

RANDOM_STATE = 42


# ------------------------------------------------------------
# Temporal split
# ------------------------------------------------------------

TRAIN_RATIO = 0.70
VALIDATION_RATIO = 0.15
TEST_RATIO = 0.15

assert abs(
    TRAIN_RATIO
    + VALIDATION_RATIO
    + TEST_RATIO
    - 1.0
) < 1e-9


# ------------------------------------------------------------
# Expected date format
# ------------------------------------------------------------

EXPECTED_DATE_FORMAT = "%Y%m%d"


# ------------------------------------------------------------
# Lag configuration
# ------------------------------------------------------------

LAG_VALUES = [
    1,
    2,
    3,
    6,
    12,
    24,
    48,
    72,
    168,
]


# ------------------------------------------------------------
# Rolling windows
# ------------------------------------------------------------

ROLLING_WINDOWS = [
    3,
    6,
    12,
    24,
    48,
    168,
]


# ============================================================
# 2. COLUMN CANDIDATES
# ============================================================

TIME_CANDIDATES = [
    "TravelDate",
    "Timestamp",
    "timestamp",
    "Datetime",
    "datetime",
    "DateTime",
    "date_time",
    "Date",
    "date",
]


TARGET_CANDIDATES = [
    "TubeJourneyCount",
    "Demand",
    "demand",
    "Trips",
    "trips",
    "Entry_Count",
    "entry_count",
    "Volume",
    "volume",
]


DAY_OF_WEEK_CANDIDATES = [
    "DayOfWeek",
    "day_of_week",
    "Weekday",
    "weekday",
]


# ============================================================
# 3. PRINT FUNCTIONS
# ============================================================

def print_header(title):

    print("\n")
    print("=" * 100)
    print(title)
    print("=" * 100)


def print_section(title):

    print("\n")
    print("-" * 100)
    print(title)
    print("-" * 100)


# ============================================================
# 4. COLUMN DETECTION
# ============================================================

def find_column(
    df,
    candidates,
    required=True
):

    lower_map = {
        str(c).strip().lower(): c
        for c in df.columns
    }

    for candidate in candidates:

        key = candidate.strip().lower()

        if key in lower_map:

            return lower_map[key]

    if required:

        raise ValueError(
            "\nRequired column was not found.\n"
            f"Candidates: {candidates}\n"
            f"Available columns: {list(df.columns)}"
        )

    return None


def detect_time_column(df):

    col = find_column(
        df,
        TIME_CANDIDATES,
        required=False
    )

    if col is not None:

        return col

    for c in df.columns:

        name = str(c).lower()

        if (
            "traveldate" in name
            or "timestamp" in name
            or "datetime" in name
            or name == "date"
        ):

            return c

    raise ValueError(
        "Could not detect datetime column."
    )


def detect_target_column(df):

    col = find_column(
        df,
        TARGET_CANDIDATES,
        required=False
    )

    if col is not None:

        return col

    for c in df.columns:

        name = str(c).lower()

        if (
            "tube" in name
            and "count" in name
        ):

            return c

        if "journey" in name:

            return c

        if "demand" in name:

            return c

    raise ValueError(
        "Could not detect target column."
    )


# ============================================================
# 5. LOAD DATASET
# ============================================================

print_header(
    "TfL FORECASTING - ABLATION STUDY V3"
)

print_section(
    "LOADING DATASET"
)

if not DATA_FILE.exists():

    raise FileNotFoundError(
        f"Dataset not found:\n{DATA_FILE}"
    )

print(
    "Dataset:",
    DATA_FILE
)

df = pd.read_csv(
    DATA_FILE
)

print(
    f"Rows    : {len(df):,}"
)

print(
    f"Columns : {len(df.columns)}"
)

print(
    "\nColumns:"
)

for c in df.columns:

    print(
        "  -",
        c
    )


# ============================================================
# 6. DETECT COLUMNS
# ============================================================

TIME_COL = detect_time_column(df)

TARGET_COL = detect_target_column(df)

DAY_OF_WEEK_COL = find_column(
    df,
    DAY_OF_WEEK_CANDIDATES,
    required=False
)

print_section(
    "DETECTED COLUMNS"
)

print(
    "Travel date:",
    TIME_COL
)

print(
    "Target:",
    TARGET_COL
)

print(
    "Existing DayOfWeek:",
    DAY_OF_WEEK_COL
)


# ============================================================
# 7. CORRECT TRAVEL DATE PARSING
# ============================================================

print_section(
    "CORRECTING AND VALIDATING TRAVEL DATE"
)

raw_date_sample = (
    df[TIME_COL]
    .astype(str)
    .head(10)
    .tolist()
)

print(
    "Raw date sample:"
)

for value in raw_date_sample:

    print(
        "  ",
        value
    )


# ------------------------------------------------------------
# First attempt:
# YYYYMMDD
# ------------------------------------------------------------

raw_date = (
    df[TIME_COL]
    .astype(str)
    .str.strip()
)


# Remove possible decimal .0
raw_date = (
    raw_date
    .str.replace(
        r"\.0$",
        "",
        regex=True
    )
)


parsed_date = pd.to_datetime(
    raw_date,
    format=EXPECTED_DATE_FORMAT,
    errors="coerce"
)


# ------------------------------------------------------------
# If YYYYMMDD parsing fails heavily, try standard parsing.
# ------------------------------------------------------------

parse_success_rate = (
    parsed_date.notna().mean()
)

print(
    f"\nYYYYMMDD parse success rate: "
    f"{parse_success_rate * 100:.2f}%"
)


if parse_success_rate < 0.95:

    print(
        "WARNING: YYYYMMDD parsing success "
        "rate below 95%."
    )

    fallback_date = pd.to_datetime(
        raw_date,
        errors="coerce"
    )

    fallback_success_rate = (
        fallback_date.notna().mean()
    )

    print(
        f"Fallback parse success rate: "
        f"{fallback_success_rate * 100:.2f}%"
    )

    if (
        fallback_success_rate
        > parse_success_rate
    ):

        parsed_date = fallback_date


# ------------------------------------------------------------
# Validate parsed date
# ------------------------------------------------------------

invalid_dates = (
    parsed_date.isna().sum()
)

if invalid_dates > 0:

    print(
        f"Invalid dates: {invalid_dates}"
    )

    df = df.loc[
        parsed_date.notna()
    ].copy()

    parsed_date = (
        parsed_date[
            parsed_date.notna()
        ]
    )


df[TIME_COL] = (
    parsed_date.values
)


# ------------------------------------------------------------
# CRITICAL sanity check
# ------------------------------------------------------------

min_date = df[TIME_COL].min()

max_date = df[TIME_COL].max()

print(
    "\nParsed date range:"
)

print(
    "Minimum:",
    min_date
)

print(
    "Maximum:",
    max_date
)


# ------------------------------------------------------------
# Reject obviously incorrect dates
# ------------------------------------------------------------

if min_date.year < 2000:

    raise ValueError(
        "\nDATE PARSING ERROR:\n"
        f"Minimum parsed date is {min_date}.\n"
        "Expected a modern TfL date such as "
        "2025-01-01.\n"
        "Check the TravelDate format."
    )


if max_date.year > 2100:

    raise ValueError(
        "\nDATE PARSING ERROR:\n"
        f"Maximum parsed date is {max_date}.\n"
        "Check the TravelDate format."
    )


# ------------------------------------------------------------
# Date ordering
# ------------------------------------------------------------

df = (
    df
    .sort_values(
        TIME_COL
    )
    .reset_index(
        drop=True
    )
)


# ------------------------------------------------------------
# Save date validation
# ------------------------------------------------------------

date_validation = pd.DataFrame(
    {
        "Raw_Date": raw_date,
        "Parsed_Date": pd.to_datetime(
            df[TIME_COL]
        )
    }
)

date_validation.to_csv(
    OUTPUT_DIR
    / "date_validation_v3.csv",
    index=False
)


print(
    "\nFirst parsed dates:"
)

print(
    df[
        [TIME_COL]
    ]
    .head(10)
    .to_string(
        index=False
    )
)


# ============================================================
# 8. TARGET VALIDATION
# ============================================================

print_section(
    "TARGET VALIDATION"
)

df[TARGET_COL] = pd.to_numeric(
    df[TARGET_COL],
    errors="coerce"
)

invalid_target = (
    df[TARGET_COL]
    .isna()
    .sum()
)

if invalid_target > 0:

    print(
        "Removing invalid target rows:",
        invalid_target
    )

    df = df.dropna(
        subset=[TARGET_COL]
    ).copy()


print(
    "Target mean:",
    f"{df[TARGET_COL].mean():.4f}"
)

print(
    "Target std:",
    f"{df[TARGET_COL].std():.4f}"
)

print(
    "Target minimum:",
    f"{df[TARGET_COL].min():.4f}"
)

print(
    "Target maximum:",
    f"{df[TARGET_COL].max():.4f}"
)

print(
    "Zero target count:",
    int(
        (
            df[TARGET_COL] == 0
        ).sum()
    )
)


# ============================================================
# 9. DUPLICATE TIMESTAMPS
# ============================================================

duplicate_count = (
    df
    .duplicated(
        subset=[TIME_COL]
    )
    .sum()
)

print(
    "\nDuplicate timestamps:",
    duplicate_count
)

if duplicate_count > 0:

    raise ValueError(
        "Duplicate TravelDate values detected. "
        "Resolve duplicates before forecasting."
    )


# ============================================================
# 10. CHECK EXISTING DAY OF WEEK
# ============================================================

print_section(
    "DAY-OF-WEEK VALIDATION"
)

if DAY_OF_WEEK_COL is not None:

    existing_dow = pd.to_numeric(
        df[DAY_OF_WEEK_COL],
        errors="coerce"
    )

    calculated_dow = (
        df[TIME_COL]
        .dt.dayofweek
    )

    valid_mask = (
        existing_dow.notna()
    )

    if valid_mask.sum() > 0:

        agreement = (
            existing_dow[valid_mask]
            .astype(int)
            .values
            ==
            calculated_dow[valid_mask]
            .values
        )

        agreement_rate = (
            agreement.mean()
        )

        print(
            "Existing DayOfWeek vs "
            "calculated datetime agreement:",
            f"{agreement_rate * 100:.2f}%"
        )

        if agreement_rate < 0.95:

            print(
                "WARNING: DayOfWeek column differs "
                "from datetime-derived weekday."
            )

        else:

            print(
                "DayOfWeek validation PASSED."
            )

else:

    print(
        "No existing DayOfWeek column found."
    )


# ============================================================
# 11. FIXED TEMPORAL SPLIT
# ============================================================

print_section(
    "CREATING FIXED TEMPORAL SPLIT"
)

n_total = len(df)

train_end = int(
    n_total
    * TRAIN_RATIO
)

validation_end = int(
    n_total
    * (
        TRAIN_RATIO
        + VALIDATION_RATIO
    )
)

df["_split"] = "test"

df.loc[
    :train_end - 1,
    "_split"
] = "train"

df.loc[
    train_end:validation_end - 1,
    "_split"
] = "validation"


train_raw = df[
    df["_split"] == "train"
].copy()

validation_raw = df[
    df["_split"] == "validation"
].copy()

test_raw = df[
    df["_split"] == "test"
].copy()


print(
    f"Total      : {len(df):,}"
)

print(
    f"Train      : {len(train_raw):,}"
)

print(
    f"Validation : {len(validation_raw):,}"
)

print(
    f"Test       : {len(test_raw):,}"
)

print(
    "\nTrain period:"
)

print(
    train_raw[TIME_COL].min(),
    "->",
    train_raw[TIME_COL].max()
)

print(
    "\nValidation period:"
)

print(
    validation_raw[TIME_COL].min(),
    "->",
    validation_raw[TIME_COL].max()
)

print(
    "\nTest period:"
)

print(
    test_raw[TIME_COL].min(),
    "->",
    test_raw[TIME_COL].max()
)


# ============================================================
# 12. SAVE SPLIT SUMMARY
# ============================================================

split_summary = pd.DataFrame(
    [
        {
            "Split": "Train",
            "Rows": len(train_raw),
            "Start": train_raw[TIME_COL].min(),
            "End": train_raw[TIME_COL].max(),
        },
        {
            "Split": "Validation",
            "Rows": len(validation_raw),
            "Start": validation_raw[TIME_COL].min(),
            "End": validation_raw[TIME_COL].max(),
        },
        {
            "Split": "Test",
            "Rows": len(test_raw),
            "Start": test_raw[TIME_COL].min(),
            "End": test_raw[TIME_COL].max(),
        },
    ]
)

split_summary.to_csv(
    OUTPUT_DIR
    / "split_summary_v3.csv",
    index=False
)


# ============================================================
# 13. CALENDAR FEATURES
# ============================================================

print_section(
    "CREATING CALENDAR FEATURES"
)

df["year"] = (
    df[TIME_COL].dt.year
)

df["month"] = (
    df[TIME_COL].dt.month
)

df["day"] = (
    df[TIME_COL].dt.day
)

df["day_of_week"] = (
    df[TIME_COL].dt.dayofweek
)

df["day_of_year"] = (
    df[TIME_COL].dt.dayofyear
)

df["week_of_year"] = (
    df[TIME_COL]
    .dt.isocalendar()
    .week
    .astype(int)
)

df["hour"] = (
    df[TIME_COL].dt.hour
)

df["minute"] = (
    df[TIME_COL].dt.minute
)

df["is_weekend"] = (
    df["day_of_week"] >= 5
).astype(int)

df["is_month_start"] = (
    df[TIME_COL]
    .dt.is_month_start
    .astype(int)
)

df["is_month_end"] = (
    df[TIME_COL]
    .dt.is_month_end
    .astype(int)
)


# ============================================================
# 14. CYCLIC FEATURES
# ============================================================

df["hour_sin"] = np.sin(
    2
    * np.pi
    * df["hour"]
    / 24
)

df["hour_cos"] = np.cos(
    2
    * np.pi
    * df["hour"]
    / 24
)

df["dow_sin"] = np.sin(
    2
    * np.pi
    * df["day_of_week"]
    / 7
)

df["dow_cos"] = np.cos(
    2
    * np.pi
    * df["day_of_week"]
    / 7
)

df["month_sin"] = np.sin(
    2
    * np.pi
    * df["month"]
    / 12
)

df["month_cos"] = np.cos(
    2
    * np.pi
    * df["month"]
    / 12
)


CALENDAR_FEATURES_ALL = [

    "year",
    "month",
    "day",
    "day_of_week",
    "day_of_year",
    "week_of_year",
    "hour",
    "minute",

    "is_weekend",
    "is_month_start",
    "is_month_end",

    "hour_sin",
    "hour_cos",

    "dow_sin",
    "dow_cos",

    "month_sin",
    "month_cos",
]


# ============================================================
# 15. CALENDAR FEATURE VARIATION CHECK
# ============================================================

print_section(
    "CALENDAR FEATURE VARIATION CHECK"
)

CALENDAR_FEATURES = []

calendar_diagnostics = []

for feature in CALENDAR_FEATURES_ALL:

    unique_count = (
        df[feature]
        .nunique(
            dropna=True
        )
    )

    minimum = (
        df[feature]
        .min()
    )

    maximum = (
        df[feature]
        .max()
    )

    is_constant = (
        unique_count <= 1
    )

    calendar_diagnostics.append(
        {
            "Feature": feature,
            "Unique_Values": unique_count,
            "Minimum": minimum,
            "Maximum": maximum,
            "Constant": is_constant,
        }
    )

    if not is_constant:

        CALENDAR_FEATURES.append(
            feature
        )

    print(
        f"{feature:20s}"
        f" unique={unique_count:4d}"
        f" min={minimum}"
        f" max={maximum}"
        f" constant={is_constant}"
    )


calendar_diagnostics_df = pd.DataFrame(
    calendar_diagnostics
)


# ============================================================
# 16. LAG FEATURES
# ============================================================

print_section(
    "CREATING LAG FEATURES"
)

LAG_FEATURES = []

for lag in LAG_VALUES:

    feature_name = (
        f"lag_{lag}"
    )

    df[feature_name] = (
        df[TARGET_COL]
        .shift(lag)
    )

    LAG_FEATURES.append(
        feature_name
    )


# ============================================================
# 17. ROLLING FEATURES
# ============================================================

print_section(
    "CREATING LEAKAGE-CONTROLLED ROLLING FEATURES"
)

ROLLING_FEATURES = []

shifted_target = (
    df[TARGET_COL]
    .shift(1)
)

for window in ROLLING_WINDOWS:

    mean_name = (
        f"rolling_mean_{window}"
    )

    std_name = (
        f"rolling_std_{window}"
    )

    df[mean_name] = (
        shifted_target
        .rolling(
            window=window,
            min_periods=window
        )
        .mean()
    )

    df[std_name] = (
        shifted_target
        .rolling(
            window=window,
            min_periods=window
        )
        .std()
    )

    ROLLING_FEATURES.extend(
        [
            mean_name,
            std_name,
        ]
    )


# ============================================================
# 18. EXOGENOUS FEATURES
# ============================================================

print_section(
    "IDENTIFYING EXOGENOUS FEATURES"
)

GENERATED_FEATURES = set(
    CALENDAR_FEATURES_ALL
    + LAG_FEATURES
    + ROLLING_FEATURES
)

EXCLUDED_COLUMNS = {
    TIME_COL,
    TARGET_COL,
    "_split",
}

numeric_columns = (
    df
    .select_dtypes(
        include=[np.number]
    )
    .columns
    .tolist()
)

EXOGENOUS_FEATURES = [

    c

    for c in numeric_columns

    if (
        c not in EXCLUDED_COLUMNS
        and c not in GENERATED_FEATURES
    )
]


print(
    "Exogenous features:"
)

if EXOGENOUS_FEATURES:

    for feature in EXOGENOUS_FEATURES:

        print(
            "  -",
            feature
        )

else:

    print(
        "  None"
    )


# ============================================================
# 19. FEATURE GROUP SUMMARY
# ============================================================

print_section(
    "FEATURE GROUP SUMMARY"
)

print(
    "Calendar features:",
    len(CALENDAR_FEATURES)
)

print(
    "Lag features:",
    len(LAG_FEATURES)
)

print(
    "Rolling features:",
    len(ROLLING_FEATURES)
)

print(
    "Exogenous features:",
    len(EXOGENOUS_FEATURES)
)


# ============================================================
# 20. FULL FEATURE SET
# ============================================================

FULL_FEATURES = list(
    dict.fromkeys(
        CALENDAR_FEATURES
        + LAG_FEATURES
        + ROLLING_FEATURES
        + EXOGENOUS_FEATURES
    )
)


print(
    "Full feature count:",
    len(FULL_FEATURES)
)


# ============================================================
# 21. ABLATION EXPERIMENTS
# ============================================================

EXPERIMENTS = {

    "A0_Full": {

        "description":
            "Full calendar + lag + rolling + exogenous",

        "features":
            FULL_FEATURES,
    },

    "A1_No_Calendar": {

        "description":
            "Without calendar and cyclic features",

        "features":
            (
                LAG_FEATURES
                + ROLLING_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A2_No_Lag": {

        "description":
            "Without autoregressive lag features",

        "features":
            (
                CALENDAR_FEATURES
                + ROLLING_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A3_No_Rolling": {

        "description":
            "Without rolling statistical features",

        "features":
            (
                CALENDAR_FEATURES
                + LAG_FEATURES
                + EXOGENOUS_FEATURES
            ),
    },

    "A4_No_Exogenous": {

        "description":
            "Without external numerical variables",

        "features":
            (
                CALENDAR_FEATURES
                + LAG_FEATURES
                + ROLLING_FEATURES
            ),
    },

    "A5_Minimal_AR": {

        "description":
            "Only lag and rolling demand features",

        "features":
            (
                LAG_FEATURES
                + ROLLING_FEATURES
            ),
    },

    "A6_Calendar_Only": {

        "description":
            "Only calendar and cyclic features",

        "features":
            CALENDAR_FEATURES,
    },
}


# ============================================================
# 22. MODEL
# ============================================================

def build_model():

    return HistGradientBoostingRegressor(

        learning_rate=0.05,

        max_iter=400,

        max_leaf_nodes=31,

        max_depth=None,

        min_samples_leaf=20,

        l2_regularization=0.1,

        random_state=RANDOM_STATE,
    )


# ============================================================
# 23. METRICS
# ============================================================

def calculate_rmse(
    y_true,
    y_pred
):

    return float(
        np.sqrt(
            mean_squared_error(
                y_true,
                y_pred
            )
        )
    )


def calculate_mape(
    y_true,
    y_pred
):

    y_true = np.asarray(
        y_true,
        dtype=float
    )

    y_pred = np.asarray(
        y_pred,
        dtype=float
    )

    mask = (
        np.abs(y_true)
        > 1e-8
    )

    if mask.sum() == 0:

        return np.nan

    return float(
        np.mean(
            np.abs(
                (
                    y_true[mask]
                    - y_pred[mask]
                )
                / y_true[mask]
            )
        )
        * 100
    )


def calculate_smape(
    y_true,
    y_pred
):

    y_true = np.asarray(
        y_true,
        dtype=float
    )

    y_pred = np.asarray(
        y_pred,
        dtype=float
    )

    denominator = (
        np.abs(y_true)
        + np.abs(y_pred)
    )

    mask = (
        denominator
        > 1e-8
    )

    if mask.sum() == 0:

        return np.nan

    return float(
        np.mean(
            2
            * np.abs(
                y_pred[mask]
                - y_true[mask]
            )
            / denominator[mask]
        )
        * 100
    )


def evaluate_predictions(
    y_true,
    y_pred
):

    return {

        "MAE":
            mean_absolute_error(
                y_true,
                y_pred
            ),

        "RMSE":
            calculate_rmse(
                y_true,
                y_pred
            ),

        "R2":
            r2_score(
                y_true,
                y_pred
            ),

        "MAPE_percent":
            calculate_mape(
                y_true,
                y_pred
            ),

        "sMAPE_percent":
            calculate_smape(
                y_true,
                y_pred
            ),

        "Mean_Bias":
            float(
                np.mean(
                    y_pred
                    - y_true
                )
            ),

        "Median_Bias":
            float(
                np.median(
                    y_pred
                    - y_true
                )
            ),
    }


# ============================================================
# 24. PREPARE EXPERIMENT DATA
# ============================================================

def prepare_experiment_data(
    feature_list
):

    feature_list = [
        feature
        for feature in feature_list
        if feature in df.columns
    ]

    work = df[
        [
            TIME_COL,
            TARGET_COL,
            "_split",
        ]
        + feature_list
    ].copy()

    work = work.replace(
        [np.inf, -np.inf],
        np.nan
    )

    train = work[
        work["_split"] == "train"
    ].copy()

    validation = work[
        work["_split"] == "validation"
    ].copy()

    test = work[
        work["_split"] == "test"
    ].copy()


    # --------------------------------------------------------
    # Train-only median imputation
    # --------------------------------------------------------

    train_medians = (
        train[
            feature_list
        ].median()
    )

    X_train = (
        train[
            feature_list
        ]
        .fillna(
            train_medians
        )
    )

    X_validation = (
        validation[
            feature_list
        ]
        .fillna(
            train_medians
        )
    )

    X_test = (
        test[
            feature_list
        ]
        .fillna(
            train_medians
        )
    )


    # --------------------------------------------------------
    # Target
    # --------------------------------------------------------

    y_train = (
        train[TARGET_COL]
        .values
    )

    y_validation = (
        validation[TARGET_COL]
        .values
    )

    y_test = (
        test[TARGET_COL]
        .values
    )

    return (
        train,
        validation,
        test,
        X_train,
        X_validation,
        X_test,
        y_train,
        y_validation,
        y_test,
    )


# ============================================================
# 25. FEATURE DIAGNOSTICS
# ============================================================

print_header(
    "FEATURE DIAGNOSTICS V3"
)

feature_diagnostics = []


for experiment_name, config in EXPERIMENTS.items():

    features = [
        c
        for c in config["features"]
        if c in df.columns
    ]

    missing_cells = int(
        df[
            features
        ]
        .isna()
        .sum()
        .sum()
    )

    constant_features = []

    variable_features = []

    for feature in features:

        unique_count = (
            df[feature]
            .nunique(
                dropna=True
            )
        )

        if unique_count <= 1:

            constant_features.append(
                feature
            )

        else:

            variable_features.append(
                feature
            )


    feature_diagnostics.append(
        {
            "Experiment":
                experiment_name,

            "Feature_Count":
                len(features),

            "Variable_Feature_Count":
                len(variable_features),

            "Constant_Feature_Count":
                len(constant_features),

            "Constant_Features":
                ";".join(
                    constant_features
                ),

            "Missing_Cells":
                missing_cells,

            "Train_Rows":
                len(train_raw),

            "Validation_Rows":
                len(validation_raw),

            "Test_Rows":
                len(test_raw),
        }
    )


    print(
        f"{experiment_name:25s}"
        f" total={len(features):2d}"
        f" variable={len(variable_features):2d}"
        f" constant={len(constant_features):2d}"
        f" missing={missing_cells:4d}"
    )


feature_diagnostics_df = pd.DataFrame(
    feature_diagnostics
)


# ============================================================
# 26. RUN ABLATION EXPERIMENTS
# ============================================================

print_header(
    "RUNNING ABLATION EXPERIMENTS V3"
)

all_results = []

all_predictions = []

feature_summary = []


for experiment_name, config in EXPERIMENTS.items():

    print_section(
        f"EXPERIMENT: {experiment_name}"
    )

    features = [
        c
        for c in config["features"]
        if c in df.columns
    ]

    print(
        "Description:",
        config["description"]
    )

    print(
        "Feature count:",
        len(features)
    )

    if not features:

        print(
            "SKIPPED: no features available."
        )

        continue


    # --------------------------------------------------------
    # Prepare data
    # --------------------------------------------------------

    (
        train,
        validation,
        test,
        X_train,
        X_validation,
        X_test,
        y_train,
        y_validation,
        y_test,
    ) = prepare_experiment_data(
        features
    )


    # --------------------------------------------------------
    # Build model
    # --------------------------------------------------------

    model = build_model()

    start_time = time.perf_counter()

    model.fit(
        X_train,
        y_train
    )

    training_time = (
        time.perf_counter()
        - start_time
    )


    # --------------------------------------------------------
    # Predictions
    # --------------------------------------------------------

    validation_prediction = (
        model.predict(
            X_validation
        )
    )

    test_prediction = (
        model.predict(
            X_test
        )
    )


    # --------------------------------------------------------
    # Metrics
    # --------------------------------------------------------

    validation_metrics = (
        evaluate_predictions(
            y_validation,
            validation_prediction
        )
    )

    test_metrics = (
        evaluate_predictions(
            y_test,
            test_prediction
        )
    )


    # --------------------------------------------------------
    # Store result
    # --------------------------------------------------------

    result = {

        "Experiment":
            experiment_name,

        "Description":
            config["description"],

        "Feature_Count":
            len(features),

        "Train_Rows":
            len(X_train),

        "Validation_Rows":
            len(X_validation),

        "Test_Rows":
            len(X_test),

        "Validation_MAE":
            validation_metrics["MAE"],

        "Validation_RMSE":
            validation_metrics["RMSE"],

        "Validation_R2":
            validation_metrics["R2"],

        "Validation_MAPE_percent":
            validation_metrics[
                "MAPE_percent"
            ],

        "Validation_sMAPE_percent":
            validation_metrics[
                "sMAPE_percent"
            ],

        "Validation_Mean_Bias":
            validation_metrics[
                "Mean_Bias"
            ],

        "Validation_Median_Bias":
            validation_metrics[
                "Median_Bias"
            ],

        "Test_MAE":
            test_metrics["MAE"],

        "Test_RMSE":
            test_metrics["RMSE"],

        "Test_R2":
            test_metrics["R2"],

        "Test_MAPE_percent":
            test_metrics[
                "MAPE_percent"
            ],

        "Test_sMAPE_percent":
            test_metrics[
                "sMAPE_percent"
            ],

        "Test_Mean_Bias":
            test_metrics[
                "Mean_Bias"
            ],

        "Test_Median_Bias":
            test_metrics[
                "Median_Bias"
            ],

        "Training_Time_sec":
            training_time,
    }

    all_results.append(
        result
    )


    # --------------------------------------------------------
    # Feature summary
    # --------------------------------------------------------

    feature_summary.append(
        {
            "Experiment":
                experiment_name,

            "Feature_Count":
                len(features),

            "Features":
                ";".join(
                    features
                ),
        }
    )


    # --------------------------------------------------------
    # Predictions
    # --------------------------------------------------------

    prediction_frame = pd.DataFrame(
        {
            "Experiment":
                experiment_name,

            "Timestamp":
                test[TIME_COL].values,

            "Actual":
                y_test,

            "Predicted":
                test_prediction,

            "Residual":
                (
                    test_prediction
                    - y_test
                ),
        }
    )

    all_predictions.append(
        prediction_frame
    )


    # --------------------------------------------------------
    # Console
    # --------------------------------------------------------

    print(
        "\nValidation:"
    )

    print(
        f"  MAE  = "
        f"{validation_metrics['MAE']:.4f}"
    )

    print(
        f"  RMSE = "
        f"{validation_metrics['RMSE']:.4f}"
    )

    print(
        f"  R2   = "
        f"{validation_metrics['R2']:.4f}"
    )

    print(
        "\nTest:"
    )

    print(
        f"  MAE  = "
        f"{test_metrics['MAE']:.4f}"
    )

    print(
        f"  RMSE = "
        f"{test_metrics['RMSE']:.4f}"
    )

    print(
        f"  R2   = "
        f"{test_metrics['R2']:.4f}"
    )

    print(
        f"  MAPE = "
        f"{test_metrics['MAPE_percent']:.4f}%"
    )

    print(
        f"  sMAPE = "
        f"{test_metrics['sMAPE_percent']:.4f}%"
    )

    print(
        f"Training time = "
        f"{training_time:.3f} sec"
    )


# ============================================================
# 27. BUILD RESULTS
# ============================================================

print_header(
    "BUILDING FINAL ABLATION TABLE"
)

results_df = pd.DataFrame(
    all_results
)

predictions_df = pd.concat(
    all_predictions,
    ignore_index=True
)

feature_summary_df = pd.DataFrame(
    feature_summary
)


# ============================================================
# 28. COMPONENT CONTRIBUTIONS
# ============================================================

print_section(
    "CALCULATING COMPONENT CONTRIBUTIONS"
)

if not results_df.empty:

    full_rows = results_df[
        results_df["Experiment"]
        == "A0_Full"
    ]

    if len(full_rows) == 1:

        full_rmse = float(
            full_rows[
                "Test_RMSE"
            ].iloc[0]
        )

        full_mae = float(
            full_rows[
                "Test_MAE"
            ].iloc[0]
        )

        full_r2 = float(
            full_rows[
                "Test_R2"
            ].iloc[0]
        )

        full_mape = float(
            full_rows[
                "Test_MAPE_percent"
            ].iloc[0]
        )

        results_df[
            "Delta_RMSE_vs_Full"
        ] = (
            results_df[
                "Test_RMSE"
            ]
            - full_rmse
        )

        results_df[
            "Delta_MAE_vs_Full"
        ] = (
            results_df[
                "Test_MAE"
            ]
            - full_mae
        )

        results_df[
            "Delta_R2_vs_Full"
        ] = (
            results_df[
                "Test_R2"
            ]
            - full_r2
        )

        results_df[
            "Delta_MAPE_vs_Full"
        ] = (
            results_df[
                "Test_MAPE_percent"
            ]
            - full_mape
        )

        results_df[
            "RMSE_Change_percent_vs_Full"
        ] = (
            (
                results_df[
                    "Test_RMSE"
                ]
                - full_rmse
            )
            / full_rmse
            * 100
        )


# ============================================================
# 29. IDENTICAL PREDICTION DIAGNOSTICS
# ============================================================

print_section(
    "IDENTICAL-PREDICTION DIAGNOSTICS"
)

prediction_diagnostics = []

experiment_names = (
    predictions_df[
        "Experiment"
    ]
    .unique()
    .tolist()
)


for i in range(
    len(experiment_names)
):

    for j in range(
        i + 1,
        len(experiment_names)
    ):

        exp_a = (
            experiment_names[i]
        )

        exp_b = (
            experiment_names[j]
        )

        pred_a = (
            predictions_df[
                predictions_df[
                    "Experiment"
                ] == exp_a
            ]
            .sort_values(
                "Timestamp"
            )[
                "Predicted"
            ]
            .values
        )

        pred_b = (
            predictions_df[
                predictions_df[
                    "Experiment"
                ] == exp_b
            ]
            .sort_values(
                "Timestamp"
            )[
                "Predicted"
            ]
            .values
        )

        if len(pred_a) != len(pred_b):

            continue

        max_difference = float(
            np.max(
                np.abs(
                    pred_a
                    - pred_b
                )
            )
        )

        identical = bool(
            np.allclose(
                pred_a,
                pred_b,
                rtol=1e-10,
                atol=1e-10
            )
        )

        prediction_diagnostics.append(
            {
                "Experiment_A":
                    exp_a,

                "Experiment_B":
                    exp_b,

                "Identical_Predictions":
                    identical,

                "Max_Absolute_Difference":
                    max_difference,
            }
        )

        if identical:

            print(
                f"WARNING: "
                f"{exp_a} and {exp_b} "
                f"have identical predictions."
            )

        else:

            print(
                f"OK: "
                f"{exp_a} vs {exp_b} "
                f"max difference = "
                f"{max_difference:.6f}"
            )


prediction_diagnostics_df = pd.DataFrame(
    prediction_diagnostics
)


# ============================================================
# 30. SORT RESULTS
# ============================================================

if not results_df.empty:

    results_df = (
        results_df
        .sort_values(
            "Test_RMSE",
            ascending=True
        )
        .reset_index(
            drop=True
        )
    )


# ============================================================
# 31. SAVE OUTPUTS
# ============================================================

print_header(
    "SAVING V3 RESULTS"
)

results_file = (
    OUTPUT_DIR
    / "ablation_results_v3.csv"
)

predictions_file = (
    OUTPUT_DIR
    / "ablation_predictions_v3.csv"
)

features_file = (
    OUTPUT_DIR
    / "feature_summary_v3.csv"
)

diagnostics_file = (
    OUTPUT_DIR
    / "feature_diagnostics_v3.csv"
)

prediction_diagnostics_file = (
    OUTPUT_DIR
    / "prediction_diagnostics_v3.csv"
)


results_df.to_csv(
    results_file,
    index=False
)

predictions_df.to_csv(
    predictions_file,
    index=False
)

feature_summary_df.to_csv(
    features_file,
    index=False
)

feature_diagnostics_df.to_csv(
    diagnostics_file,
    index=False
)

prediction_diagnostics_df.to_csv(
    prediction_diagnostics_file,
    index=False
)

calendar_diagnostics_df.to_csv(
    OUTPUT_DIR
    / "calendar_feature_diagnostics_v3.csv",
    index=False
)


# ============================================================
# 32. FINAL SUMMARY
# ============================================================

print_header(
    "FINAL ABLATION SUMMARY V3"
)

if not results_df.empty:

    summary_columns = [

        "Experiment",

        "Feature_Count",

        "Validation_RMSE",

        "Validation_R2",

        "Test_MAE",

        "Test_RMSE",

        "Test_R2",

        "Test_MAPE_percent",

        "Test_sMAPE_percent",

        "Delta_RMSE_vs_Full",

        "RMSE_Change_percent_vs_Full",
    ]

    available_columns = [
        c
        for c in summary_columns
        if c in results_df.columns
    ]

    print(
        results_df[
            available_columns
        ].to_string(
            index=False,
            float_format=lambda x:
                f"{x:.4f}"
        )
    )


# ============================================================
# 33. COMPONENT ANALYSIS
# ============================================================

print_section(
    "COMPONENT-LEVEL ANALYSIS"
)

if not results_df.empty:

    for _, row in results_df.iterrows():

        experiment = (
            row["Experiment"]
        )

        if experiment == "A0_Full":

            continue

        delta_rmse = row.get(
            "Delta_RMSE_vs_Full",
            np.nan
        )

        percentage_change = row.get(
            "RMSE_Change_percent_vs_Full",
            np.nan
        )

        print(
            f"{experiment:25s}"
            f" ΔRMSE = "
            f"{delta_rmse:+.4f}"
            f" | Change = "
            f"{percentage_change:+.2f}%"
        )


# ============================================================
# 34. DATE SANITY CHECK
# ============================================================

print_section(
    "FINAL DATE SANITY CHECK"
)

print(
    "Minimum date:",
    df[TIME_COL].min()
)

print(
    "Maximum date:",
    df[TIME_COL].max()
)

print(
    "Date dtype:",
    df[TIME_COL].dtype
)

print(
    "Calendar variable count:",
    len(CALENDAR_FEATURES)
)

print(
    "Calendar variable list:"
)

for feature in CALENDAR_FEATURES:

    print(
        "  -",
        feature
    )


# ============================================================
# 35. OUTPUT FILES
# ============================================================

print_header(
    "OUTPUT FILES"
)

print(
    "1.",
    results_file
)

print(
    "2.",
    predictions_file
)

print(
    "3.",
    features_file
)

print(
    "4.",
    diagnostics_file
)

print(
    "5.",
    prediction_diagnostics_file
)

print(
    "6.",
    OUTPUT_DIR
    / "calendar_feature_diagnostics_v3.csv"
)

print(
    "7.",
    OUTPUT_DIR
    / "split_summary_v3.csv"
)

print(
    "8.",
    OUTPUT_DIR
    / "date_validation_v3.csv"
)


# ============================================================
# 36. COMPLETION
# ============================================================

print_header(
    "ABLATION STUDY V3 COMPLETED"
)

print(
    "Experiment completed successfully."
)

print(
    "IMPORTANT:"
)

print(
    "Verify the displayed date range before using "
    "the results in the manuscript."
)

print(
    "Expected dates should look like:"
)

print(
    "2025-01-01 -> 2026-09-19"
)

print(
    "=" * 100
)