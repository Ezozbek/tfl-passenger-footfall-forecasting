from pathlib import Path
import zipfile
import hashlib
import csv
import sys
from datetime import datetime


# ============================================================
# STAGE 40
# FINAL MANUSCRIPT SUBMISSION PACKAGE REVIEW
# DOCX-ONLY / NO PDF
# ============================================================

PROJECT_ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

PACKAGE_DIR = PROJECT_ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

SOURCE_ZIP = PROJECT_ROOT / "FINAL_Q1_SUBMISSION_PACKAGE_STAGE38B_DOCX_ONLY.zip"

CLEAN_ZIP = PROJECT_ROOT / "FINAL_Q1_JOURNAL_SUBMISSION_PACKAGE_STAGE40.zip"

REPORT_FILE = PACKAGE_DIR / "STAGE40_FINAL_MANUSCRIPT_SUBMISSION_PACKAGE_REVIEW.txt"

MANIFEST_FILE = PACKAGE_DIR / "STAGE40_CLEAN_SUBMISSION_MANIFEST.csv"


# ============================================================
# EXPECTED SCIENTIFIC SUBMISSION CONTENT
# ============================================================

REQUIRED_FILES = [
    "01_Final_Manuscript.docx",

    "03_High_Resolution_Figures/Figure_1_Feature_Importance.png",
    "03_High_Resolution_Figures/Figure_2_Actual_vs_Predicted.png",
    "03_High_Resolution_Figures/Figure_3_Residual_Diagnostics.png",
    "03_High_Resolution_Figures/Figure_4_Model_Comparison.png",

    "05_Supplementary_Material/Figure_2_3_Paired_Test_Predictions.csv",
]


# ============================================================
# INTERNAL FILES — MUST NOT ENTER CLEAN SUBMISSION ZIP
# ============================================================

INTERNAL_PREFIXES = [
    "_Stage38_Backup/",
]

INTERNAL_EXACT = {
    "stage38b_docx_only_final_audit.py",
    "STAGE38B_DOCX_ONLY_PACKAGE_MANIFEST.csv",
    "STAGE38B_DOCX_ONLY_FINAL_AUDIT.txt",
    "STAGE39_FINAL_ZIP_CONTENT_MANIFEST.csv",
    "STAGE39_FINAL_ZIP_CONTENT_INSPECTION.txt",
}


# ============================================================
# UTILITIES
# ============================================================

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)

            if not chunk:
                break

            h.update(chunk)

    return h.hexdigest()


def human_size(size: int) -> str:
    if size < 1024:
        return f"{size} B"

    if size < 1024 ** 2:
        return f"{size / 1024:.2f} KB"

    if size < 1024 ** 3:
        return f"{size / (1024 ** 2):.2f} MB"

    return f"{size / (1024 ** 3):.2f} GB"


def print_line(text=""):
    print(text)


# ============================================================
# START
# ============================================================

print("=" * 100)
print("STAGE 40 — FINAL MANUSCRIPT SUBMISSION PACKAGE REVIEW")
print("GENERAL JOURNAL SUBMISSION READINESS / DOCX-ONLY")
print("=" * 100)

start_time = datetime.now()

passed = []
failed = []
notes = []


# ============================================================
# 1. SOURCE ZIP
# ============================================================

print("\n[1] SOURCE PACKAGE")

if not SOURCE_ZIP.exists():
    print("FAIL | Source ZIP not found")
    print(SOURCE_ZIP)

    sys.exit(1)

source_hash = sha256_file(SOURCE_ZIP)

print("PASS | Source ZIP exists")
print(f"      {SOURCE_ZIP}")

print(f"      Size   : {human_size(SOURCE_ZIP.stat().st_size)}")
print(f"      SHA256 : {source_hash}")

passed.append("Source ZIP exists")


# ============================================================
# 2. OPEN ZIP + INTEGRITY
# ============================================================

print("\n[2] ZIP INTEGRITY")

try:
    with zipfile.ZipFile(SOURCE_ZIP, "r") as z:
        bad_member = z.testzip()

        if bad_member is None:
            print("PASS | ZIP integrity")
            passed.append("ZIP integrity")

        else:
            print("FAIL | Corrupted ZIP member")
            print(f"      {bad_member}")

            failed.append("ZIP integrity")

except Exception as e:
    print("FAIL | ZIP cannot be opened")
    print(f"      {e}")

    failed.append("ZIP open")


# ============================================================
# 3. ZIP MEMBER INVENTORY
# ============================================================

with zipfile.ZipFile(SOURCE_ZIP, "r") as z:

    members = [
        name
        for name in z.namelist()
        if not name.endswith("/")
    ]

print("\n[3] ZIP CONTENT")

print(f"ZIP files : {len(members)}")

for member in members:
    print(f"      {member}")


# ============================================================
# 4. PDF EXCLUSION
# ============================================================

print("\n[4] PDF EXCLUSION")

pdf_members = [
    m for m in members
    if m.lower().endswith(".pdf")
]

if not pdf_members:
    print("PASS | No PDF files present")
    passed.append("PDF exclusion")

else:
    print("FAIL | PDF files detected")

    for m in pdf_members:
        print(f"      {m}")

    failed.append("PDF exclusion")


# ============================================================
# 5. REQUIRED SUBMISSION FILES
# ============================================================

print("\n[5] REQUIRED SUBMISSION FILES")

missing = []

for required in REQUIRED_FILES:

    if required in members:
        print(f"PASS | {required}")

        passed.append(f"Required file: {required}")

    else:
        print(f"FAIL | MISSING: {required}")

        missing.append(required)
        failed.append(f"Missing: {required}")


if not missing:
    print("\nPASS | All core submission files are present")


# ============================================================
# 6. INTERNAL FILE DETECTION
# ============================================================

print("\n[6] INTERNAL / AUDIT FILE DETECTION")

internal_members = []

for member in members:

    basename = Path(member).name

    if (
        basename in INTERNAL_EXACT
        or any(member.startswith(prefix) for prefix in INTERNAL_PREFIXES)
    ):
        internal_members.append(member)

if internal_members:

    print("NOTE | Internal files detected in source ZIP:")

    for member in internal_members:
        print(f"      {member}")

    notes.append(
        "Internal audit/backup files detected in source package "
        "and excluded from clean submission ZIP."
    )

else:

    print("PASS | No internal files detected")

    passed.append("No internal files")


# ============================================================
# 7. CLEAN SUBMISSION MEMBER LIST
# ============================================================

print("\n[7] CLEAN SUBMISSION CONTENT")

clean_members = [
    member
    for member in members
    if member in REQUIRED_FILES
]

print(f"Clean submission files : {len(clean_members)}")

for member in clean_members:
    print(f"      {member}")


if set(clean_members) == set(REQUIRED_FILES):

    print("PASS | Clean submission content is complete")
    passed.append("Clean submission content complete")

else:

    print("FAIL | Clean submission content incomplete")
    failed.append("Clean submission content incomplete")


# ============================================================
# 8. VALIDATE DOCX ZIP STRUCTURE
# ============================================================

print("\n[8] DOCX VALIDATION")

docx_ok = False

with zipfile.ZipFile(SOURCE_ZIP, "r") as z:

    if "01_Final_Manuscript.docx" in members:

        try:

            docx_bytes = z.read("01_Final_Manuscript.docx")

            with zipfile.ZipFile(
                __import__("io").BytesIO(docx_bytes),
                "r"
            ) as docx_zip:

                docx_required = [
                    "[Content_Types].xml",
                    "word/document.xml",
                    "word/_rels/document.xml.rels",
                ]

                missing_docx_parts = [
                    x for x in docx_required
                    if x not in docx_zip.namelist()
                ]

                if not missing_docx_parts:

                    print("PASS | DOCX internal structure valid")
                    docx_ok = True
                    passed.append("DOCX internal structure")

                else:

                    print("FAIL | DOCX internal structure incomplete")

                    for item in missing_docx_parts:
                        print(f"      Missing: {item}")

                    failed.append("DOCX internal structure")

        except Exception as e:

            print("FAIL | DOCX cannot be opened as ZIP")
            print(f"      {e}")

            failed.append("DOCX validation")

    else:

        print("FAIL | DOCX missing")
        failed.append("DOCX validation")


# ============================================================
# 9. FIGURE VALIDATION
# ============================================================

print("\n[9] FIGURE VALIDATION")

figure_files = [
    x for x in REQUIRED_FILES
    if x.lower().endswith(".png")
]

with zipfile.ZipFile(SOURCE_ZIP, "r") as z:

    for figure in figure_files:

        if figure not in members:
            continue

        try:

            data = z.read(figure)

            if len(data) == 0:

                print(f"FAIL | Empty figure: {figure}")
                failed.append(f"Empty figure: {figure}")
                continue

            # PNG signature
            png_signature = b"\x89PNG\r\n\x1a\n"

            if not data.startswith(png_signature):

                print(f"FAIL | Invalid PNG signature: {figure}")
                failed.append(f"Invalid PNG: {figure}")

            else:

                digest = sha256_bytes(data)

                print(f"PASS | {figure}")
                print(f"      Size   : {human_size(len(data))}")
                print(f"      SHA256 : {digest}")

                passed.append(f"Figure valid: {figure}")

        except Exception as e:

            print(f"FAIL | Figure read error: {figure}")
            print(f"      {e}")

            failed.append(f"Figure read: {figure}")


# ============================================================
# 10. SUPPLEMENTARY CSV VALIDATION
# ============================================================

print("\n[10] SUPPLEMENTARY MATERIAL")

supplementary = (
    "05_Supplementary_Material/"
    "Figure_2_3_Paired_Test_Predictions.csv"
)

with zipfile.ZipFile(SOURCE_ZIP, "r") as z:

    if supplementary in members:

        try:

            data = z.read(supplementary)

            decoded = data.decode("utf-8-sig")

            lines = decoded.splitlines()

            print("PASS | Supplementary CSV readable")
            print(f"      Size  : {human_size(len(data))}")
            print(f"      Lines : {len(lines)}")

            if len(lines) > 1:

                print("PASS | Supplementary CSV contains data")

                passed.append("Supplementary CSV")

            else:

                print("FAIL | Supplementary CSV appears empty")

                failed.append("Supplementary CSV empty")

        except Exception as e:

            print("FAIL | Supplementary CSV cannot be read")
            print(f"      {e}")

            failed.append("Supplementary CSV")

    else:

        print("FAIL | Supplementary CSV missing")
        failed.append("Supplementary CSV")


# ============================================================
# 11. CREATE CLEAN SUBMISSION ZIP
# ============================================================

print("\n[11] CREATE CLEAN SUBMISSION ZIP")

if failed:
    print("WARNING | Validation failures detected.")
    print("         Clean ZIP will NOT be created.")
else:

    if CLEAN_ZIP.exists():
        CLEAN_ZIP.unlink()

    with zipfile.ZipFile(
        SOURCE_ZIP,
        "r",
        compression=zipfile.ZIP_DEFLATED
    ) as source:

        with zipfile.ZipFile(
            CLEAN_ZIP,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6
        ) as clean:

            for member in REQUIRED_FILES:

                data = source.read(member)

                clean.writestr(
                    member,
                    data
                )

                print(f"ADDED | {member}")

    print("\nPASS | Clean submission ZIP created")
    print(f"      {CLEAN_ZIP}")

    passed.append("Clean submission ZIP created")


# ============================================================
# 12. CLEAN ZIP VALIDATION
# ============================================================

print("\n[12] CLEAN ZIP VALIDATION")

clean_hash = None

if CLEAN_ZIP.exists():

    try:

        with zipfile.ZipFile(CLEAN_ZIP, "r") as z:

            clean_test = z.testzip()

            if clean_test is None:

                print("PASS | Clean ZIP integrity")

                passed.append("Clean ZIP integrity")

            else:

                print("FAIL | Clean ZIP corrupted")
                print(f"      {clean_test}")

                failed.append("Clean ZIP integrity")

            clean_members_actual = [
                x for x in z.namelist()
                if not x.endswith("/")
            ]

            print(
                f"      Clean ZIP members : "
                f"{len(clean_members_actual)}"
            )

            unexpected = [
                x for x in clean_members_actual
                if x not in REQUIRED_FILES
            ]

            missing_clean = [
                x for x in REQUIRED_FILES
                if x not in clean_members_actual
            ]

            if not unexpected and not missing_clean:

                print(
                    "PASS | Clean ZIP contains ONLY required "
                    "submission files"
                )

                passed.append(
                    "Clean ZIP exact content"
                )

            else:

                print("FAIL | Clean ZIP content mismatch")

                for x in unexpected:
                    print(f"      Unexpected: {x}")

                for x in missing_clean:
                    print(f"      Missing: {x}")

                failed.append("Clean ZIP exact content")

        clean_hash = sha256_file(CLEAN_ZIP)

        print(f"      Size   : {human_size(CLEAN_ZIP.stat().st_size)}")
        print(f"      SHA256 : {clean_hash}")

    except Exception as e:

        print("FAIL | Clean ZIP validation error")
        print(f"      {e}")

        failed.append("Clean ZIP validation")

else:

    print("SKIP | Clean ZIP was not created")


# ============================================================
# 13. MANIFEST
# ============================================================

print("\n[13] CLEAN SUBMISSION MANIFEST")

manifest_rows = []

if CLEAN_ZIP.exists():

    with zipfile.ZipFile(CLEAN_ZIP, "r") as z:

        for member in REQUIRED_FILES:

            data = z.read(member)

            manifest_rows.append(
                {
                    "file": member,
                    "size_bytes": len(data),
                    "size_human": human_size(len(data)),
                    "sha256": sha256_bytes(data),
                }
            )

    with MANIFEST_FILE.open(
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=[
                "file",
                "size_bytes",
                "size_human",
                "sha256",
            ]
        )

        writer.writeheader()
        writer.writerows(manifest_rows)

    print("PASS | Manifest created")
    print(f"      {MANIFEST_FILE}")

    passed.append("Clean submission manifest")

else:

    print("SKIP | Manifest not created")


# ============================================================
# 14. FINAL STATUS
# ============================================================

end_time = datetime.now()

duration = end_time - start_time

status = "PASS" if not failed else "FAIL"


print("\n" + "=" * 100)
print("STAGE 40 FINAL RESULT")
print("=" * 100)

print(f"STATUS          : {status}")
print(f"Passed checks   : {len(passed)}")
print(f"Failed checks   : {len(failed)}")
print(f"Notes           : {len(notes)}")
print(f"Duration        : {duration}")

print("\nSOURCE PACKAGE")
print(f"  {SOURCE_ZIP}")

if CLEAN_ZIP.exists():

    print("\nCLEAN JOURNAL SUBMISSION PACKAGE")
    print(f"  {CLEAN_ZIP}")

    print("\nCLEAN PACKAGE CONTENT")

    for member in REQUIRED_FILES:
        print(f"  {member}")

print("\nREPORT")
print(f"  {REPORT_FILE}")

print("\nMANIFEST")
print(f"  {MANIFEST_FILE}")


# ============================================================
# FAILURE DETAILS
# ============================================================

if failed:

    print("\nFAILURE DETAILS")

    for item in failed:
        print(f"  - {item}")


# ============================================================
# NOTES
# ============================================================

if notes:

    print("\nNOTES")

    for item in notes:
        print(f"  - {item}")


# ============================================================
# WRITE REPORT
# ============================================================

report_lines = []

report_lines.append(
    "STAGE 40 — FINAL MANUSCRIPT SUBMISSION PACKAGE REVIEW"
)

report_lines.append("=" * 100)

report_lines.append(
    f"Date/time : {datetime.now().isoformat(timespec='seconds')}"
)

report_lines.append(f"STATUS    : {status}")

report_lines.append("")

report_lines.append("SOURCE ZIP:")
report_lines.append(str(SOURCE_ZIP))
report_lines.append(f"SHA256: {source_hash}")

report_lines.append("")

report_lines.append("CLEAN SUBMISSION ZIP:")

if CLEAN_ZIP.exists():
    report_lines.append(str(CLEAN_ZIP))
    report_lines.append(f"SHA256: {clean_hash}")
else:
    report_lines.append("NOT CREATED")

report_lines.append("")

report_lines.append("REQUIRED SUBMISSION FILES:")

for member in REQUIRED_FILES:

    state = "PRESENT" if member in members else "MISSING"

    report_lines.append(
        f"{state} | {member}"
    )

report_lines.append("")

report_lines.append("INTERNAL FILES EXCLUDED FROM CLEAN PACKAGE:")

for member in internal_members:

    report_lines.append(
        f"EXCLUDED | {member}"
    )

report_lines.append("")

report_lines.append("FAILED CHECKS:")

if failed:

    for item in failed:
        report_lines.append(f"FAIL | {item}")

else:

    report_lines.append("NONE")

report_lines.append("")

report_lines.append("FINAL STATUS:")
report_lines.append(status)

REPORT_FILE.write_text(
    "\n".join(report_lines),
    encoding="utf-8"
)


print("\n" + "=" * 100)

if status == "PASS":

    print("STAGE 40 STATUS: PASS")
    print("Clean DOCX-only journal submission package is ready.")
    print("PDF was intentionally excluded.")

else:

    print("STAGE 40 STATUS: FAIL")
    print("Review the failure details before submission.")

print("=" * 100)

sys.exit(0 if status == "PASS" else 1)