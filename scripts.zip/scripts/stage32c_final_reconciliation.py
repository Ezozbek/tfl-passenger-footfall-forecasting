# ============================================================
# STAGE 32C
# FINAL SCIENTIFIC RECONCILIATION + FIGURE CORRECTION
# ============================================================

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

BASELINE_DIR = PROJECT_ROOT / "tfl_baseline_results"
ADVANCED_DIR = PROJECT_ROOT / "tfl_advanced_results"
ABLATION_DIR = PROJECT_ROOT / "tfl_ablation_results_v3"

FIGURE_DIR = PROJECT_ROOT / "figures"

REPORT_DIR = (
    PROJECT_ROOT
    / "scientific_validation_results"
)

FIGURE_DIR.mkdir(
    parents=True,
    exist_ok=True
)

REPORT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# HELPER
# ============================================================

def save_figure(fig, filename):

    png_path = FIGURE_DIR / f"{filename}.png"
    pdf_path = FIGURE_DIR / f"{filename}.pdf"

    fig.savefig(
        png_path,
        dpi=300,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf_path,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(
        f"[SAVED] {png_path.name}"
    )

    print(
        f"[SAVED] {pdf_path.name}"
    )


# ============================================================
# HEADER
# ============================================================

print("=" * 100)
print("STAGE 32C — FINAL SCIENTIFIC RECONCILIATION")
print("=" * 100)

print(
    "Project root:",
    PROJECT_ROOT
)

print(
    "Figure dir:",
    FIGURE_DIR
)


# ============================================================
# LOAD BASELINE FEATURE IMPORTANCE
# ============================================================

print("\n" + "=" * 100)
print("1. LOAD VERIFIED FEATURE IMPORTANCE")
print("=" * 100)

feature_file = (
    BASELINE_DIR
    / "feature_importance.csv"
)

feature_df = pd.read_csv(
    feature_file
)

feature_df["Importance"] = pd.to_numeric(
    feature_df["Importance"],
    errors="coerce"
)

feature_df = feature_df.dropna(
    subset=["Importance"]
)

feature_df = feature_df.sort_values(
    "Importance",
    ascending=False
).reset_index(
    drop=True
)

total_importance = (
    feature_df["Importance"].sum()
)

feature_df["Percentage"] = (
    feature_df["Importance"]
    / total_importance
    * 100
)

top10 = feature_df.head(10).copy()

print(
    top10[
        [
            "Feature",
            "Importance",
            "Percentage"
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# CLEAN FEATURE LABELS
# ============================================================

def clean_feature_name(name):

    name = str(name)

    prefixes = [
        "numeric__",
        "categorical__"
    ]

    for prefix in prefixes:

        if name.startswith(prefix):

            name = name[
                len(prefix):
            ]

    return name


top10["DisplayFeature"] = (
    top10["Feature"]
    .apply(clean_feature_name)
)


# ============================================================
# FIGURE 1
# FINAL FEATURE IMPORTANCE
# ============================================================

print("\n" + "=" * 100)
print("2. FIGURE 1 — VERIFIED TOP-10 FEATURE IMPORTANCE")
print("=" * 100)

plot_df = top10.sort_values(
    "Percentage",
    ascending=True
)

fig, ax = plt.subplots(
    figsize=(9, 6)
)

ax.barh(
    plot_df["DisplayFeature"],
    plot_df["Percentage"]
)

ax.set_xlabel(
    "Feature Importance (%)"
)

ax.set_ylabel(
    "Feature"
)

ax.set_title(
    "Top-10 Feature Importances of the ExtraTrees Model"
)

ax.grid(
    axis="x",
    alpha=0.25
)

fig.tight_layout()

save_figure(
    fig,
    "Figure_1_Feature_Importance"
)


# ============================================================
# LOAD TEST PREDICTIONS
# ============================================================

print("\n" + "=" * 100)
print("3. LOAD VERIFIED EXTRA TREES TEST PREDICTIONS")
print("=" * 100)

prediction_file = (
    BASELINE_DIR
    / "final_test_predictions.csv"
)

prediction_df = pd.read_csv(
    prediction_file
)

actual = pd.to_numeric(
    prediction_df["TotalFootfall"],
    errors="coerce"
)

predicted = pd.to_numeric(
    prediction_df["Predicted_TotalFootfall"],
    errors="coerce"
)

mask = (
    actual.notna()
    &
    predicted.notna()
)

actual = actual[mask].to_numpy()
predicted = predicted[mask].to_numpy()

residual = (
    actual
    - predicted
)

mae = np.mean(
    np.abs(residual)
)

rmse = np.sqrt(
    np.mean(
        residual ** 2
    )
)

ss_res = np.sum(
    residual ** 2
)

ss_tot = np.sum(
    (
        actual
        - np.mean(actual)
    ) ** 2
)

r2 = (
    1
    - ss_res / ss_tot
)

pearson_r = np.corrcoef(
    actual,
    predicted
)[0, 1]

mean_bias = np.mean(
    residual
)

median_bias = np.median(
    residual
)

std_residual = np.std(
    residual
)

print(
    f"N             : {len(actual):,}"
)

print(
    f"MAE           : {mae:.6f}"
)

print(
    f"RMSE          : {rmse:.6f}"
)

print(
    f"R2            : {r2:.8f}"
)

print(
    f"Pearson r     : {pearson_r:.8f}"
)

print(
    f"Mean bias     : {mean_bias:.8f}"
)

print(
    f"Median bias   : {median_bias:.8f}"
)

print(
    f"Residual std  : {std_residual:.8f}"
)


# ============================================================
# FIGURE 2
# ACTUAL VS PREDICTED
# ============================================================

print("\n" + "=" * 100)
print("4. FIGURE 2 — ACTUAL VS PREDICTED")
print("=" * 100)

fig, ax = plt.subplots(
    figsize=(7, 7)
)

ax.scatter(
    actual,
    predicted,
    s=5,
    alpha=0.25
)

min_value = min(
    actual.min(),
    predicted.min()
)

max_value = max(
    actual.max(),
    predicted.max()
)

ax.plot(
    [min_value, max_value],
    [min_value, max_value],
    linestyle="--"
)

ax.set_xlabel(
    "Observed Total Footfall"
)

ax.set_ylabel(
    "Predicted Total Footfall"
)

ax.set_title(
    "Observed vs Predicted Passenger Footfall"
)

ax.text(
    0.05,
    0.95,
    f"R² = {r2:.5f}\nPearson r = {pearson_r:.5f}",
    transform=ax.transAxes,
    verticalalignment="top"
)

ax.grid(
    alpha=0.25
)

fig.tight_layout()

save_figure(
    fig,
    "Figure_2_Actual_vs_Predicted"
)


# ============================================================
# FIGURE 3
# RESIDUAL DIAGNOSTICS
# ============================================================

print("\n" + "=" * 100)
print("5. FIGURE 3 — VERIFIED RESIDUAL DIAGNOSTICS")
print("=" * 100)

fig, ax = plt.subplots(
    figsize=(9, 6)
)

ax.hist(
    residual,
    bins=100
)

ax.axvline(
    0,
    linestyle="--"
)

ax.set_xlabel(
    "Residual (Observed − Predicted)"
)

ax.set_ylabel(
    "Frequency"
)

ax.set_title(
    "Residual Distribution of ExtraTrees Test Predictions"
)

ax.text(
    0.97,
    0.95,
    (
        f"Mean = {mean_bias:.2f}\n"
        f"Median = {median_bias:.2f}\n"
        f"SD = {std_residual:.2f}"
    ),
    transform=ax.transAxes,
    horizontalalignment="right",
    verticalalignment="top"
)

ax.grid(
    axis="y",
    alpha=0.25
)

fig.tight_layout()

save_figure(
    fig,
    "Figure_3_Residual_Diagnostics"
)


# ============================================================
# LOAD ADVANCED XGBOOST RESULTS
# ============================================================

print("\n" + "=" * 100)
print("6. LOAD VERIFIED REGULARIZED XGBOOST RESULTS")
print("=" * 100)

advanced_file = (
    ADVANCED_DIR
    / "advanced_test_results.csv"
)

advanced_df = pd.read_csv(
    advanced_file
)

print(
    advanced_df.to_string(
        index=False
    )
)

xgb_row = advanced_df[
    advanced_df["Model"]
    .astype(str)
    .eq(
        "XGBoost_Regularized"
    )
]

if len(xgb_row) != 1:

    raise ValueError(
        "Exactly one XGBoost_Regularized row expected."
    )

xgb = xgb_row.iloc[0]

xgb_mae = float(
    xgb["MAE"]
)

xgb_rmse = float(
    xgb["RMSE"]
)

xgb_r2 = float(
    xgb["R2"]
)

xgb_pearson = float(
    xgb["Pearson_r"]
)

print(
    "\nVerified XGBoost Regularized:"
)

print(
    f"MAE       = {xgb_mae:.6f}"
)

print(
    f"RMSE      = {xgb_rmse:.6f}"
)

print(
    f"R2        = {xgb_r2:.8f}"
)

print(
    f"Pearson r = {xgb_pearson:.8f}"
)


# ============================================================
# FIGURE 4
# EXTRA TREES VS REGULARIZED XGBOOST
# ============================================================

print("\n" + "=" * 100)
print("7. FIGURE 4 — FINAL MODEL COMPARISON")
print("=" * 100)

comparison_df = pd.DataFrame(
    {
        "Model": [
            "ExtraTrees",
            "Regularized XGBoost"
        ],
        "MAE": [
            mae,
            xgb_mae
        ],
        "RMSE": [
            rmse,
            xgb_rmse
        ],
        "R2": [
            r2,
            xgb_r2
        ],
        "Pearson_r": [
            pearson_r,
            xgb_pearson
        ]
    }
)

print(
    comparison_df.to_string(
        index=False
    )
)


# ------------------------------------------------------------
# Figure 4A — MAE / RMSE
# ------------------------------------------------------------

models = comparison_df[
    "Model"
].tolist()

x = np.arange(
    len(models)
)

width = 0.35

fig, ax = plt.subplots(
    figsize=(8, 6)
)

ax.bar(
    x - width / 2,
    comparison_df["MAE"],
    width,
    label="MAE"
)

ax.bar(
    x + width / 2,
    comparison_df["RMSE"],
    width,
    label="RMSE"
)

ax.set_xticks(
    x
)

ax.set_xticklabels(
    models
)

ax.set_ylabel(
    "Prediction Error"
)

ax.set_title(
    "Test-Set Error Comparison"
)

ax.legend()

ax.grid(
    axis="y",
    alpha=0.25
)

fig.tight_layout()

save_figure(
    fig,
    "Figure_4_Model_Comparison"
)


# ============================================================
# SAVE FINAL RECONCILIATION TABLE
# ============================================================

print("\n" + "=" * 100)
print("8. SAVE FINAL RECONCILIATION TABLE")
print("=" * 100)

final_table = pd.DataFrame(
    {
        "Model": [
            "ExtraTrees",
            "Regularized XGBoost"
        ],

        "Test_MAE": [
            mae,
            xgb_mae
        ],

        "Test_RMSE": [
            rmse,
            xgb_rmse
        ],

        "Test_R2": [
            r2,
            xgb_r2
        ],

        "Test_Pearson_r": [
            pearson_r,
            xgb_pearson
        ],

        "Mean_Bias": [
            mean_bias,
            np.nan
        ]
    }
)

final_table_file = (
    REPORT_DIR
    / "FINAL_MANUSCRIPT_MODEL_RESULTS.csv"
)

final_table.to_csv(
    final_table_file,
    index=False
)

print(
    "[SAVED]",
    final_table_file
)


# ============================================================
# SAVE FEATURE TABLE
# ============================================================

feature_table_file = (
    REPORT_DIR
    / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"
)

top10[
    [
        "Feature",
        "Importance",
        "Percentage"
    ]
].to_csv(
    feature_table_file,
    index=False
)

print(
    "[SAVED]",
    feature_table_file
)


# ============================================================
# FINAL SCIENTIFIC RECONCILIATION
# ============================================================

print("\n" + "=" * 100)
print("9. FINAL SCIENTIFIC RECONCILIATION")
print("=" * 100)

print(
    "\n[VERIFIED]"
)

print(
    "ExtraTrees:"
)

print(
    f"  MAE       = {mae:.4f}"
)

print(
    f"  RMSE      = {rmse:.4f}"
)

print(
    f"  R²        = {r2:.6f}"
)

print(
    f"  Pearson r = {pearson_r:.6f}"
)

print(
    f"  Bias      = {mean_bias:.4f}"
)

print(
    "\nRegularized XGBoost:"
)

print(
    f"  MAE       = {xgb_mae:.4f}"
)

print(
    f"  RMSE      = {xgb_rmse:.4f}"
)

print(
    f"  R²        = {xgb_r2:.6f}"
)

print(
    f"  Pearson r = {xgb_pearson:.6f}"
)

print(
    "\nFeature importance:"
)

for _, row in top10.iterrows():

    print(
        f"  {row['DisplayFeature']:<25s}"
        f" {row['Percentage']:.4f}%"
    )


# ============================================================
# REJECTED OLD CLAIMS
# ============================================================

print(
    "\n" + "-" * 80
)

print(
    "REJECTED / REPLACED MANUSCRIPT VALUES:"
)

print(
    "  Lag_7 = 61.998%  -> REPLACED by 19.7594%"
)

print(
    "  Mean Bias = -5.48 -> REPLACED by +26.3903%"
    .replace(
        "+26.3903%",
        "+26.3903"
    )
)

print(
    "  Figure 4 six-model baseline -> REPLACED by"
)

print(
    "  ExtraTrees vs Regularized XGBoost"
)


# ============================================================
# FINAL
# ============================================================

print("\n" + "=" * 100)
print("STAGE 32C COMPLETED SUCCESSFULLY")
print("=" * 100)

print(
    "\nGenerated/updated:"
)

for filename in [
    "Figure_1_Feature_Importance.png",
    "Figure_1_Feature_Importance.pdf",
    "Figure_2_Actual_vs_Predicted.png",
    "Figure_2_Actual_vs_Predicted.pdf",
    "Figure_3_Residual_Diagnostics.png",
    "Figure_3_Residual_Diagnostics.pdf",
    "Figure_4_Model_Comparison.png",
    "Figure_4_Model_Comparison.pdf",
]:

    path = FIGURE_DIR / filename

    print(
        f"  [{'OK' if path.exists() else 'FAIL'}] {filename}"
    )

print(
    "\nFinal result tables:"
)

print(
    "  FINAL_MANUSCRIPT_MODEL_RESULTS.csv"
)

print(
    "  FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"
)

print(
    "\nNEXT STAGE:"
)

print(
    "STAGE 33 -> FINAL Q1 MANUSCRIPT REWRITE"
)

print("=" * 100)