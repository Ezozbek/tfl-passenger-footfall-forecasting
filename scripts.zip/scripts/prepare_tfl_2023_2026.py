from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# 1. PROJECT PATH
# ============================================================

BASE_DIR = Path(
    r"c:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

OUTPUT_DIR = BASE_DIR / "tfl_master_data"
OUTPUT_DIR.mkdir(exist_ok=True)

# ============================================================
# 2. INPUT FILES
# ============================================================

FILES = [
    BASE_DIR / "StationFootfall_2023.csv",
    BASE_DIR / "StationFootfall_2024.csv",
    BASE_DIR / "stationfootfall-2025-2026.csv",
]

# ============================================================
# 3. EXPECTED COLUMNS
# ============================================================

EXPECTED_COLUMNS = [
    "TravelDate",
    "DayOfWeek",
    "Station",
    "EntryTapCount",
    "ExitTapCount",
]

# ============================================================
# 4. LOAD FUNCTION
# ============================================================

def load_footfall_file(file_path):

    print("\n" + "=" * 90)
    print(f"LOADING: {file_path.name}")
    print("=" * 90)

    if not file_path.exists():
        raise FileNotFoundError(
            f"File not found:\n{file_path}"
        )

    df = pd.read_csv(
        file_path,
        low_memory=False
    )

    print(f"Rows loaded: {len(df):,}")
    print(f"Columns    : {len(df.columns)}")

    # --------------------------------------------------------
    # Check columns
    # --------------------------------------------------------

    missing_columns = [
        col for col in EXPECTED_COLUMNS
        if col not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing expected columns in {file_path.name}: "
            f"{missing_columns}"
        )

    # Keep only expected columns
    df = df[EXPECTED_COLUMNS].copy()

    # --------------------------------------------------------
    # Add source year/file
    # --------------------------------------------------------

    df["Source_File"] = file_path.name

    # --------------------------------------------------------
    # Convert TravelDate
    # --------------------------------------------------------

    df["TravelDate"] = pd.to_datetime(
        df["TravelDate"].astype(str),
        format="%Y%m%d",
        errors="coerce"
    )

    # --------------------------------------------------------
    # Convert numerical columns
    # --------------------------------------------------------

    df["EntryTapCount"] = pd.to_numeric(
        df["EntryTapCount"],
        errors="coerce"
    )

    df["ExitTapCount"] = pd.to_numeric(
        df["ExitTapCount"],
        errors="coerce"
    )

    # --------------------------------------------------------
    # Clean text columns
    # --------------------------------------------------------

    df["DayOfWeek"] = (
        df["DayOfWeek"]
        .astype("string")
        .str.strip()
    )

    df["Station"] = (
        df["Station"]
        .astype("string")
        .str.strip()
    )

    print(
        f"Date range: "
        f"{df['TravelDate'].min()} "
        f"→ "
        f"{df['TravelDate'].max()}"
    )

    return df


# ============================================================
# 5. LOAD ALL THREE DATASETS
# ============================================================

dataframes = []

for file_path in FILES:

    df_temp = load_footfall_file(file_path)

    dataframes.append(df_temp)


# ============================================================
# 6. COMBINE DATASETS
# ============================================================

print("\n" + "#" * 90)
print("COMBINING ALL TFL FOOTFALL DATASETS")
print("#" * 90)

df = pd.concat(
    dataframes,
    ignore_index=True
)

print(f"Combined rows: {len(df):,}")
print(f"Columns      : {len(df.columns)}")


# ============================================================
# 7. REMOVE EXACT DUPLICATES
# ============================================================

before_duplicates = len(df)

df = df.drop_duplicates()

after_duplicates = len(df)

removed_duplicates = (
    before_duplicates - after_duplicates
)

print("\nDuplicate check:")
print(f"Before: {before_duplicates:,}")
print(f"After : {after_duplicates:,}")
print(f"Removed: {removed_duplicates:,}")


# ============================================================
# 8. REMOVE INVALID RECORDS
# ============================================================

print("\nChecking invalid records...")

invalid_date = df["TravelDate"].isna()

invalid_station = (
    df["Station"].isna()
    | (df["Station"].str.len() == 0)
)

invalid_entry = (
    df["EntryTapCount"].isna()
    | (df["EntryTapCount"] < 0)
)

invalid_exit = (
    df["ExitTapCount"].isna()
    | (df["ExitTapCount"] < 0)
)

invalid_rows = (
    invalid_date
    | invalid_station
    | invalid_entry
    | invalid_exit
)

print(
    f"Invalid date rows   : {invalid_date.sum():,}"
)

print(
    f"Invalid station rows: {invalid_station.sum():,}"
)

print(
    f"Invalid entry rows  : {invalid_entry.sum():,}"
)

print(
    f"Invalid exit rows   : {invalid_exit.sum():,}"
)

print(
    f"Total invalid rows  : {invalid_rows.sum():,}"
)

# Remove invalid rows
df = df.loc[~invalid_rows].copy()


# ============================================================
# 9. SORT DATA
# ============================================================

df = df.sort_values(
    by=["TravelDate", "Station"]
).reset_index(drop=True)


# ============================================================
# 10. CREATE TIME FEATURES
# ============================================================

print("\nCreating temporal features...")

df["Year"] = df["TravelDate"].dt.year

df["Month"] = df["TravelDate"].dt.month

df["Day"] = df["TravelDate"].dt.day

df["DayOfYear"] = (
    df["TravelDate"].dt.dayofyear
)

df["WeekOfYear"] = (
    df["TravelDate"].dt.isocalendar().week.astype(int)
)

df["DayOfWeek_Num"] = (
    df["TravelDate"].dt.dayofweek
)

df["IsWeekend"] = (
    df["DayOfWeek_Num"] >= 5
).astype(int)


# ============================================================
# 11. CREATE DEMAND TARGET
# ============================================================

print("\nCreating demand variables...")

# Total station footfall
df["TotalFootfall"] = (
    df["EntryTapCount"]
    + df["ExitTapCount"]
)

# Average of entry and exit
df["AverageFootfall"] = (
    df["TotalFootfall"] / 2.0
)

# Entry/exit difference
df["EntryExitDifference"] = (
    df["EntryTapCount"]
    - df["ExitTapCount"]
)

# Absolute imbalance
df["EntryExitAbsDifference"] = (
    df["EntryExitDifference"].abs()
)


# ============================================================
# 12. LOG TRANSFORMATION
# ============================================================

df["LogTotalFootfall"] = np.log1p(
    df["TotalFootfall"]
)


# ============================================================
# 13. STATION-LEVEL FEATURES
# ============================================================

print("\nCreating station-level statistics...")

station_stats = (
    df.groupby("Station")["TotalFootfall"]
    .agg(
        Station_Mean_Footfall="mean",
        Station_Median_Footfall="median",
        Station_Std_Footfall="std",
        Station_Max_Footfall="max"
    )
    .reset_index()
)

df = df.merge(
    station_stats,
    on="Station",
    how="left"
)


# ============================================================
# 14. TEMPORAL LAG FEATURES
# ============================================================

print("\nCreating lag features...")

# IMPORTANT:
# Data is grouped by station to prevent mixing
# different stations.

df = df.sort_values(
    ["Station", "TravelDate"]
).reset_index(drop=True)

grouped = df.groupby("Station")["TotalFootfall"]

df["Lag_1"] = grouped.shift(1)

df["Lag_7"] = grouped.shift(7)

df["Lag_14"] = grouped.shift(14)

df["Lag_28"] = grouped.shift(28)


# ============================================================
# 15. ROLLING FEATURES
# ============================================================

print("\nCreating rolling features...")

# Shift first to avoid using the current target
# in its own predictors.

shifted_demand = (
    df.groupby("Station")["TotalFootfall"]
    .shift(1)
)

df["RollingMean_7"] = (
    shifted_demand
    .groupby(df["Station"])
    .transform(
        lambda x: x.rolling(
            window=7,
            min_periods=3
        ).mean()
    )
)

df["RollingStd_7"] = (
    shifted_demand
    .groupby(df["Station"])
    .transform(
        lambda x: x.rolling(
            window=7,
            min_periods=3
        ).std()
    )
)

df["RollingMean_14"] = (
    shifted_demand
    .groupby(df["Station"])
    .transform(
        lambda x: x.rolling(
            window=14,
            min_periods=5
        ).mean()
    )
)

df["RollingMean_28"] = (
    shifted_demand
    .groupby(df["Station"])
    .transform(
        lambda x: x.rolling(
            window=28,
            min_periods=7
        ).mean()
    )
)


# ============================================================
# 16. CHECK FOR DATA LEAKAGE
# ============================================================

print("\nChecking potential target leakage...")

# These columns contain current-day information.
# They should NOT be used as predictors when predicting
# future TotalFootfall.

LEAKAGE_COLUMNS = [
    "EntryTapCount",
    "ExitTapCount",
    "TotalFootfall",
    "AverageFootfall",
    "EntryExitDifference",
    "EntryExitAbsDifference",
    "LogTotalFootfall",
]

print("Current-target columns:")
for col in LEAKAGE_COLUMNS:
    print(f"  - {col}")


# ============================================================
# 17. FINAL COLUMN ORDER
# ============================================================

FINAL_COLUMNS = [
    # Identification
    "TravelDate",
    "Station",
    "DayOfWeek",
    "Source_File",

    # Calendar
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",

    # Original measurements
    "EntryTapCount",
    "ExitTapCount",

    # Target / derived demand
    "TotalFootfall",
    "AverageFootfall",
    "EntryExitDifference",
    "EntryExitAbsDifference",
    "LogTotalFootfall",

    # Station statistics
    "Station_Mean_Footfall",
    "Station_Median_Footfall",
    "Station_Std_Footfall",
    "Station_Max_Footfall",

    # Temporal features
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

df = df[FINAL_COLUMNS]


# ============================================================
# 18. FINAL DATA QUALITY REPORT
# ============================================================

print("\n" + "#" * 90)
print("FINAL DATA QUALITY REPORT")
print("#" * 90)

print(f"Rows        : {len(df):,}")
print(f"Columns     : {len(df.columns)}")
print(f"Stations    : {df['Station'].nunique():,}")
print(
    f"Date range  : "
    f"{df['TravelDate'].min().date()} "
    f"→ "
    f"{df['TravelDate'].max().date()}"
)

print(
    f"Duplicates  : "
    f"{df.duplicated().sum():,}"
)

print(
    f"Missing cells: "
    f"{df.isna().sum().sum():,}"
)


# ============================================================
# 19. MISSING VALUE REPORT
# ============================================================

missing_report = pd.DataFrame({
    "Column": df.columns,
    "Missing": [
        df[col].isna().sum()
        for col in df.columns
    ],
    "Missing_Percent": [
        round(
            df[col].isna().mean() * 100,
            4
        )
        for col in df.columns
    ]
})

missing_report = missing_report.sort_values(
    "Missing",
    ascending=False
)

missing_report.to_csv(
    OUTPUT_DIR / "missing_value_report.csv",
    index=False,
    encoding="utf-8"
)


# ============================================================
# 20. STATION SUMMARY
# ============================================================

station_summary = (
    df.groupby("Station")
    .agg(
        Observations=("TotalFootfall", "size"),
        Mean_Footfall=("TotalFootfall", "mean"),
        Median_Footfall=("TotalFootfall", "median"),
        Std_Footfall=("TotalFootfall", "std"),
        Max_Footfall=("TotalFootfall", "max"),
        First_Date=("TravelDate", "min"),
        Last_Date=("TravelDate", "max")
    )
    .reset_index()
    .sort_values(
        "Mean_Footfall",
        ascending=False
    )
)

station_summary.to_csv(
    OUTPUT_DIR / "station_summary.csv",
    index=False,
    encoding="utf-8"
)


# ============================================================
# 21. YEAR SUMMARY
# ============================================================

year_summary = (
    df.groupby("Year")
    .agg(
        Observations=("TotalFootfall", "size"),
        Stations=("Station", "nunique"),
        Mean_Footfall=("TotalFootfall", "mean"),
        Total_Entries=("EntryTapCount", "sum"),
        Total_Exits=("ExitTapCount", "sum")
    )
    .reset_index()
)

year_summary.to_csv(
    OUTPUT_DIR / "year_summary.csv",
    index=False,
    encoding="utf-8"
)


# ============================================================
# 22. SAVE COMPLETE MASTER DATASET
# ============================================================

MASTER_FILE = (
    OUTPUT_DIR
    / "TfL_StationFootfall_Master_2023_2026.csv"
)

df.to_csv(
    MASTER_FILE,
    index=False,
    encoding="utf-8"
)


# ============================================================
# 23. SAVE PARQUET VERSION
# ============================================================

MASTER_PARQUET = (
    OUTPUT_DIR
    / "TfL_StationFootfall_Master_2023_2026.parquet"
)

df.to_parquet(
    MASTER_PARQUET,
    index=False
)


# ============================================================
# 24. SAMPLE DATA
# ============================================================

print("\n" + "#" * 90)
print("SAMPLE OF FINAL MASTER DATASET")
print("#" * 90)

print(
    df.head(10).to_string(index=False)
)


# ============================================================
# 25. OUTPUT INFORMATION
# ============================================================

print("\n" + "=" * 90)
print("PREPARATION COMPLETED SUCCESSFULLY")
print("=" * 90)

print("\nMASTER CSV:")
print(MASTER_FILE)

print("\nMASTER PARQUET:")
print(MASTER_PARQUET)

print("\nOUTPUT DIRECTORY:")
print(OUTPUT_DIR)

print("\nAdditional reports:")
print("  - missing_value_report.csv")
print("  - station_summary.csv")
print("  - year_summary.csv")

print("\nNext step:")
print("Run the ML-ready dataset validation and temporal train/validation/test split.")