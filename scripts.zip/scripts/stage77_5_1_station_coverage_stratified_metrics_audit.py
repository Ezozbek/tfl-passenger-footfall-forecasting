
from pathlib import Path
import json
import traceback

import numpy as np
import pandas as pd


# ============================================================
# STAGE 77.5.1
# STATION COVERAGE STRATIFIED METRICS AUDIT
# Read-only analysis of existing Stage 76 test predictions.
# ============================================================

ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects"
    r"\PythonProject5_Transport_Scheduling"
)

DATA_DIR = ROOT / "tfl_calendar_ml"
STAGE76_DIR = ROOT / "tfl_mhtdr_station_ablation_stage76"

PREDICTIONS_FILE = (
    STAGE76_DIR / "station_ablation_test_predictions.csv"
)
TRAIN_FILE = DATA_DIR / "train_2023.csv"
VALIDATION_FILE = DATA_DIR / "validation_2024.csv"

OUT_DIR = ROOT / "tfl_stage77_5_1_station_coverage_audit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

METRICS_FILE = OUT_DIR / "stratified_metrics_by_variant.csv"
STATION_FILE = OUT_DIR / "unseen_station_metrics_by_variant.csv"
COVERAGE_FILE = OUT_DIR / "station_coverage_summary.csv"
SUMMARY_FILE = OUT_DIR / "stage77_5_1_summary.txt"
JSON_FILE = OUT_DIR / "stage77_5_1_audit.json"

DATE = "TravelDate"
STATION = "Station"
ACTUAL = "Actual_TotalFootfall"
PREDICTED = "Predicted_TotalFootfall"
VARIANT = "Variant"


def calculate_metrics(group):
    """Calculate pooled row-level regression metrics."""
    actual = pd.to_numeric(
        group[ACTUAL], errors="coerce"
    ).to_numpy(dtype=float)

    predicted = pd.to_numeric(
        group[PREDICTED], errors="coerce"
    ).to_numpy(dtype=float)

    valid = np.isfinite(actual) & np.isfinite(predicted)
    actual = actual[valid]
    predicted = predicted[valid]

    n = len(actual)

    if n == 0:
        return {
            "N": 0,
            "MAE": np.nan,
            "RMSE": np.nan,
            "R2": np.nan,
        }

    errors = predicted - actual
    mae = float(np.mean(np.abs(errors)))
    rmse = float(np.sqrt(np.mean(errors ** 2)))

    ss_total = float(np.sum((actual - np.mean(actual)) ** 2))
    ss_residual = float(np.sum(errors ** 2))

    if n < 2 or ss_total == 0:
        r2 = np.nan
    else:
        r2 = float(1.0 - ss_residual / ss_total)

    return {
        "N": int(n),
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
    }


def main():
    print("=" * 80)
    print("STAGE 77.5.1 — STATION COVERAGE STRATIFIED METRICS AUDIT")
    print("=" * 80)

    # --------------------------------------------------------
    # 1. Validate inputs
    # --------------------------------------------------------
    for path in [PREDICTIONS_FILE, TRAIN_FILE, VALIDATION_FILE]:
        if not path.exists():
            raise FileNotFoundError(f"Required file not found: {path}")

    print("\nLoading existing predictions and split files...")

    predictions = pd.read_csv(
        PREDICTIONS_FILE,
        low_memory=False
    )
    train = pd.read_csv(TRAIN_FILE, low_memory=False)
    validation = pd.read_csv(VALIDATION_FILE, low_memory=False)

    required_predictions = {
        DATE, STATION, ACTUAL, PREDICTED, VARIANT
    }
    missing = required_predictions - set(predictions.columns)

    if missing:
        raise ValueError(
            f"Prediction file is missing required columns: {sorted(missing)}"
        )

    for split_name, frame in [
        ("train", train),
        ("validation", validation),
    ]:
        missing_cols = {STATION} - set(frame.columns)
        if missing_cols:
            raise ValueError(
                f"{split_name} file missing columns: {sorted(missing_cols)}"
            )

    # Normalize station names for consistent matching.
    for frame in [predictions, train, validation]:
        frame[STATION] = (
            frame[STATION].astype("string").str.strip()
        )

    predictions[DATE] = pd.to_datetime(
        predictions[DATE], errors="coerce"
    ).dt.normalize()

    predictions[ACTUAL] = pd.to_numeric(
        predictions[ACTUAL], errors="coerce"
    )
    predictions[PREDICTED] = pd.to_numeric(
        predictions[PREDICTED], errors="coerce"
    )

    if predictions[[STATION, DATE, ACTUAL, PREDICTED, VARIANT]].isna().any().any():
        null_counts = predictions[
            [STATION, DATE, ACTUAL, PREDICTED, VARIANT]
        ].isna().sum().to_dict()
        raise ValueError(
            f"Required prediction fields contain nulls: {null_counts}"
        )

    train_stations = set(train[STATION].dropna().unique())
    validation_stations = set(validation[STATION].dropna().unique())
    known_stations = train_stations | validation_stations

    test_stations = set(predictions[STATION].unique())
    unseen_stations = sorted(test_stations - known_stations)

    predictions["Coverage_Group"] = np.where(
        predictions[STATION].isin(known_stations),
        "Seen_in_Train_Validation",
        "Unseen_Test_Stations",
    )

    print(f"Prediction rows: {len(predictions):,}")
    print(f"Variants: {predictions[VARIANT].nunique()}")
    print(f"Train stations: {len(train_stations):,}")
    print(f"Validation stations: {len(validation_stations):,}")
    print(f"Known stations (union): {len(known_stations):,}")
    print(f"Test stations: {len(test_stations):,}")
    print(f"Unseen test stations: {len(unseen_stations)}")
    print(f"Unseen station names: {unseen_stations}")

    # --------------------------------------------------------
    # 2. Validate test prediction structure
    # --------------------------------------------------------
    key_cols = [DATE, STATION]

    duplicate_rows = int(
        predictions.duplicated([VARIANT] + key_cols).sum()
    )
    if duplicate_rows:
        raise ValueError(
            f"Duplicate Station-Date rows within variants: {duplicate_rows}"
        )

    variants = sorted(predictions[VARIANT].unique().tolist())

    # Confirm actual targets are identical across variants for each key.
    actual_counts = (
        predictions.groupby(key_cols, dropna=False)[ACTUAL]
        .nunique(dropna=False)
    )
    actual_conflicts = int((actual_counts > 1).sum())

    if actual_conflicts:
        raise ValueError(
            "Actual target values differ across variants for "
            f"{actual_conflicts} Station-Date keys."
        )

    row_counts = predictions.groupby(VARIANT).size().to_dict()
    print(f"Rows per variant: {row_counts}")

    # --------------------------------------------------------
    # 3. Coverage summary
    # --------------------------------------------------------
    unique_test_rows = predictions[
        [DATE, STATION, ACTUAL, "Coverage_Group"]
    ].drop_duplicates([DATE, STATION])

    coverage_rows = []

    for group_name, group in [
        ("All_Test_Stations", unique_test_rows),
        (
            "Seen_in_Train_Validation",
            unique_test_rows[
                unique_test_rows["Coverage_Group"]
                == "Seen_in_Train_Validation"
            ],
        ),
        (
            "Unseen_Test_Stations",
            unique_test_rows[
                unique_test_rows["Coverage_Group"]
                == "Unseen_Test_Stations"
            ],
        ),
    ]:
        coverage_rows.append({
            "Coverage_Group": group_name,
            "Unique_Station_Date_Rows": int(len(group)),
            "Unique_Stations": int(group[STATION].nunique()),
            "Date_Start": str(group[DATE].min().date()) if len(group) else None,
            "Date_End": str(group[DATE].max().date()) if len(group) else None,
        })

    coverage_df = pd.DataFrame(coverage_rows)
    coverage_df.to_csv(COVERAGE_FILE, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------
    # 4. Metrics by variant and coverage group
    # --------------------------------------------------------
    metrics_rows = []

    coverage_order = [
        "All_Test_Stations",
        "Seen_in_Train_Validation",
        "Unseen_Test_Stations",
    ]

    for variant in variants:
        variant_df = predictions[predictions[VARIANT] == variant].copy()

        group_frames = {
            "All_Test_Stations": variant_df,
            "Seen_in_Train_Validation": variant_df[
                variant_df["Coverage_Group"]
                == "Seen_in_Train_Validation"
            ],
            "Unseen_Test_Stations": variant_df[
                variant_df["Coverage_Group"]
                == "Unseen_Test_Stations"
            ],
        }

        for coverage_group in coverage_order:
            group = group_frames[coverage_group]
            metrics = calculate_metrics(group)

            metrics_rows.append({
                "Variant": variant,
                "Coverage_Group": coverage_group,
                **metrics,
                "Unique_Stations": int(group[STATION].nunique()),
                "Date_Start": (
                    str(group[DATE].min().date()) if len(group) else None
                ),
                "Date_End": (
                    str(group[DATE].max().date()) if len(group) else None
                ),
            })

    metrics_df = pd.DataFrame(metrics_rows)
    metrics_df.to_csv(METRICS_FILE, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------
    # 5. Metrics for each unseen station and variant
    # --------------------------------------------------------
    unseen_rows = []

    for station in unseen_stations:
        for variant in variants:
            group = predictions[
                (predictions[STATION] == station)
                & (predictions[VARIANT] == variant)
            ]
            metrics = calculate_metrics(group)

            unseen_rows.append({
                "Station": station,
                "Variant": variant,
                **metrics,
                "Date_Start": (
                    str(group[DATE].min().date()) if len(group) else None
                ),
                "Date_End": (
                    str(group[DATE].max().date()) if len(group) else None
                ),
            })

    unseen_df = pd.DataFrame(unseen_rows)
    unseen_df.to_csv(
        STATION_FILE,
        index=False,
        encoding="utf-8-sig"
    )

    # --------------------------------------------------------
    # 6. Checks and machine-readable report
    # --------------------------------------------------------
    checks = {
        "prediction_file_exists": True,
        "duplicate_station_date_variant_rows": duplicate_rows,
        "actual_target_conflicts_across_variants": actual_conflicts,
        "variant_count": len(variants),
        "unseen_test_station_count": len(unseen_stations),
        "unseen_test_stations": unseen_stations,
        "prediction_rows_per_variant": {
            str(k): int(v) for k, v in row_counts.items()
        },
        "all_variants_have_same_row_count": len(set(row_counts.values())) == 1,
    }

    overall_metrics = metrics_df[
        metrics_df["Coverage_Group"] == "All_Test_Stations"
    ]

    report = {
        "stage": "77.5.1",
        "title": "Station Coverage Stratified Metrics Audit",
        "status": (
            "COMPLETED_WITH_REVIEW"
            if unseen_stations
            else "COMPLETED"
        ),
        "prediction_file": str(PREDICTIONS_FILE),
        "train_file": str(TRAIN_FILE),
        "validation_file": str(VALIDATION_FILE),
        "known_station_count": len(known_stations),
        "test_station_count": len(test_stations),
        "unseen_test_stations": unseen_stations,
        "checks": checks,
        "outputs": {
            "stratified_metrics": str(METRICS_FILE),
            "unseen_station_metrics": str(STATION_FILE),
            "coverage_summary": str(COVERAGE_FILE),
            "summary": str(SUMMARY_FILE),
        },
        "interpretation": {
            "metric_scope": (
                "MAE, RMSE and R2 are computed over rows within each "
                "variant and coverage group."
            ),
            "r2_note": (
                "R2 is calculated separately within each group. It is not "
                "the average of station-level R2 values."
            ),
            "unseen_station_note": (
                "Unseen station metrics are descriptive and should be "
                "interpreted cautiously because only three stations are included."
            ),
            "forecast_protocol_note": (
                "This audit stratifies existing predictions by station coverage. "
                "It does not resolve the rolling one-step-ahead versus fixed-origin "
                "multi-step protocol question."
            ),
        },
    }

    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # --------------------------------------------------------
    # 7. Human-readable summary
    # --------------------------------------------------------
    lines = [
        "STAGE 77.5.1 — STATION COVERAGE STRATIFIED METRICS AUDIT",
        "=" * 80,
        f"Prediction file: {PREDICTIONS_FILE}",
        f"Prediction rows: {len(predictions):,}",
        f"Variants: {len(variants)}",
        f"Known stations: {len(known_stations)}",
        f"Test stations: {len(test_stations)}",
        f"Unseen test stations: {len(unseen_stations)}",
        f"Unseen names: {unseen_stations}",
        "",
        "COVERAGE SUMMARY",
        coverage_df.to_string(index=False),
        "",
        "METRICS BY VARIANT AND COVERAGE GROUP",
        metrics_df.to_string(index=False, float_format=lambda x: f"{x:.6f}"),
        "",
        "UNSEEN-STATION METRICS",
        unseen_df.to_string(index=False, float_format=lambda x: f"{x:.6f}"),
        "",
        "AUDIT CHECKS",
        json.dumps(checks, indent=2, ensure_ascii=False),
        "",
        "INTERPRETATION",
        "- All-station metrics summarize pooled test rows.",
        "- Seen-station metrics summarize rows from train/validation-known stations.",
        "- Unseen-station metrics summarize rows from stations absent from train/validation.",
        "- The unseen group contains only three stations; avoid broad generalization.",
        "- This audit does not by itself establish the operational forecast protocol.",
        "",
        "OUTPUT FILES",
        str(METRICS_FILE),
        str(STATION_FILE),
        str(COVERAGE_FILE),
        str(JSON_FILE),
    ]

    SUMMARY_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # --------------------------------------------------------
    # 8. Print concise results to terminal
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("STRATIFIED METRICS")
    print("=" * 80)

    display_cols = [
        "Variant", "Coverage_Group", "N",
        "Unique_Stations", "MAE", "RMSE", "R2"
    ]
    print(
        metrics_df[display_cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.4f}"
        )
    )

    print("\n" + "=" * 80)
    print("UNSEEN STATION METRICS")
    print("=" * 80)

    if len(unseen_df):
        print(
            unseen_df[
                ["Station", "Variant", "N", "MAE", "RMSE", "R2"]
            ].to_string(
                index=False,
                float_format=lambda x: f"{x:.4f}"
            )
        )
    else:
        print("No unseen test stations identified.")

    print("\n" + "=" * 80)
    print("STAGE 77.5.1 COMPLETE")
    print(f"Metrics: {METRICS_FILE}")
    print(f"Station metrics: {STATION_FILE}")
    print(f"Coverage: {COVERAGE_FILE}")
    print(f"Summary: {SUMMARY_FILE}")
    print(f"JSON: {JSON_FILE}")
    print("=" * 80)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        error_file = OUT_DIR / "stage77_5_1_execution_error.txt"
        error_file.write_text(
            f"ERROR: {exc}\n\n{traceback.format_exc()}",
            encoding="utf-8",
        )
        print(f"\nAUDIT FAILED: {exc}")
        print(f"Error details: {error_file}")
        raise
