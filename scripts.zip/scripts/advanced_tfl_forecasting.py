# ablation_tfl_forecasting.py
# ============================================================
# TfL Demand Forecasting - Ablation Study
# ============================================================
#
# Purpose:
#   1. Load the corrected TfL master dataset
#   2. Create leakage-free temporal train/validation/test split
#   3. Compare:
#        A0 - Full proposed feature set
#        A1 - Without calendar features
#        A2 - Without lag features
#        A3 - Without rolling features
#        A4 - Without exogenous features
#        A5 - Minimal autoregressive model
#   4. Train the same forecasting model for each experiment
#   5. Save comparable metrics and predictions
#
# Output:
#   tfl_ablation_results/
#       ablation_results.csv
#       ablation_predictions.csv
#       feature_summary.csv
#
# ============================================================

from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd

from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

warnings.filterwarnings("ignore")


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent

# Change this only if your master dataset has another filename.
DATA_FILE = PROJECT_DIR / "tfl_master_dataset.csv"

OUTPUT_DIR = PROJECT_DIR / "tfl_ablation_results"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42

# Forecast horizon.
# For one-step-ahead forecasting use 1.
HORIZON = 1

# Target column.
TARGET_CANDIDATES = [
    "Demand",
    "demand",
    "Trips",
    "trips",
    "Entry_Count",
    "entry_count",
    "Volume",
    "volume",
    "y",
]

# Time candidates.
TIME_CANDIDATES = [
    "Timestamp",
    "timestamp",
    "Datetime",
    "datetime",
    "DateTime",
    "date_time",
    "Date",
    "date",
]


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def print_header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def find_column(df, candidates, required=True):
    """
    Find a column using case-insensitive matching.
    """

    lower_map = {
        str(col).strip().lower(): col
        for col in df.columns
    }

    for candidate in candidates:
        key = candidate.strip().lower()
        if key in lower_map:
            return lower_map[key]

    if required:
        raise ValueError(
            f"Required column was not found.\n"
            f"Candidates: {candidates}\n"
            f"Available columns:\n{list(df.columns)}"
        )

    return None


def detect_time_column(df):
    """
    Automatically detect the datetime column.
    """

    col = find_column(
        df,
        TIME_CANDIDATES,
        required=False
    )

    if col is not None:
        return col

    # Try columns containing time/date/datetime.
    for c in df.columns:
        name = str(c).lower()

        if (
            "timestamp" in name
            or "datetime" in name
            or name == "date"
            or "date" in name
        ):
            return c

    raise ValueError(
        "Could not identify a datetime column."
    )


def detect_target_column(df):
    """
    Automatically detect forecasting target.
    """

    col = find_column(
        df,
        TARGET_CANDIDATES,
        required=False
    )

    if col is not None:
        return col

    # Try common demand-like names.
    for c in df.columns:
        name = str(c).lower()

        if (
            "demand" in name
            or "trip" in name
            or "volume" in name
            or "count" in name
        ):
            return c

    raise ValueError(
        "Could not identify target column."
    )


def rmse(y_true, y_pred):
    return float(
        np.sqrt(
            mean_squared_error(y_true, y_pred)
        )
    )


def safe_mape(y_true, y_pred):
    """
    MAPE excluding zero targets.
    """

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mask = np.abs(y_true) > 1e-8

    if mask.sum() == 0:
        return np.nan

    return float(
        np.mean(
            np.abs(
                (y_true[mask] - y_pred[mask])
                / y_true[mask]
            )
        ) * 100
    )


def smape(y_true, y_pred):
    """
    Symmetric MAPE.
    """

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    denominator = (
        np.abs(y_true) + np.abs(y_pred)
    )

    mask = denominator > 1e-8

    if mask.sum() == 0:
        return np.nan

    return float(
        np.mean(
            2.0
            * np.abs(y_pred[mask] - y_true[mask])
            / denominator[mask]
        ) * 100
    )


# ============================================================
# LOAD DATA
# ============================================================

print_header("LOADING MASTER DATASET")

if not DATA_FILE.exists():

    # Try to locate CSV automatically.
    csv_files = sorted(
        PROJECT_DIR.glob("*.csv")
    )

    if len(csv_files) == 0:
        raise FileNotFoundError(
            f"No CSV files were found in:\n{PROJECT_DIR}"
        )

    print(
        f"WARNING: {DATA_FILE.name} was not found."
    )

    print("Available CSV files:")

    for f in csv_files:
        print("  -", f.name)

    # Prefer files containing master/tfl.
    preferred = [
        f for f in csv_files
        if (
            "master" in f.name.lower()
            or "tfl" in f.name.lower()
        )
    ]

    if preferred:
        DATA_FILE = preferred[0]
    else:
        DATA_FILE = csv_files[0]

print("Dataset:", DATA_FILE)

df = pd.read_csv(DATA_FILE)

print(f"Rows    : {len(df):,}")
print(f"Columns : {len(df.columns)}")


# ============================================================
# DETECT IMPORTANT COLUMNS
# ============================================================

TIME_COL = detect_time_column(df)
TARGET_COL = detect_target_column(df)

print("\nDetected columns:")
print("  Time   :", TIME_COL)
print("  Target :", TARGET_COL)


# ============================================================
# DATETIME PREPARATION
# ============================================================

print_header("PREPARING TIME INDEX")

df[TIME_COL] = pd.to_datetime(
    df[TIME_COL],
    errors="coerce"
)

invalid_time = df[TIME_COL].isna().sum()

if invalid_time > 0:

    print(
        f"Removing {invalid_time:,} rows "
        f"with invalid timestamps."
    )

    df = df.dropna(
        subset=[TIME_COL]
    ).copy()


df = df.sort_values(
    TIME_COL
).reset_index(drop=True)


# ============================================================
# REMOVE DUPLICATE TIME ROWS
# ============================================================

duplicates = df.duplicated(
    subset=[TIME_COL]
).sum()

if duplicates > 0:

    print(
        f"WARNING: {duplicates:,} duplicate timestamps found."
    )

    # If duplicates exist, aggregate numeric values.
    numeric_columns = df.select_dtypes(
        include=[np.number]
    ).columns.tolist()

    if TARGET_COL in numeric_columns:

        aggregation = {
            c: "mean"
            for c in numeric_columns
        }

        df = (
            df.groupby(
                TIME_COL,
                as_index=False
            )
            .agg(aggregation)
            .sort_values(TIME_COL)
            .reset_index(drop=True)
        )


# ============================================================
# TARGET CLEANING
# ============================================================

df[TARGET_COL] = pd.to_numeric(
    df[TARGET_COL],
    errors="coerce"
)

before = len(df)

df = df.dropna(
    subset=[TARGET_COL]
).copy()

print(
    f"Removed {before - len(df):,} rows "
    f"with missing target."
)


# ============================================================
# FEATURE ENGINEERING
# ============================================================

print_header("CREATING FORECASTING FEATURES")


# ------------------------------------------------------------
# Calendar features
# ------------------------------------------------------------

df["year"] = df[TIME_COL].dt.year
df["month"] = df[TIME_COL].dt.month
df["day"] = df[TIME_COL].dt.day
df["day_of_week"] = df[TIME_COL].dt.dayofweek
df["day_of_year"] = df[TIME_COL].dt.dayofyear
df["week_of_year"] = (
    df[TIME_COL].dt.isocalendar().week
    .astype(int)
)
df["hour"] = df[TIME_COL].dt.hour
df["minute"] = df[TIME_COL].dt.minute

df["is_weekend"] = (
    df["day_of_week"] >= 5
).astype(int)

df["is_month_start"] = (
    df[TIME_COL].dt.is_month_start
).astype(int)

df["is_month_end"] = (
    df[TIME_COL].dt.is_month_end
).astype(int)


# ------------------------------------------------------------
# Cyclic time features
# ------------------------------------------------------------

df["hour_sin"] = np.sin(
    2 * np.pi * df["hour"] / 24
)

df["hour_cos"] = np.cos(
    2 * np.pi * df["hour"] / 24
)

df["dow_sin"] = np.sin(
    2 * np.pi * df["day_of_week"] / 7
)

df["dow_cos"] = np.cos(
    2 * np.pi * df["day_of_week"] / 7
)

df["month_sin"] = np.sin(
    2 * np.pi * df["month"] / 12
)

df["month_cos"] = np.cos(
    2 * np.pi * df["month"] / 12
)


# ------------------------------------------------------------
# Lag features
# ------------------------------------------------------------

lag_values = [
    1,
    2,
    3,
    6,
    12,
    24,
    48,
    72,
    168,
]

LAG_FEATURES = []

for lag in lag_values:

    col = f"lag_{lag}"

    df[col] = (
        df[TARGET_COL]
        .shift(lag)
    )

    LAG_FEATURES.append(col)


# ------------------------------------------------------------
# Rolling features
# ------------------------------------------------------------

ROLLING_FEATURES = []

for window in [3, 6, 12, 24, 48, 168]:

    mean_col = f"rolling_mean_{window}"
    std_col = f"rolling_std_{window}"

    # Shift BEFORE rolling to avoid leakage.
    shifted = df[TARGET_COL].shift(1)

    df[mean_col] = (
        shifted
        .rolling(
            window=window,
            min_periods=window
        )
        .mean()
    )

    df[std_col] = (
        shifted
        .rolling(
            window=window,
            min_periods=window
        )
        .std()
    )

    ROLLING_FEATURES.extend(
        [mean_col, std_col]
    )


# ============================================================
# IDENTIFY EXOGENOUS FEATURES
# ============================================================

print_header("IDENTIFYING EXOGENOUS FEATURES")

EXCLUDE_COLUMNS = {
    TIME_COL,
    TARGET_COL,
}

# Automatically detect numeric variables that are not
# generated calendar/lag/rolling features.

GENERATED_FEATURES = set(
    [
        "year",
        "month",
        "day",
        "day_of_week",
        "day_of_year",
        "week_of_year",
        "hour",
        "minute",
        "is_weekend",
        "is_month_start",
        "is_month_end",
        "hour_sin",
        "hour_cos",
        "dow_sin",
        "dow_cos",
        "month_sin",
        "month_cos",
    ]
    + LAG_FEATURES
    + ROLLING_FEATURES
)

numeric_columns = df.select_dtypes(
    include=[np.number]
).columns.tolist()

EXOGENOUS_FEATURES = [
    c for c in numeric_columns
    if (
        c not in EXCLUDE_COLUMNS
        and c not in GENERATED_FEATURES
    )
]

print("Exogenous features:")

if EXOGENOUS_FEATURES:

    for c in EXOGENOUS_FEATURES:
        print("  -", c)

else:

    print("  None detected.")


# ============================================================
# FEATURE GROUPS
# ============================================================

CALENDAR_FEATURES = [
    "year",
    "month",
    "day",
    "day_of_week",
    "day_of_year",
    "week_of_year",
    "hour",
    "minute",
    "is_weekend",
    "is_month_start",
    "is_month_end",
    "hour_sin",
    "hour_cos",
    "dow_sin",
    "dow_cos",
    "month_sin",
    "month_cos",
]


# ============================================================
# FULL FEATURE SET
# ============================================================

FULL_FEATURES = (
    CALENDAR_FEATURES
    + LAG_FEATURES
    + ROLLING_FEATURES
    + EXOGENOUS_FEATURES
)

# Remove duplicates while preserving order.
FULL_FEATURES = list(
    dict.fromkeys(FULL_FEATURES)
)


# ============================================================
# REMOVE INITIAL NA ROWS
# ============================================================

df_model = df[
    FULL_FEATURES + [TARGET_COL]
].copy()

df_model = df_model.replace(
    [np.inf, -np.inf],
    np.nan
)

before = len(df_model)

df_model = df_model.dropna(
    subset=FULL_FEATURES + [TARGET_COL]
).copy()

print(
    f"\nRows before feature cleaning : {before:,}"
)

print(
    f"Rows after feature cleaning  : {len(df_model):,}"
)


# ============================================================
# TEMPORAL SPLIT
# ============================================================

print_header("TEMPORAL TRAIN / VALIDATION / TEST SPLIT")

df_model = df_model.sort_index()

n = len(df_model)

train_end = int(
    n * 0.70
)

val_end = int(
    n * 0.85
)

train_df = df_model.iloc[
    :train_end
].copy()

val_df = df_model.iloc[
    train_end:val_end
].copy()

test_df = df_model.iloc[
    val_end:
].copy()

print(
    f"Train      : {len(train_df):,}"
)

print(
    f"Validation : {len(val_df):,}"
)

print(
    f"Test       : {len(test_df):,}"
)

print(
    "\nTrain period:"
)

print(
    train_df.index.min(),
    "->",
    train_df.index.max()
)

print(
    "Validation period:"
)

print(
    val_df.index.min(),
    "->",
    val_df.index.max()
)

print(
    "Test period:"
)

print(
    test_df.index.min(),
    "->",
    test_df.index.max()
)


# ============================================================
# EXPERIMENT DEFINITIONS
# ============================================================

EXPERIMENTS = {

    # --------------------------------------------------------
    # A0 - Full model
    # --------------------------------------------------------
    "A0_Full": {
        "description": (
            "Full calendar + lag + rolling + exogenous features"
        ),
        "features": FULL_FEATURES,
    },

    # --------------------------------------------------------
    # A1 - No calendar
    # --------------------------------------------------------
    "A1_No_Calendar": {
        "description": (
            "Remove all calendar and cyclic time features"
        ),
        "features": (
            LAG_FEATURES
            + ROLLING_FEATURES
            + EXOGENOUS_FEATURES
        ),
    },

    # --------------------------------------------------------
    # A2 - No lag
    # --------------------------------------------------------
    "A2_No_Lag": {
        "description": (
            "Remove autoregressive lag features"
        ),
        "features": (
            CALENDAR_FEATURES
            + ROLLING_FEATURES
            + EXOGENOUS_FEATURES
        ),
    },

    # --------------------------------------------------------
    # A3 - No rolling
    # --------------------------------------------------------
    "A3_No_Rolling": {
        "description": (
            "Remove rolling statistical features"
        ),
        "features": (
            CALENDAR_FEATURES
            + LAG_FEATURES
            + EXOGENOUS_FEATURES
        ),
    },

    # --------------------------------------------------------
    # A4 - No exogenous
    # --------------------------------------------------------
    "A4_No_Exogenous": {
        "description": (
            "Remove all external numerical variables"
        ),
        "features": (
            CALENDAR_FEATURES
            + LAG_FEATURES
            + ROLLING_FEATURES
        ),
    },

    # --------------------------------------------------------
    # A5 - Minimal autoregressive
    # --------------------------------------------------------
    "A5_Minimal_AR": {
        "description": (
            "Only lag and rolling demand features"
        ),
        "features": (
            LAG_FEATURES
            + ROLLING_FEATURES
        ),
    },

    # --------------------------------------------------------
    # A6 - Calendar only
    # --------------------------------------------------------
    "A6_Calendar_Only": {
        "description": (
            "Only calendar and cyclic time features"
        ),
        "features": CALENDAR_FEATURES,
    },
}


# ============================================================
# REMOVE FEATURES THAT DO NOT EXIST
# ============================================================

for name, config in EXPERIMENTS.items():

    config["features"] = [
        c
        for c in config["features"]
        if c in df_model.columns
    ]


# ============================================================
# MODEL
# ============================================================

def build_model():
    """
    Same model configuration is used for every ablation
    experiment to isolate the contribution of features.
    """

    return HistGradientBoostingRegressor(
        learning_rate=0.05,
        max_iter=400,
        max_leaf_nodes=31,
        max_depth=None,
        min_samples_leaf=20,
        l2_regularization=0.1,
        random_state=RANDOM_STATE,
    )


# ============================================================
# EVALUATION
# ============================================================

def evaluate_model(
    model,
    X,
    y,
):

    pred = model.predict(X)

    metrics = {
        "MAE": mean_absolute_error(
            y,
            pred
        ),

        "RMSE": rmse(
            y,
            pred
        ),

        "R2": r2_score(
            y,
            pred
        ),

        "MAPE_percent": safe_mape(
            y,
            pred
        ),

        "sMAPE_percent": smape(
            y,
            pred
        ),

        "Mean_Bias": float(
            np.mean(pred - y)
        ),

        "Median_Bias": float(
            np.median(pred - y)
        ),
    }

    return metrics, pred


# ============================================================
# RUN ABLATION EXPERIMENTS
# ============================================================

print_header("RUNNING ABLATION EXPERIMENTS")

all_results = []
all_predictions = []
feature_summary = []


for experiment_name, config in EXPERIMENTS.items():

    features = config["features"]

    print("\n" + "-" * 100)

    print(
        f"EXPERIMENT: {experiment_name}"
    )

    print(
        f"Description: {config['description']}"
    )

    print(
        f"Feature count: {len(features)}"
    )

    if len(features) == 0:

        print(
            "SKIPPED: no features available."
        )

        continue


    # --------------------------------------------------------
    # Data
    # --------------------------------------------------------

    X_train = train_df[features].copy()
    y_train = train_df[TARGET_COL].copy()

    X_val = val_df[features].copy()
    y_val = val_df[TARGET_COL].copy()

    X_test = test_df[features].copy()
    y_test = test_df[TARGET_COL].copy()


    # --------------------------------------------------------
    # Numeric cleaning
    # --------------------------------------------------------

    X_train = X_train.replace(
        [np.inf, -np.inf],
        np.nan
    )

    X_val = X_val.replace(
        [np.inf, -np.inf],
        np.nan
    )

    X_test = X_test.replace(
        [np.inf, -np.inf],
        np.nan
    )


    # --------------------------------------------------------
    # Median imputation using TRAIN ONLY
    # --------------------------------------------------------

    train_medians = X_train.median()

    X_train = X_train.fillna(
        train_medians
    )

    X_val = X_val.fillna(
        train_medians
    )

    X_test = X_test.fillna(
        train_medians
    )


    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    model = build_model()

    start_time = time.perf_counter()

    model.fit(
        X_train,
        y_train
    )

    train_time = (
        time.perf_counter()
        - start_time
    )


    # --------------------------------------------------------
    # Validation
    # --------------------------------------------------------

    val_metrics, val_pred = evaluate_model(
        model,
        X_val,
        y_val
    )


    # --------------------------------------------------------
    # Test
    # --------------------------------------------------------

    test_metrics, test_pred = evaluate_model(
        model,
        X_test,
        y_test
    )


    # --------------------------------------------------------
    # Store result
    # --------------------------------------------------------

    result = {
        "Experiment": experiment_name,
        "Description": config["description"],
        "Feature_Count": len(features),
        "Train_Rows": len(X_train),
        "Validation_Rows": len(X_val),
        "Test_Rows": len(X_test),
        "Validation_MAE": val_metrics["MAE"],
        "Validation_RMSE": val_metrics["RMSE"],
        "Validation_R2": val_metrics["R2"],
        "Validation_MAPE_percent": val_metrics[
            "MAPE_percent"
        ],
        "Validation_sMAPE_percent": val_metrics[
            "sMAPE_percent"
        ],
        "Validation_Mean_Bias": val_metrics[
            "Mean_Bias"
        ],
        "Validation_Median_Bias": val_metrics[
            "Median_Bias"
        ],
        "Test_MAE": test_metrics["MAE"],
        "Test_RMSE": test_metrics["RMSE"],
        "Test_R2": test_metrics["R2"],
        "Test_MAPE_percent": test_metrics[
            "MAPE_percent"
        ],
        "Test_sMAPE_percent": test_metrics[
            "sMAPE_percent"
        ],
        "Test_Mean_Bias": test_metrics[
            "Mean_Bias"
        ],
        "Test_Median_Bias": test_metrics[
            "Median_Bias"
        ],
        "Training_Time_sec": train_time,
    }

    all_results.append(
        result
    )


    # --------------------------------------------------------
    # Feature summary
    # --------------------------------------------------------

    feature_summary.append(
        {
            "Experiment": experiment_name,
            "Feature_Count": len(features),
            "Features": ";".join(features),
        }
    )


    # --------------------------------------------------------
    # Predictions
    # --------------------------------------------------------

    test_prediction_df = pd.DataFrame(
        {
            "Experiment": experiment_name,
            "Timestamp": (
                test_df.index
                if test_df.index.name == TIME_COL
                else np.arange(
                    len(test_df)
                )
            ),
            "Actual": y_test.values,
            "Predicted": test_pred,
            "Residual": (
                test_pred
                - y_test.values
            ),
        }
    )

    all_predictions.append(
        test_prediction_df
    )


    # --------------------------------------------------------
    # Console output
    # --------------------------------------------------------

    print(
        f"Validation MAE  : "
        f"{val_metrics['MAE']:.4f}"
    )

    print(
        f"Validation RMSE : "
        f"{val_metrics['RMSE']:.4f}"
    )

    print(
        f"Validation R2   : "
        f"{val_metrics['R2']:.4f}"
    )

    print(
        f"Test MAE        : "
        f"{test_metrics['MAE']:.4f}"
    )

    print(
        f"Test RMSE       : "
        f"{test_metrics['RMSE']:.4f}"
    )

    print(
        f"Test R2         : "
        f"{test_metrics['R2']:.4f}"
    )

    print(
        f"Training time   : "
        f"{train_time:.2f} sec"
    )


# ============================================================
# SAVE RESULTS
# ============================================================

print_header("SAVING ABLATION RESULTS")


results_df = pd.DataFrame(
    all_results
)

predictions_df = pd.concat(
    all_predictions,
    ignore_index=True
)

feature_summary_df = pd.DataFrame(
    feature_summary
)


# ------------------------------------------------------------
# Sort by test RMSE
# ------------------------------------------------------------

if not results_df.empty:

    results_df = results_df.sort_values(
        "Test_RMSE",
        ascending=True
    ).reset_index(
        drop=True
    )


# ------------------------------------------------------------
# Save
# ------------------------------------------------------------

results_file = (
    OUTPUT_DIR
    / "ablation_results.csv"
)

predictions_file = (
    OUTPUT_DIR
    / "ablation_predictions.csv"
)

features_file = (
    OUTPUT_DIR
    / "feature_summary.csv"
)


results_df.to_csv(
    results_file,
    index=False
)

predictions_df.to_csv(
    predictions_file,
    index=False
)

feature_summary_df.to_csv(
    features_file,
    index=False
)


# ============================================================
# FINAL SUMMARY
# ============================================================

print_header("FINAL ABLATION SUMMARY")

if not results_df.empty:

    display_columns = [
        "Experiment",
        "Feature_Count",
        "Validation_RMSE",
        "Test_MAE",
        "Test_RMSE",
        "Test_R2",
        "Test_MAPE_percent",
        "Test_sMAPE_percent",
    ]

    print(
        results_df[
            display_columns
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.4f}"
        )
    )

else:

    print(
        "No experiments completed."
    )


print("\nOutput files:")

print(
    "  -",
    results_file
)

print(
    "  -",
    predictions_file
)

print(
    "  -",
    features_file
)


# ============================================================
# CHECK COMPONENT CONTRIBUTIONS
# ============================================================

if not results_df.empty:

    full_row = results_df[
        results_df["Experiment"]
        == "A0_Full"
    ]

    if len(full_row) == 1:

        full_rmse = float(
            full_row[
                "Test_RMSE"
            ].iloc[0]
        )

        print(
            "\nComponent contribution relative to "
            "A0_Full:"
        )

        for _, row in results_df.iterrows():

            if row["Experiment"] == "A0_Full":
                continue

            delta = (
                row["Test_RMSE"]
                - full_rmse
            )

            print(
                f"  {row['Experiment']:25s}"
                f" ΔRMSE = {delta:+.4f}"
            )


print("\n" + "=" * 100)
print("ABLATION STUDY COMPLETED")
print("=" * 100)