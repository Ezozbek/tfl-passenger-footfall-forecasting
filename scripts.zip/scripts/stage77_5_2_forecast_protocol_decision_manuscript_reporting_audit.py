from pathlib import Path
import json
import csv
import re
from datetime import datetime

ROOT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

PRED_DIR = ROOT / "tfl_mhtdr_station_ablation_stage76"
AUDIT_DIR = ROOT / "tfl_stage77_5_2_protocol_audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

CONFIG = PRED_DIR / "experiment_config.json"
PREDICTIONS = PRED_DIR / "station_ablation_test_predictions.csv"

KEYWORDS = [
    "test_model.predict",
    ".predict(",
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean",
    "RollingStd",
    "shift(",
    "groupby(",
    "test_2025_2026",
    "validation_2024",
    "train_2023",
    "station_ablation_test_predictions",
    "A0_Full_MHTDR",
    "TimeSeriesSplit",
    "walk_forward",
    "expanding",
    "recursive",
    "fixed-origin",
    "one-step",
    "refit",
    "predict",
]

EXCLUDED_DIRS = {
    ".venv", "__pycache__", ".git", ".idea",
    "tfl_stage77_5_2_protocol_audit",
}

def write_text(filename, content):
    path = AUDIT_DIR / filename
    path.write_text(content, encoding="utf-8")
    return path

def read_json(path):
    if not path.exists():
        return None, f"NOT FOUND: {path}"
    try:
        return json.loads(path.read_text(encoding="utf-8")), None
    except Exception as exc:
        return None, f"JSON READ ERROR: {exc}"

def discover_scripts():
    results = []

    for path in ROOT.rglob("*.py"):
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue

        try:
            text = path.read_text(
                encoding="utf-8", errors="replace"
            )
        except Exception:
            continue

        matches = []
        for line_no, line in enumerate(text.splitlines(), start=1):
            if any(k.lower() in line.lower() for k in KEYWORDS):
                matches.append((line_no, line.rstrip()))

        # Keep only potentially relevant files.
        score = len(matches)
        name = path.name.lower()

        if (
            score >= 3
            or "stage76" in name
            or "mhtdr" in name
            or "ablation" in name
        ):
            results.append((path, score, matches))

    results.sort(key=lambda x: (-x[1], str(x[0]).lower()))
    return results

def inspect_predictions():
    if not PREDICTIONS.exists():
        return {
            "status": "NOT FOUND",
            "path": str(PREDICTIONS),
        }

    required = {
        "TravelDate",
        "Station",
        "Actual_TotalFootfall",
        "Predicted_TotalFootfall",
        "Variant",
    }

    rows = 0
    variants = set()
    dates = []
    missing_required = []
    parse_errors = 0

    try:
        with PREDICTIONS.open(
            "r", encoding="utf-8-sig", newline=""
        ) as f:
            reader = csv.DictReader(f)
            columns = reader.fieldnames or []
            missing_required = sorted(required - set(columns))

            for row in reader:
                rows += 1
                variants.add(row.get("Variant", ""))

                try:
                    dates.append(
                        datetime.strptime(
                            row["TravelDate"][:10], "%Y-%m-%d"
                        ).date()
                    )
                    float(row["Actual_TotalFootfall"])
                    float(row["Predicted_TotalFootfall"])
                except Exception:
                    parse_errors += 1

        return {
            "status": "READ",
            "path": str(PREDICTIONS),
            "rows": rows,
            "columns": columns,
            "missing_required_columns": missing_required,
            "variants": sorted(variants),
            "date_min": str(min(dates)) if dates else None,
            "date_max": str(max(dates)) if dates else None,
            "parse_errors": parse_errors,
        }

    except Exception as exc:
        return {
            "status": "READ ERROR",
            "path": str(PREDICTIONS),
            "error": str(exc),
        }

def main():
    report = []
    report.append("=" * 88)
    report.append(
        "STAGE 77.5.2 — FORECAST PROTOCOL DECISION & "
        "MANUSCRIPT REPORTING AUDIT"
    )
    report.append("=" * 88)
    report.append(f"Project root: {ROOT}")
    report.append(f"Audit output: {AUDIT_DIR}")
    report.append("")

    # 1. Inspect experiment configuration.
    config, config_error = read_json(CONFIG)
    report.append("1. EXPERIMENT CONFIGURATION")
    report.append("-" * 88)

    if config_error:
        report.append(config_error)
    else:
        report.append(json.dumps(config, indent=2, ensure_ascii=False))

    report.append("")

    # 2. Inspect the existing prediction artifact.
    pred_info = inspect_predictions()
    report.append("2. EXISTING TEST PREDICTIONS")
    report.append("-" * 88)
    report.append(json.dumps(pred_info, indent=2, ensure_ascii=False))
    report.append("")

    # 3. Search project source code for implementation evidence.
    report.append("3. SOURCE-CODE EVIDENCE")
    report.append("-" * 88)

    scripts = discover_scripts()
    if not scripts:
        report.append(
            "No relevant Python source files found. "
            "Check whether the original experiment script is in another folder."
        )

    source_lines = []
    for path, score, matches in scripts:
        relative = str(path.relative_to(ROOT))
        report.append(f"\nFILE: {relative} | keyword matches: {score}")
        report.append("." * 88)

        # Include up to 80 matching lines per file.
        for line_no, line in matches[:80]:
            entry = f"{relative}:{line_no}: {line}"
            report.append(entry)
            source_lines.append(entry)

        if len(matches) > 80:
            report.append(
                f"... {len(matches) - 80} additional matching lines omitted"
            )

    report.append("")

    # 4. Evidence-based decision criteria.
    report.append("4. PROTOCOL DECISION CRITERIA")
    report.append("-" * 88)
    report.append(
        "FIXED-ORIGIN MULTI-STEP is supported only if test predictions "
        "for later dates do not use actual target values that became "
        "available after the forecast origin."
    )
    report.append(
        "ROLLING ONE-STEP-AHEAD is supported if each prediction is made "
        "using only information available at that prediction time, "
        "including actual observations from earlier dates when available."
    )
    report.append(
        "A single vectorized predict() call does not by itself determine "
        "the forecasting protocol. The provenance and availability time "
        "of each feature determine whether the protocol is valid."
    )
    report.append(
        "If test-period actuals are used as lag inputs but the intended "
        "deployment requires forecasting the entire horizon before any "
        "test-period actuals arrive, the evaluation is not a valid "
        "fixed-origin multi-step evaluation."
    )
    report.append("")

    # 5. Provisional manuscript reporting.
    report.append("5. PROVISIONAL MANUSCRIPT REPORTING")
    report.append("-" * 88)
    report.append(
        "Do not yet describe the evaluation as fixed-origin multi-step."
    )
    report.append(
        "Do not claim leakage-free fixed-origin forecasting until the "
        "original feature-generation code and forecast origin are verified."
    )
    report.append(
        "If the source confirms sequential one-day-ahead forecasts with "
        "previously observed actual footfall available before each forecast, "
        "report the test protocol as rolling one-step-ahead forecasting."
    )
    report.append(
        "If the source confirms actual observations from the test period "
        "were used for later predictions but the evaluation was intended "
        "to be fixed-origin, redesign the evaluation before making that claim."
    )
    report.append(
        "Report the three unseen Elizabeth line stations separately as a "
        "limited station-coverage/generalization analysis."
    )
    report.append("")

    report.append("6. AUDIT LIMITATIONS")
    report.append("-" * 88)
    report.append(
        "This script searches source code and reads existing artifacts. "
        "Keyword matches are evidence for manual verification, not proof "
        "of runtime execution order or operational data availability."
    )
    report.append(
        "No model retraining, prediction modification, or changes to "
        "existing experiment files are performed."
    )

    report_text = "\n".join(report)
    report_path = write_text(
        "stage77_5_2_protocol_audit_report.txt", report_text
    )

    evidence_path = write_text(
        "stage77_5_2_source_evidence.txt",
        "\n".join(source_lines) if source_lines else
        "No source-code evidence extracted."
    )

    json_path = write_text(
        "stage77_5_2_audit_summary.json",
        json.dumps(
            {
                "stage": "77.5.2",
                "config_found": CONFIG.exists(),
                "predictions_found": PREDICTIONS.exists(),
                "prediction_artifact": pred_info,
                "candidate_scripts": [
                    {
                        "path": str(p.relative_to(ROOT)),
                        "keyword_match_count": score,
                    }
                    for p, score, _ in scripts
                ],
                "decision": "REQUIRES SOURCE-CODE AND PROTOCOL VERIFICATION",
                "model_retrained": False,
                "existing_files_modified": False,
            },
            indent=2,
            ensure_ascii=False,
        ),
    )

    print("\n".join(report[:45]))
    print("\n" + "=" * 88)
    print("STAGE 77.5.2 AUDIT ARTIFACTS CREATED")
    print(f"Report:  {report_path}")
    print(f"Evidence: {evidence_path}")
    print(f"JSON:    {json_path}")
    print("=" * 88)
    print(
        "IMPORTANT: The script does not automatically certify a protocol. "
        "Review the original source-code evidence before finalizing the manuscript."
    )

if __name__ == "__main__":
    main()