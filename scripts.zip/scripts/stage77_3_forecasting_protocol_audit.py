# stage77_3_forecasting_protocol_audit.py
# Stage 77.3 — Forecasting Protocol & Prediction-Horizon Audit
#
# Purpose:
#   1. Inspect the Stage 76 experiment script.
#   2. Locate Stage 76 prediction, metrics and configuration artifacts.
#   3. Check test prediction date coverage and duplicate keys.
#   4. Examine evidence for rolling one-step-ahead versus
#      fixed-origin multi-step forecasting.
#   5. Produce a conservative audit report without modifying
#      existing project files.
#
# Important:
#   Prediction CSV files alone cannot prove the exact information
#   available to the model at each prediction time. Ambiguous cases
#   are marked REVIEW rather than automatically classified as leakage.

from pathlib import Path
import ast
import json
import re
import sys
import traceback

import pandas as pd


# ============================================================
# 1. PATHS AND SETTINGS
# ============================================================

BASE = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

DATA_DIR = BASE / "tfl_calendar_ml"
AUDIT_DIR = BASE / "tfl_stage77_audit"

MASTER_FILE = (
    BASE
    / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)

TEST_FILE = DATA_DIR / "test_2025_2026.csv"

STAGE76_SCRIPT = BASE / "stage76_mhtdr_station_ablation.py"

AUDIT_DIR.mkdir(parents=True, exist_ok=True)

REPORT_CSV = AUDIT_DIR / "stage77_3_protocol_findings.csv"
SUMMARY_TXT = AUDIT_DIR / "stage77_3_protocol_summary.txt"
SOURCE_EVIDENCE_TXT = AUDIT_DIR / "stage77_3_source_evidence.txt"

EXPECTED_TEST_START = pd.Timestamp("2025-01-01")
EXPECTED_TEST_END = pd.Timestamp("2026-07-04")

DATE_CANDIDATES = [
    "TravelDate",
    "Date",
    "date",
    "travel_date",
    "ds",
]

STATION_CANDIDATES = [
    "Station",
    "station",
    "StationName",
    "station_name",
]

TARGET_CANDIDATES = [
    "TotalFootfall",
    "Actual",
    "Actual_TotalFootfall",
    "y_true",
    "actual",
]

PREDICTION_CANDIDATES = [
    "Prediction",
    "Predicted",
    "Predicted_TotalFootfall",
    "PredictedFootfall",
    "y_pred",
    "prediction",
    "pred",
]


# ============================================================
# 2. REPORT HELPERS
# ============================================================

findings = []
evidence_lines = []


def add_finding(check, status, details, evidence=""):
    findings.append(
        {
            "Check": check,
            "Status": status,
            "Details": str(details),
            "Evidence": str(evidence),
        }
    )


def add_evidence(text):
    evidence_lines.append(str(text))


def safe_read_csv(path, nrows=None):
    """Read CSV while trying common encodings."""
    errors = []

    for encoding in ["utf-8-sig", "utf-8", "cp1252"]:
        try:
            return pd.read_csv(
                path,
                encoding=encoding,
                nrows=nrows,
                low_memory=False,
            )
        except Exception as exc:
            errors.append(f"{encoding}: {exc}")

    raise RuntimeError(
        f"Could not read CSV: {path}\n" + "\n".join(errors)
    )


def first_existing_column(df, candidates):
    for col in candidates:
        if col in df.columns:
            return col
    return None


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8-sig") as file:
            return json.load(file)
    except Exception as exc:
        add_finding(
            f"Read JSON: {path.name}",
            "REVIEW",
            f"Could not parse JSON: {exc}",
            str(path),
        )
        return None


def prune_walk_dirs(dirnames):
    excluded = {
        ".venv",
        "venv",
        "__pycache__",
        ".git",
        "node_modules",
        "site-packages",
    }
    dirnames[:] = [
        name for name in dirnames
        if name.lower() not in excluded
    ]


def find_stage76_artifacts():
    """
    Search project files for likely Stage 76 outputs.
    Excludes virtual environments and common large dependency folders.
    """
    matches = []

    wanted = re.compile(
        r"(stage.?76|mhtdr|ablation|prediction|experiment.?config|"
        r"station.?coverage|metrics)",
        re.IGNORECASE,
    )

    for root, dirs, files in __import__("os").walk(BASE):
        prune_walk_dirs(dirs)

        root_path = Path(root)

        # Avoid scanning audit output repeatedly.
        try:
            if AUDIT_DIR.resolve() == root_path.resolve():
                dirs[:] = []
                continue
        except Exception:
            pass

        for filename in files:
            path = root_path / filename

            if not wanted.search(filename):
                continue

            if path.suffix.lower() not in {
                ".py", ".csv", ".json", ".txt", ".log"
            }:
                continue

            matches.append(path)

    return sorted(set(matches), key=lambda p: str(p).lower())


def classify_artifact(path):
    name = path.name.lower()

    if name.endswith(".py"):
        return "python_script"
    if name.endswith(".json") and "config" in name:
        return "experiment_config"
    if name.endswith(".json") and "coverage" in name:
        return "station_coverage_audit"
    if name.endswith(".csv") and "prediction" in name:
        return "prediction_csv"
    if name.endswith(".csv") and "metric" in name:
        return "metrics_csv"
    if name.endswith(".csv") and "ablation" in name:
        return "ablation_csv"
    if name.endswith(".json"):
        return "json"
    if name.endswith(".csv"):
        return "csv"
    return "other"


# ============================================================
# 3. CHECK INPUT FILES
# ============================================================

print("=" * 88)
print("STAGE 77.3 — FORECASTING PROTOCOL & PREDICTION-HORIZON AUDIT")
print("=" * 88)

print(f"Project directory : {BASE}")
print(f"Stage 76 script   : {STAGE76_SCRIPT}")
print(f"Test split        : {TEST_FILE}")
print(f"Master dataset    : {MASTER_FILE}")
print()

if not BASE.exists():
    print("ERROR: Project directory does not exist.")
    sys.exit(1)

if TEST_FILE.exists():
    add_finding(
        "Test split file exists",
        "PASS",
        "The Stage 77.3 test split file was found.",
        str(TEST_FILE),
    )
else:
    add_finding(
        "Test split file exists",
        "FAIL",
        "The expected test split file was not found.",
        str(TEST_FILE),
    )

if MASTER_FILE.exists():
    add_finding(
        "Original master dataset exists",
        "PASS",
        "The original master dataset was found.",
        str(MASTER_FILE),
    )
else:
    add_finding(
        "Original master dataset exists",
        "REVIEW",
        "Master dataset not found at the expected path. "
        "Checks requiring it will be limited.",
        str(MASTER_FILE),
    )

if STAGE76_SCRIPT.exists():
    add_finding(
        "Stage 76 source script exists",
        "PASS",
        "The expected Stage 76 Python script was found.",
        str(STAGE76_SCRIPT),
    )
else:
    add_finding(
        "Stage 76 source script exists",
        "REVIEW",
        "The Stage 76 script was not found at the expected path. "
        "The script may have another filename.",
        str(STAGE76_SCRIPT),
    )


# ============================================================
# 4. INSPECT STAGE 76 SOURCE CODE
# ============================================================

source_text = ""
source_lines = []

if STAGE76_SCRIPT.exists():
    try:
        source_text = STAGE76_SCRIPT.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        source_text = STAGE76_SCRIPT.read_text(
            encoding="utf-8",
            errors="replace",
        )

    source_lines = source_text.splitlines()

    add_evidence("=" * 88)
    add_evidence("STAGE 76 SOURCE INSPECTION")
    add_evidence(f"File: {STAGE76_SCRIPT}")
    add_evidence("=" * 88)

    # Syntax check. This parses code without executing it.
    try:
        ast.parse(source_text)
        add_finding(
            "Stage 76 source syntax",
            "PASS",
            "Python source parsed successfully.",
            str(STAGE76_SCRIPT),
        )
    except SyntaxError as exc:
        add_finding(
            "Stage 76 source syntax",
            "REVIEW",
            f"Syntax parsing failed: {exc}",
            str(STAGE76_SCRIPT),
        )

    # Record relevant source lines and their surrounding context.
    source_patterns = [
        r"\.predict\s*\(",
        r"predict_proba\s*\(",
        r"test_2025_2026",
        r"TotalFootfall",
        r"Lag_1",
        r"Lag_7",
        r"Lag_14",
        r"Lag_28",
        r"RollingMean",
        r"RollingStd",
        r"iterrows\s*\(",
        r"itertuples\s*\(",
        r"for\s+.*date",
        r"for\s+.*day",
        r"shift\s*\(",
        r"concat\s*\(",
        r"experiment_config",
        r"final_test_predictions",
        r"prediction",
        r"test_df",
        r"X_test",
        r"y_test",
    ]

    relevant_lines = []

    for index, line in enumerate(source_lines, start=1):
        if any(
            re.search(pattern, line, re.IGNORECASE)
            for pattern in source_patterns
        ):
            relevant_lines.append((index, line.rstrip()))

    for line_no, line in relevant_lines:
        add_evidence(f"{line_no:5d}: {line}")

    # Conservative static evidence.
    has_prediction_call = bool(
        re.search(r"\.predict\s*\(", source_text)
    )

    has_test_split_reference = bool(
        re.search(
            r"test_2025_2026|X_test|test_df",
            source_text,
            re.IGNORECASE,
        )
    )

    has_explicit_date_loop = bool(
        re.search(
            r"for\s+\w+\s+in\s+.*(?:date|day|dates|days)",
            source_text,
            re.IGNORECASE,
        )
    )

    has_row_iteration = bool(
        re.search(
            r"\.(?:iterrows|itertuples)\s*\(",
            source_text,
        )
    )

    has_recursive_prediction_reference = bool(
        re.search(
            r"(?:recursive|recursive_forecast|"
            r"predicted_lag|prediction_as_lag|"
            r"forecasted_value|forecast_value)",
            source_text,
            re.IGNORECASE,
        )
    )

    add_finding(
        "Prediction call in source",
        "PASS" if has_prediction_call else "REVIEW",
        "A model .predict(...) call was found."
        if has_prediction_call
        else "No model .predict(...) call was found by the static search.",
        str(STAGE76_SCRIPT),
    )

    add_finding(
        "Test split referenced in source",
        "PASS" if has_test_split_reference else "REVIEW",
        "A test split / X_test / test_df reference was found."
        if has_test_split_reference
        else "No obvious test split reference was found.",
        str(STAGE76_SCRIPT),
    )

    add_finding(
        "Explicit date iteration in source",
        "REVIEW",
        (
            "A possible date iteration pattern was found. "
            "This alone does not prove recursive or rolling forecasting."
            if has_explicit_date_loop
            else
            "No obvious explicit date loop was detected. "
            "Vectorized one-shot prediction remains possible."
        ),
        str(STAGE76_SCRIPT),
    )

    add_finding(
        "Row-by-row iteration in source",
        "REVIEW",
        (
            "iterrows()/itertuples() appears in the source. "
            "Inspect its context before drawing conclusions."
            if has_row_iteration
            else
            "No iterrows()/itertuples() call was found."
        ),
        str(STAGE76_SCRIPT),
    )

    add_finding(
        "Recursive forecasting keywords",
        "REVIEW",
        (
            "Potential recursive-forecasting keywords were found. "
            "Their actual use must be verified in context."
            if has_recursive_prediction_reference
            else
            "No obvious recursive-forecasting keyword was found. "
            "Recursive prediction cannot be ruled out solely by this search."
        ),
        str(STAGE76_SCRIPT),
    )

else:
    has_prediction_call = False
    has_test_split_reference = False
    has_explicit_date_loop = False
    has_row_iteration = False
    has_recursive_prediction_reference = False

    add_evidence("Stage 76 source script unavailable at expected path.")


# ============================================================
# 5. LOCATE STAGE 76 OUTPUTS
# ============================================================

artifacts = find_stage76_artifacts()

add_evidence("")
add_evidence("=" * 88)
add_evidence("DISCOVERED PROJECT ARTIFACTS")
add_evidence("=" * 88)

for path in artifacts:
    add_evidence(f"[{classify_artifact(path)}] {path}")

prediction_files = [
    p for p in artifacts
    if p.suffix.lower() == ".csv"
    and "prediction" in p.name.lower()
]

config_files = [
    p for p in artifacts
    if p.suffix.lower() == ".json"
    and "config" in p.name.lower()
]

metrics_files = [
    p for p in artifacts
    if p.suffix.lower() == ".csv"
    and "metric" in p.name.lower()
]

coverage_files = [
    p for p in artifacts
    if p.suffix.lower() == ".json"
    and "coverage" in p.name.lower()
]

add_finding(
    "Stage 76 prediction artifacts discovered",
    "PASS" if prediction_files else "REVIEW",
    f"Found {len(prediction_files)} CSV file(s) whose names contain 'prediction'.",
    "; ".join(str(p) for p in prediction_files[:20]),
)

add_finding(
    "Stage 76 configuration artifacts discovered",
    "PASS" if config_files else "REVIEW",
    f"Found {len(config_files)} JSON configuration file(s).",
    "; ".join(str(p) for p in config_files[:20]),
)

add_finding(
    "Stage 76 metrics artifacts discovered",
    "PASS" if metrics_files else "REVIEW",
    f"Found {len(metrics_files)} CSV file(s) whose names contain 'metric'.",
    "; ".join(str(p) for p in metrics_files[:20]),
)


# ============================================================
# 6. INSPECT CONFIGURATION FILES
# ============================================================

add_evidence("")
add_evidence("=" * 88)
add_evidence("CONFIGURATION CONTENTS")
add_evidence("=" * 88)

protocol_terms = re.compile(
    r"forecast|horizon|rolling|recursive|one.?step|"
    r"multi.?step|teacher|forcing|test|split|lag|"
    r"target|origin|refit|update|retrain",
    re.IGNORECASE,
)

for config_path in config_files:
    config = read_json(config_path)

    add_evidence("")
    add_evidence(f"Configuration file: {config_path}")

    if config is None:
        continue

    try:
        config_string = json.dumps(
            config,
            ensure_ascii=False,
            indent=2,
        )
    except Exception:
        config_string = str(config)

    add_evidence(config_string[:20000])

    matching_items = []

    def scan_config(obj, prefix=""):
        if isinstance(obj, dict):
            for key, value in obj.items():
                new_prefix = f"{prefix}.{key}" if prefix else key

                if protocol_terms.search(str(key)):
                    matching_items.append(
                        f"{new_prefix} = {value!r}"
                    )

                scan_config(value, new_prefix)

        elif isinstance(obj, list):
            for i, value in enumerate(obj):
                scan_config(value, f"{prefix}[{i}]")

    scan_config(config)

    if matching_items:
        for item in matching_items:
            add_evidence(f"Relevant config field: {item}")

        add_finding(
            f"Protocol-related fields in {config_path.name}",
            "REVIEW",
            "Relevant configuration fields were found; "
            "they require interpretation against the prediction code.",
            " | ".join(matching_items[:30]),
        )
    else:
        add_finding(
            f"Protocol-related fields in {config_path.name}",
            "REVIEW",
            "No obvious protocol/horizon fields were found in the JSON.",
            str(config_path),
        )


# ============================================================
# 7. INSPECT PREDICTION CSV STRUCTURE AND DATES
# ============================================================

test_df = None

if TEST_FILE.exists():
    try:
        test_df = safe_read_csv(TEST_FILE)
        add_finding(
            "Test split readable",
            "PASS",
            f"Loaded {len(test_df):,} rows and {len(test_df.columns)} columns.",
            str(TEST_FILE),
        )
    except Exception as exc:
        add_finding(
            "Test split readable",
            "FAIL",
            str(exc),
            str(TEST_FILE),
        )

if test_df is not None:
    date_col = first_existing_column(test_df, DATE_CANDIDATES)
    station_col = first_existing_column(test_df, STATION_CANDIDATES)

    if date_col:
        parsed_dates = pd.to_datetime(
            test_df[date_col],
            errors="coerce",
        )

        valid_dates = parsed_dates.dropna()

        add_finding(
            "Test split date column",
            "PASS" if len(valid_dates) == len(test_df) else "REVIEW",
            (
                f"Date column={date_col}; valid dates={len(valid_dates):,}/"
                f"{len(test_df):,}; "
                f"minimum={valid_dates.min() if len(valid_dates) else 'N/A'}; "
                f"maximum={valid_dates.max() if len(valid_dates) else 'N/A'}"
            ),
            str(TEST_FILE),
        )

        if len(valid_dates):
            start = valid_dates.min().normalize()
            end = valid_dates.max().normalize()

            boundary_status = (
                "PASS"
                if start == EXPECTED_TEST_START
                and end == EXPECTED_TEST_END
                else "REVIEW"
            )

            add_finding(
                "Test split date boundaries",
                boundary_status,
                f"Observed {start.date()} to {end.date()}; "
                f"expected {EXPECTED_TEST_START.date()} to "
                f"{EXPECTED_TEST_END.date()}.",
                str(TEST_FILE),
            )

    else:
        add_finding(
            "Test split date column",
            "REVIEW",
            "No recognized date column was found.",
            ", ".join(map(str, test_df.columns)),
        )

    if station_col and date_col:
        normalized_dates = pd.to_datetime(
            test_df[date_col],
            errors="coerce",
        ).dt.normalize()

        duplicate_count = int(
            test_df.assign(_audit_date=normalized_dates)
            .duplicated(subset=[station_col, "_audit_date"])
            .sum()
        )

        add_finding(
            "Test split unique station-date keys",
            "PASS" if duplicate_count == 0 else "FAIL",
            f"Duplicate Station-Date keys: {duplicate_count:,}.",
            str(TEST_FILE),
        )

else:
    date_col = None
    station_col = None


# Inspect each prediction artifact.
prediction_inspections = []

for pred_path in prediction_files:
    try:
        pred_df = safe_read_csv(pred_path)

        pred_date_col = first_existing_column(
            pred_df,
            DATE_CANDIDATES,
        )
        pred_station_col = first_existing_column(
            pred_df,
            STATION_CANDIDATES,
        )
        actual_col = first_existing_column(
            pred_df,
            TARGET_CANDIDATES,
        )
        predicted_col = first_existing_column(
            pred_df,
            PREDICTION_CANDIDATES,
        )

        info = {
            "path": pred_path,
            "rows": len(pred_df),
            "columns": list(pred_df.columns),
            "date_col": pred_date_col,
            "station_col": pred_station_col,
            "actual_col": actual_col,
            "predicted_col": predicted_col,
            "min_date": None,
            "max_date": None,
            "duplicate_keys": None,
            "test_date_coverage": None,
        }

        add_evidence("")
        add_evidence("-" * 88)
        add_evidence(f"PREDICTION FILE: {pred_path}")
        add_evidence(f"Rows: {len(pred_df):,}")
        add_evidence(f"Columns: {pred_df.columns.tolist()}")

        if pred_date_col:
            pred_dates = pd.to_datetime(
                pred_df[pred_date_col],
                errors="coerce",
            )

            valid_pred_dates = pred_dates.dropna()

            if len(valid_pred_dates):
                info["min_date"] = str(valid_pred_dates.min())
                info["max_date"] = str(valid_pred_dates.max())

            add_evidence(
                f"Date range: {info['min_date']} to {info['max_date']}"
            )

            if pred_station_col:
                temp = pred_df.copy()
                temp["_audit_date"] = pd.to_datetime(
                    temp[pred_date_col],
                    errors="coerce",
                ).dt.normalize()

                duplicate_count = int(
                    temp.duplicated(
                        subset=[pred_station_col, "_audit_date"]
                    ).sum()
                )

                info["duplicate_keys"] = duplicate_count

                add_finding(
                    f"Prediction keys: {pred_path.name}",
                    "PASS" if duplicate_count == 0 else "REVIEW",
                    f"Rows={len(pred_df):,}; duplicate Station-Date "
                    f"keys={duplicate_count:,}.",
                    str(pred_path),
                )

            if test_df is not None and date_col and station_col:
                test_keys = set(
                    zip(
                        test_df[station_col].astype(str),
                        pd.to_datetime(
                            test_df[date_col],
                            errors="coerce",
                        ).dt.normalize().astype(str),
                    )
                )

                pred_station_values = (
                    pred_df[pred_station_col].astype(str)
                    if pred_station_col
                    else None
                )

                if pred_station_values is not None:
                    pred_keys = set(
                        zip(
                            pred_station_values,
                            pd.to_datetime(
                                pred_df[pred_date_col],
                                errors="coerce",
                            ).dt.normalize().astype(str),
                        )
                    )

                    matched = len(test_keys & pred_keys)
                    coverage = (
                        100.0 * matched / len(test_keys)
                        if test_keys
                        else 0.0
                    )

                    info["test_date_coverage"] = coverage

                    add_finding(
                        f"Prediction key coverage: {pred_path.name}",
                        "PASS" if coverage >= 99.9 else "REVIEW",
                        f"Prediction keys matching test split: "
                        f"{matched:,}/{len(test_keys):,} ({coverage:.3f}%).",
                        str(pred_path),
                    )

        else:
            add_finding(
                f"Prediction date column: {pred_path.name}",
                "REVIEW",
                "No recognized date column was found in this prediction file.",
                ", ".join(map(str, pred_df.columns)),
            )

        if actual_col and predicted_col:
            actual_values = pd.to_numeric(
                pred_df[actual_col],
                errors="coerce",
            )
            prediction_values = pd.to_numeric(
                pred_df[predicted_col],
                errors="coerce",
            )

            valid = actual_values.notna() & prediction_values.notna()

            add_finding(
                f"Prediction/actual columns: {pred_path.name}",
                "PASS" if valid.any() else "REVIEW",
                f"Actual column={actual_col}; prediction column={predicted_col}; "
                f"rows with numeric pairs={int(valid.sum()):,}.",
                str(pred_path),
            )

        else:
            add_finding(
                f"Prediction/actual columns: {pred_path.name}",
                "REVIEW",
                "Could not identify both actual and predicted value columns "
                "automatically. Inspect the listed column names.",
                ", ".join(map(str, pred_df.columns)),
            )

        prediction_inspections.append(info)

    except Exception as exc:
        add_finding(
            f"Read prediction file: {pred_path.name}",
            "REVIEW",
            f"Could not inspect prediction CSV: {exc}",
            str(pred_path),
        )


# ============================================================
# 8. DETERMINE WHAT CAN AND CANNOT BE CONCLUDED
# ============================================================

add_evidence("")
add_evidence("=" * 88)
add_evidence("PROTOCOL INTERPRETATION")
add_evidence("=" * 88)

add_evidence(
    "A vectorized model.predict(X_test) call can indicate batch prediction, "
    "but does not by itself prove that all features were constructed at the "
    "forecast origin. The feature-generation procedure must also be checked."
)

add_evidence(
    "A date loop or row iteration can occur for many reasons and does not "
    "by itself prove recursive forecasting."
)

add_evidence(
    "A prediction CSV with actual values and predictions does not, by itself, "
    "show whether actual test targets were fed back into later predictions."
)

add_evidence(
    "Stage 77.2 showed that lag values match previous actual observations. "
    "Whether this is valid depends on whether the experiment was a rolling "
    "one-step-ahead protocol or a fixed-origin multi-step protocol."
)

if (
    has_prediction_call
    and has_test_split_reference
    and prediction_files
):
    add_finding(
        "Evidence that Stage 76 generated test predictions",
        "PASS",
        "The source includes a prediction call and test-split reference, "
        "and prediction artifacts were discovered. This confirms the presence "
        "of prediction workflow, not the exact forecast protocol.",
        str(STAGE76_SCRIPT),
    )
else:
    add_finding(
        "Evidence that Stage 76 generated test predictions",
        "REVIEW",
        "Source code or prediction artifacts are incomplete or not "
        "automatically identifiable.",
        str(STAGE76_SCRIPT),
    )

add_finding(
    "Final classification: rolling vs fixed-origin",
    "REVIEW",
    "Do not classify the Stage 76 experiment as rolling one-step-ahead "
    "or fixed-origin multi-step from filenames, metrics, or lag alignment "
    "alone. Review the exact order in which test features and predictions "
    "were generated in the Stage 76 source.",
    str(STAGE76_SCRIPT),
)


# ============================================================
# 9. SAVE REPORTS
# ============================================================

report_df = pd.DataFrame(findings)

report_df.to_csv(
    REPORT_CSV,
    index=False,
    encoding="utf-8-sig",
)

SOURCE_EVIDENCE_TXT.write_text(
    "\n".join(evidence_lines),
    encoding="utf-8",
)

status_counts = (
    report_df["Status"].value_counts().to_dict()
    if not report_df.empty
    else {}
)

summary_lines = [
    "=" * 88,
    "STAGE 77.3 — FORECASTING PROTOCOL AUDIT SUMMARY",
    "=" * 88,
    f"Project: {BASE}",
    f"Stage 76 script found: {STAGE76_SCRIPT.exists()}",
    f"Test split found: {TEST_FILE.exists()}",
    f"Master dataset found: {MASTER_FILE.exists()}",
    f"Prediction CSV files found: {len(prediction_files)}",
    f"Configuration JSON files found: {len(config_files)}",
    f"Metrics CSV files found: {len(metrics_files)}",
    "",
    "Finding counts:",
]

for status in ["PASS", "REVIEW", "FAIL"]:
    summary_lines.append(
        f"  {status}: {status_counts.get(status, 0)}"
    )

summary_lines += [
    "",
    "PROTOCOL CONCLUSION:",
    (
        "The audit is evidence-gathering only. Do not label the Stage 76 "
        "results as fixed-origin multi-step or rolling one-step-ahead until "
        "the feature construction and prediction-generation sequence has "
        "been verified from source code."
    ),
    "",
    "Files created:",
    str(REPORT_CSV),
    str(SUMMARY_TXT),
    str(SOURCE_EVIDENCE_TXT),
    "",
    "No existing project files were modified by this script.",
]

SUMMARY_TXT.write_text(
    "\n".join(summary_lines),
    encoding="utf-8",
)

print()
print("=" * 88)
print("STAGE 77.3 AUDIT SUMMARY")
print("=" * 88)
print(f"Stage 76 script found : {STAGE76_SCRIPT.exists()}")
print(f"Test split found      : {TEST_FILE.exists()}")
print(f"Master dataset found  : {MASTER_FILE.exists()}")
print(f"Prediction CSV files  : {len(prediction_files)}")
print(f"Config JSON files     : {len(config_files)}")
print(f"Metrics CSV files     : {len(metrics_files)}")
print()
print("Finding counts:")

for status in ["PASS", "REVIEW", "FAIL"]:
    print(f"  {status:6s}: {status_counts.get(status, 0)}")

print()
print("Reports saved:")
print(f"  {REPORT_CSV}")
print(f"  {SUMMARY_TXT}")
print(f"  {SOURCE_EVIDENCE_TXT}")
print()
print(
    "IMPORTANT: This audit does not automatically certify the forecast "
    "protocol. Inspect the source evidence and any REVIEW findings."
)
print("Audit complete. No existing project files were modified.")
print("=" * 88)