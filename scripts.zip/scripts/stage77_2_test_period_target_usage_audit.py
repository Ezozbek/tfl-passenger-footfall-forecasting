
from pathlib import Path
import pandas as pd

BASE = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

DATA_DIR = BASE / "tfl_calendar_ml"
OUT_DIR = BASE / "tfl_stage77_audit"
OUT_DIR.mkdir(exist_ok=True)

MASTER_FILE = (
    BASE / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)
TEST_FILE = DATA_DIR / "test_2025_2026.csv"

print("=" * 80)
print("STAGE 77.2 — TEST-PERIOD TARGET USAGE AUDIT")
print("=" * 80)

master = pd.read_csv(
    MASTER_FILE,
    parse_dates=["TravelDate"],
    low_memory=False,
)

test = pd.read_csv(
    TEST_FILE,
    parse_dates=["TravelDate"],
    low_memory=False,
)

master = master.sort_values(["Station", "TravelDate"])

if master.duplicated(["Station", "TravelDate"]).any():
    raise ValueError("Duplicate Station-Date keys in master dataset.")

# Build an exact calendar-date lookup of observed target values.
lookup = master[
    ["Station", "TravelDate", "TotalFootfall"]
].copy()

rows = []

for lag_days in [1, 7, 14, 28]:
    feature = f"Lag_{lag_days}"

    if feature not in test.columns:
        raise ValueError(f"Missing feature: {feature}")

    prior = lookup.copy()
    prior["TravelDate"] += pd.Timedelta(days=lag_days)
    prior = prior.rename(
        columns={"TotalFootfall": "_PriorActual"}
    )

    check = test[
        ["Station", "TravelDate", feature]
    ].merge(
        prior,
        on=["Station", "TravelDate"],
        how="left",
        validate="many_to_one",
    )

    has_feature = check[feature].notna()
    has_prior_actual = check["_PriorActual"].notna()
    comparable = has_feature & has_prior_actual

    mismatches = (
        (
            check.loc[comparable, feature].astype(float)
            - check.loc[comparable, "_PriorActual"].astype(float)
        ).abs() > 1e-8
    ).sum()

    # Was the source observation itself inside the test period?
    prior_date = check["TravelDate"] - pd.Timedelta(days=lag_days)
    prior_in_test_period = prior_date >= pd.Timestamp("2025-01-01")

    uses_test_actual = (
        comparable & prior_in_test_period
    )

    rows.append({
        "Feature": feature,
        "Test_Rows": len(check),
        "Feature_Available": int(has_feature.sum()),
        "Comparable_To_Actual": int(comparable.sum()),
        "Mismatches": int(mismatches),
        "Rows_Using_Prior_Test_Period_Actual": int(
            uses_test_actual.sum()
        ),
        "Percent_Of_Test_Rows_Using_Prior_Test_Actual": round(
            100 * uses_test_actual.sum() / len(check), 3
        ) if len(check) else 0,
    })

report = pd.DataFrame(rows)

report.to_csv(
    OUT_DIR / "stage77_2_test_period_target_usage.csv",
    index=False,
)

print(report.to_string(index=False))
print("\nSaved report:")
print(OUT_DIR / "stage77_2_test_period_target_usage.csv")
print("\nAudit complete. No existing project files were modified.")
