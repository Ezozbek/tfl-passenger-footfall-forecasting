from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    GradientBoostingRegressor,
)

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

warnings.filterwarnings("ignore")


# =============================================================================
# 1. PATHS
# =============================================================================

BASE_DIR = Path(
    r"c:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

DATA_DIR = BASE_DIR / "tfl_calendar_ml"

TRAIN_FILE = DATA_DIR / "train_2023.csv"
VALIDATION_FILE = DATA_DIR / "validation_2024.csv"
TEST_FILE = DATA_DIR / "test_2025_2026.csv"

OUTPUT_DIR = BASE_DIR / "tfl_baseline_results"
OUTPUT_DIR.mkdir(exist_ok=True)


# =============================================================================
# 2. CONFIGURATION
# =============================================================================

TARGET = "TotalFootfall"

FEATURES = [
    "Station",
    "DayOfWeek",
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

CATEGORICAL_FEATURES = [
    "Station",
    "DayOfWeek",
]

NUMERIC_FEATURES = [
    "Year",
    "Month",
    "Day",
    "DayOfYear",
    "WeekOfYear",
    "DayOfWeek_Num",
    "IsWeekend",
    "Lag_1",
    "Lag_7",
    "Lag_14",
    "Lag_28",
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]


# =============================================================================
# 3. LOAD DATA
# =============================================================================

print("=" * 100)
print("LOADING CALENDAR-AWARE TFL DATASETS")
print("=" * 100)

train = pd.read_csv(
    TRAIN_FILE,
    parse_dates=["TravelDate"]
)

validation = pd.read_csv(
    VALIDATION_FILE,
    parse_dates=["TravelDate"]
)

test = pd.read_csv(
    TEST_FILE,
    parse_dates=["TravelDate"]
)

print(f"Train      : {len(train):,}")
print(f"Validation : {len(validation):,}")
print(f"Test       : {len(test):,}")

print(
    f"Train dates      : "
    f"{train['TravelDate'].min().date()} -> "
    f"{train['TravelDate'].max().date()}"
)

print(
    f"Validation dates : "
    f"{validation['TravelDate'].min().date()} -> "
    f"{validation['TravelDate'].max().date()}"
)

print(
    f"Test dates       : "
    f"{test['TravelDate'].min().date()} -> "
    f"{test['TravelDate'].max().date()}"
)


# =============================================================================
# 4. BASIC DATA CHECK
# =============================================================================

print("\n" + "=" * 100)
print("BASIC DATA CHECK")
print("=" * 100)

for name, data in [
    ("TRAIN", train),
    ("VALIDATION", validation),
    ("TEST", test),
]:

    duplicates = data.duplicated(
        subset=["Station", "TravelDate"]
    ).sum()

    missing_target = data[TARGET].isna().sum()

    negative_target = (
        data[TARGET] < 0
    ).sum()

    print(
        f"{name:12s} | "
        f"duplicates={duplicates:,} | "
        f"missing_target={missing_target:,} | "
        f"negative_target={negative_target:,}"
    )

    if duplicates > 0:
        raise ValueError(
            f"Duplicate Station-Date rows found in {name}"
        )

    if missing_target > 0:
        raise ValueError(
            f"Missing target values found in {name}"
        )

    if negative_target > 0:
        raise ValueError(
            f"Negative target values found in {name}"
        )


# =============================================================================
# 5. TEMPORAL LEAKAGE CHECK
# =============================================================================

print("\n" + "=" * 100)
print("TEMPORAL LEAKAGE CHECK")
print("=" * 100)

if train["TravelDate"].max() >= validation["TravelDate"].min():
    raise ValueError(
        "Temporal leakage detected between train and validation."
    )

if validation["TravelDate"].max() >= test["TravelDate"].min():
    raise ValueError(
        "Temporal leakage detected between validation and test."
    )

print("PASS: Train < Validation < Test chronologically.")


# =============================================================================
# 6. PREPARE X / y
# =============================================================================

X_train = train[FEATURES].copy()
y_train = train[TARGET].copy()

X_val = validation[FEATURES].copy()
y_val = validation[TARGET].copy()

X_test = test[FEATURES].copy()
y_test = test[TARGET].copy()


# =============================================================================
# 7. PREPROCESSOR
# =============================================================================

categorical_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="most_frequent"
            ),
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore",
                sparse_output=True,
            ),
        ),
    ]
)

numeric_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="median"
            ),
        ),
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            categorical_pipeline,
            CATEGORICAL_FEATURES,
        ),
        (
            "numeric",
            numeric_pipeline,
            NUMERIC_FEATURES,
        ),
    ]
)


# =============================================================================
# 8. METRICS
# =============================================================================

def calculate_metrics(
    y_true,
    y_pred,
):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    mae = mean_absolute_error(
        y_true,
        y_pred
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_true,
            y_pred
        )
    )

    r2 = r2_score(
        y_true,
        y_pred
    )

    # MAPE:
    # Ignore zero targets to avoid division by zero.
    nonzero = y_true != 0

    if nonzero.sum() > 0:
        mape = (
            np.mean(
                np.abs(
                    (
                        y_true[nonzero]
                        - y_pred[nonzero]
                    )
                    / y_true[nonzero]
                )
            )
            * 100
        )
    else:
        mape = np.nan

    # SMAPE
    denominator = (
        np.abs(y_true)
        + np.abs(y_pred)
    )

    valid_smape = denominator != 0

    if valid_smape.sum() > 0:
        smape = (
            np.mean(
                2
                * np.abs(
                    y_pred[valid_smape]
                    - y_true[valid_smape]
                )
                / denominator[valid_smape]
            )
            * 100
        )
    else:
        smape = np.nan

    # Pearson correlation
    if (
        np.std(y_true) > 0
        and np.std(y_pred) > 0
    ):
        pearson_r = np.corrcoef(
            y_true,
            y_pred
        )[0, 1]
    else:
        pearson_r = np.nan

    return {
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "MAPE_percent": mape,
        "SMAPE_percent": smape,
        "Pearson_r": pearson_r,
    }


# =============================================================================
# 9. BASELINE MODELS
# =============================================================================

models = {

    "LinearRegression": Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor
            ),
            (
                "model",
                LinearRegression()
            ),
        ]
    ),

    "RandomForest": Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor
            ),
            (
                "model",
                RandomForestRegressor(
                    n_estimators=200,
                    max_depth=20,
                    min_samples_leaf=2,
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    ),

    "ExtraTrees": Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor
            ),
            (
                "model",
                ExtraTreesRegressor(
                    n_estimators=200,
                    max_depth=25,
                    min_samples_leaf=2,
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    ),

    "GradientBoosting": Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor
            ),
            (
                "model",
                GradientBoostingRegressor(
                    n_estimators=300,
                    learning_rate=0.05,
                    max_depth=3,
                    min_samples_leaf=5,
                    loss="huber",
                    random_state=42,
                ),
            ),
        ]
    ),
}


# =============================================================================
# 10. RESULT STORAGE
# =============================================================================

validation_results = []
test_results = []


# =============================================================================
# 11. NAIVE BASELINES
# =============================================================================

print("\n" + "=" * 100)
print("NAIVE BASELINE MODELS")
print("=" * 100)


# -------------------------------------------------------------------------
# Last-day baseline
# -------------------------------------------------------------------------

print("\nRunning: Naive_LastDay")

val_pred = validation["Lag_1"].values
test_pred = test["Lag_1"].values

val_metrics = calculate_metrics(
    y_val,
    val_pred
)

test_metrics = calculate_metrics(
    y_test,
    test_pred
)

validation_results.append({
    "Model": "Naive_LastDay",
    **val_metrics
})

test_results.append({
    "Model": "Naive_LastDay",
    **test_metrics
})

print(
    f"Validation RMSE: "
    f"{val_metrics['RMSE']:.4f}"
)

print(
    f"Test RMSE      : "
    f"{test_metrics['RMSE']:.4f}"
)


# -------------------------------------------------------------------------
# Seasonal 7-day baseline
# -------------------------------------------------------------------------

print("\nRunning: Seasonal_Naive_7Day")

val_pred = validation["Lag_7"].values
test_pred = test["Lag_7"].values

val_metrics = calculate_metrics(
    y_val,
    val_pred
)

test_metrics = calculate_metrics(
    y_test,
    test_pred
)

validation_results.append({
    "Model": "Seasonal_Naive_7Day",
    **val_metrics
})

test_results.append({
    "Model": "Seasonal_Naive_7Day",
    **test_metrics
})

print(
    f"Validation RMSE: "
    f"{val_metrics['RMSE']:.4f}"
)

print(
    f"Test RMSE      : "
    f"{test_metrics['RMSE']:.4f}"
)


# =============================================================================
# 12. MACHINE LEARNING MODELS
# =============================================================================

print("\n" + "=" * 100)
print("MACHINE LEARNING BASELINES")
print("=" * 100)


for model_name, model in models.items():

    print("\n" + "-" * 100)
    print(f"MODEL: {model_name}")
    print("-" * 100)

    start_time = time.time()

    print("Training...")

    model.fit(
        X_train,
        y_train
    )

    training_time = (
        time.time()
        - start_time
    )

    print(
        f"Training time: "
        f"{training_time:.2f} sec"
    )

    # ------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------

    val_start = time.time()

    val_pred = model.predict(
        X_val
    )

    val_prediction_time = (
        time.time()
        - val_start
    )

    val_metrics = calculate_metrics(
        y_val,
        val_pred
    )

    validation_results.append({
        "Model": model_name,
        **val_metrics,
        "Training_Time_sec": training_time,
        "Validation_Prediction_Time_sec":
            val_prediction_time,
    })

    print(
        f"Validation MAE : "
        f"{val_metrics['MAE']:.4f}"
    )

    print(
        f"Validation RMSE: "
        f"{val_metrics['RMSE']:.4f}"
    )

    print(
        f"Validation R2  : "
        f"{val_metrics['R2']:.4f}"
    )

    print(
        f"Validation r   : "
        f"{val_metrics['Pearson_r']:.4f}"
    )


# =============================================================================
# 13. SAVE VALIDATION RESULTS
# =============================================================================

validation_df = pd.DataFrame(
    validation_results
)

validation_df = validation_df.sort_values(
    "RMSE"
).reset_index(drop=True)

validation_df.to_csv(
    OUTPUT_DIR / "validation_baseline_results.csv",
    index=False
)


# =============================================================================
# 14. SELECT BEST ML MODEL USING VALIDATION ONLY
# =============================================================================

ml_validation = validation_df[
    validation_df["Model"].isin(
        models.keys()
    )
].copy()

best_model_name = (
    ml_validation
    .sort_values("RMSE")
    .iloc[0]["Model"]
)

print("\n" + "=" * 100)
print("MODEL SELECTION")
print("=" * 100)

print(
    "Best ML model according to "
    "2024 validation RMSE:"
)

print(
    best_model_name
)


# =============================================================================
# 15. RETRAIN BEST MODEL ON TRAIN + VALIDATION
# =============================================================================

print("\n" + "=" * 100)
print("FINAL TRAINING")
print("=" * 100)

train_validation = pd.concat(
    [
        train,
        validation,
    ],
    axis=0,
    ignore_index=True
)

X_train_val = train_validation[
    FEATURES
].copy()

y_train_val = train_validation[
    TARGET
].copy()

best_model = models[
    best_model_name
]

print(
    f"Retraining {best_model_name} "
    f"on 2023 + 2024..."
)

final_start = time.time()

best_model.fit(
    X_train_val,
    y_train_val
)

final_training_time = (
    time.time()
    - final_start
)

print(
    f"Final training time: "
    f"{final_training_time:.2f} sec"
)


# =============================================================================
# 16. FINAL TEST EVALUATION
# =============================================================================

print("\n" + "=" * 100)
print("FINAL TEST EVALUATION")
print("=" * 100)

test_start = time.time()

final_test_pred = best_model.predict(
    X_test
)

test_prediction_time = (
    time.time()
    - test_start
)

final_test_metrics = calculate_metrics(
    y_test,
    final_test_pred
)

print(
    f"Model : {best_model_name}"
)

print(
    f"Test MAE : "
    f"{final_test_metrics['MAE']:.4f}"
)

print(
    f"Test RMSE: "
    f"{final_test_metrics['RMSE']:.4f}"
)

print(
    f"Test R2  : "
    f"{final_test_metrics['R2']:.4f}"
)

print(
    f"Test MAPE: "
    f"{final_test_metrics['MAPE_percent']:.4f}%"
)

print(
    f"Test SMAPE: "
    f"{final_test_metrics['SMAPE_percent']:.4f}%"
)

print(
    f"Test Pearson r: "
    f"{final_test_metrics['Pearson_r']:.4f}"
)


# =============================================================================
# 17. ALL MODEL TEST RESULTS
# =============================================================================

print("\n" + "=" * 100)
print("GENERATING TEST RESULTS FOR ALL BASELINES")
print("=" * 100)


# Naive models
all_test_results = []

all_test_results.append({
    "Model": "Naive_LastDay",
    **calculate_metrics(
        y_test,
        test["Lag_1"].values
    ),
})

all_test_results.append({
    "Model": "Seasonal_Naive_7Day",
    **calculate_metrics(
        y_test,
        test["Lag_7"].values
    ),
})


# ML models:
# Retrain each model using train + validation,
# then evaluate once on the untouched test set.

for model_name in models.keys():

    print(
        f"Final test evaluation: "
        f"{model_name}"
    )

    model = models[model_name]

    start = time.time()

    model.fit(
        X_train_val,
        y_train_val
    )

    pred = model.predict(
        X_test
    )

    elapsed = time.time() - start

    metrics = calculate_metrics(
        y_test,
        pred
    )

    all_test_results.append({
        "Model": model_name,
        **metrics,
        "TrainValidation_Time_sec":
            elapsed,
    })


test_results_df = pd.DataFrame(
    all_test_results
)

test_results_df = test_results_df.sort_values(
    "RMSE"
).reset_index(drop=True)

test_results_df.to_csv(
    OUTPUT_DIR / "test_baseline_results.csv",
    index=False
)


# =============================================================================
# 18. SAVE FINAL PREDICTIONS
# =============================================================================

prediction_output = test[
    [
        "TravelDate",
        "Station",
        TARGET,
    ]
].copy()

prediction_output[
    "Predicted_TotalFootfall"
] = final_test_pred

prediction_output[
    "Absolute_Error"
] = np.abs(
    prediction_output[TARGET]
    - prediction_output[
        "Predicted_TotalFootfall"
    ]
)

prediction_output[
    "Residual"
] = (
    prediction_output[
        TARGET
    ]
    - prediction_output[
        "Predicted_TotalFootfall"
    ]
)

prediction_output.to_csv(
    OUTPUT_DIR / "final_test_predictions.csv",
    index=False
)


# =============================================================================
# 19. FEATURE IMPORTANCE
# =============================================================================

print("\n" + "=" * 100)
print("FEATURE IMPORTANCE")
print("=" * 100)

# The selected model is a Pipeline.
# Extract the transformed feature names and model importance.

if best_model_name in [
    "RandomForest",
    "ExtraTrees",
    "GradientBoosting",
]:

    fitted_preprocessor = (
        best_model.named_steps[
            "preprocessor"
        ]
    )

    fitted_model = (
        best_model.named_steps[
            "model"
        ]
    )

    feature_names = (
        fitted_preprocessor
        .get_feature_names_out()
    )

    importances = (
        fitted_model.feature_importances_
    )

    importance_df = pd.DataFrame({
        "Feature": feature_names,
        "Importance": importances,
    })

    importance_df = (
        importance_df
        .sort_values(
            "Importance",
            ascending=False
        )
        .reset_index(drop=True)
    )

    importance_df.to_csv(
        OUTPUT_DIR / "feature_importance.csv",
        index=False
    )

    print(
        importance_df.head(30)
        .to_string(index=False)
    )

else:

    print(
        "Feature importance is not directly "
        "available for this model."
    )


# =============================================================================
# 20. MODEL COMPARISON TABLE
# =============================================================================

comparison_rows = []

for _, row in validation_df.iterrows():

    model_name = row["Model"]

    test_row = test_results_df[
        test_results_df["Model"]
        == model_name
    ]

    if len(test_row) == 1:

        test_row = test_row.iloc[0]

        comparison_rows.append({
            "Model": model_name,

            "Validation_MAE":
                row["MAE"],

            "Validation_RMSE":
                row["RMSE"],

            "Validation_R2":
                row["R2"],

            "Validation_Pearson_r":
                row["Pearson_r"],

            "Test_MAE":
                test_row["MAE"],

            "Test_RMSE":
                test_row["RMSE"],

            "Test_R2":
                test_row["R2"],

            "Test_Pearson_r":
                test_row["Pearson_r"],
        })


comparison_df = pd.DataFrame(
    comparison_rows
)

comparison_df = comparison_df.sort_values(
    "Validation_RMSE"
).reset_index(drop=True)

comparison_df.to_csv(
    OUTPUT_DIR / "baseline_comparison_table.csv",
    index=False
)


# =============================================================================
# 21. SAVE EXPERIMENT CONFIGURATION
# =============================================================================

configuration = pd.DataFrame({
    "Parameter": [
        "Dataset",
        "Target",
        "Train_period",
        "Validation_period",
        "Test_period",
        "Random_split",
        "Selection_metric",
        "Best_model",
        "Train_rows",
        "Validation_rows",
        "Test_rows",
        "Number_of_features",
        "Number_of_stations",
    ],

    "Value": [
        "TfL Station Footfall 2023-2026",
        TARGET,
        "2023",
        "2024",
        "2025-01-01 to 2026-07-04",
        "NO",
        "Validation RMSE",
        best_model_name,
        len(train),
        len(validation),
        len(test),
        len(FEATURES),
        train["Station"].nunique(),
    ]
})

configuration.to_csv(
    OUTPUT_DIR / "experiment_configuration.csv",
    index=False
)


# =============================================================================
# 22. PRINT FINAL TABLES
# =============================================================================

print("\n" + "#" * 100)
print("VALIDATION BASELINE RESULTS")
print("#" * 100)

print(
    validation_df[
        [
            "Model",
            "MAE",
            "RMSE",
            "R2",
            "MAPE_percent",
            "SMAPE_percent",
            "Pearson_r",
        ]
    ].to_string(index=False)
)


print("\n" + "#" * 100)
print("FINAL TEST BASELINE RESULTS")
print("#" * 100)

print(
    test_results_df[
        [
            "Model",
            "MAE",
            "RMSE",
            "R2",
            "MAPE_percent",
            "SMAPE_percent",
            "Pearson_r",
        ]
    ].to_string(index=False)
)


# =============================================================================
# 23. OUTPUT SUMMARY
# =============================================================================

print("\n" + "#" * 100)
print("BASELINE EXPERIMENT COMPLETED SUCCESSFULLY")
print("#" * 100)

print("\nOutput directory:")
print(OUTPUT_DIR)

print("\nGenerated files:")

print(
    "1. validation_baseline_results.csv"
)

print(
    "2. test_baseline_results.csv"
)

print(
    "3. baseline_comparison_table.csv"
)

print(
    "4. final_test_predictions.csv"
)

print(
    "5. feature_importance.csv"
)

print(
    "6. experiment_configuration.csv"
)

print("\nSelected model:")
print(best_model_name)

print("\nIMPORTANT:")
print(
    "The test set was kept untouched during "
    "model selection and hyperparameter decisions."
)

print("\nNEXT STEP:")
print(
    "Send the complete terminal output. "
    "Then we will analyze the baseline results "
    "and determine the next forecasting model/experiment."
)

