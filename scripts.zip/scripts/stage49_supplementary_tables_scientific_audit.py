from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# STAGE 49 — SUPPLEMENTARY TABLES SCIENTIFIC & NUMERICAL AUDIT
# ============================================================

ROOT = Path(__file__).resolve().parent

SUPP = ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE" / "05_Supplementary_Material"
TABLES = SUPP / "Tables"

MASTER = ROOT / "tfl_master_data"
BASELINE = ROOT / "tfl_baseline_results"
ADVANCED = ROOT / "tfl_advanced_results"
ABLATION = ROOT / "tfl_ablation_results_v3"
CALENDAR = ROOT / "tfl_calendar_ml"
VALIDATION = ROOT / "scientific_validation_results"

AUDIT_FILE = SUPP / "STAGE49_SUPPLEMENTARY_TABLES_SCIENTIFIC_AUDIT.csv"


def log(message=""):
    print(message)


def load_csv(path):
    if not path.exists():
        raise FileNotFoundError(str(path))
    return pd.read_csv(path)


def normalize(df):
    """
    Normalize dataframe for robust scientific comparison.
    Column order is preserved separately.
    """
    x = df.copy()

    # normalize column names
    x.columns = [str(c).strip() for c in x.columns]

    # normalize string values
    for c in x.columns:
        if x[c].dtype == "object":
            x[c] = x[c].astype(str).str.strip()

    return x


def compare_dataframes(source, generated, label):
    """
    Compare source and generated dataframes.
    Exact row/column structure and numerical values where applicable.
    """
    source = normalize(source)
    generated = normalize(generated)

    checks = []

    checks.append({
        "Check": f"{label} row_count",
        "Status": "PASS" if len(source) == len(generated) else "FAIL",
        "Detail": f"source={len(source)}, generated={len(generated)}"
    })

    checks.append({
        "Check": f"{label} column_count",
        "Status": "PASS" if len(source.columns) == len(generated.columns) else "FAIL",
        "Detail": f"source={len(source.columns)}, generated={len(generated.columns)}"
    })

    checks.append({
        "Check": f"{label} column_names",
        "Status": "PASS" if list(source.columns) == list(generated.columns)
                  else "FAIL",
        "Detail": f"source={list(source.columns)}, generated={list(generated.columns)}"
    })

    if list(source.columns) == list(generated.columns):
        try:
            pd.testing.assert_frame_equal(
                source.reset_index(drop=True),
                generated.reset_index(drop=True),
                check_dtype=False,
                check_exact=False,
                rtol=1e-10,
                atol=1e-10
            )

            checks.append({
                "Check": f"{label} values",
                "Status": "PASS",
                "Detail": "All rows and values match source within tolerance."
            })

        except AssertionError as e:
            checks.append({
                "Check": f"{label} values",
                "Status": "FAIL",
                "Detail": str(e)[:1000]
            })

    return checks


def check_no_nan_inf(df, label):
    result = []

    nan_count = int(df.isna().sum().sum())

    numeric = df.select_dtypes(include=[np.number])

    if numeric.shape[1] > 0:
        inf_count = int(np.isinf(numeric.to_numpy()).sum())
    else:
        inf_count = 0

    result.append({
        "Check": f"{label} NaN",
        "Status": "PASS" if nan_count == 0 else "WARNING",
        "Detail": f"NaN cells={nan_count}"
    })

    result.append({
        "Check": f"{label} Inf",
        "Status": "PASS" if inf_count == 0 else "FAIL",
        "Detail": f"Inf cells={inf_count}"
    })

    return result


def check_duplicates(df, label):
    duplicates = int(df.duplicated().sum())

    return [{
        "Check": f"{label} duplicate_rows",
        "Status": "PASS" if duplicates == 0 else "WARNING",
        "Detail": f"duplicate rows={duplicates}"
    }]


def audit_table(table_name, source_paths):
    """
    For one supplementary table, verify that the generated table
    contains the expected source information.

    If multiple source files feed one table, compare structural
    and row-level fingerprints rather than forcing identical frames.
    """
    generated_path = TABLES / table_name

    if not generated_path.exists():
        return [{
            "Check": table_name,
            "Status": "FAIL",
            "Detail": f"Generated table missing: {generated_path}"
        }]

    generated = load_csv(generated_path)

    results = []

    results += check_no_nan_inf(generated, table_name)
    results += check_duplicates(generated, table_name)

    results.append({
        "Check": f"{table_name} file_exists",
        "Status": "PASS",
        "Detail": str(generated_path)
    })

    results.append({
        "Check": f"{table_name} row_count",
        "Status": "PASS" if len(generated) > 0 else "FAIL",
        "Detail": f"rows={len(generated)}"
    })

    results.append({
        "Check": f"{table_name} column_count",
        "Status": "PASS" if len(generated.columns) > 0 else "FAIL",
        "Detail": f"columns={len(generated.columns)}"
    })

    # Source inventory
    for source in source_paths:
        results.append({
            "Check": f"{table_name} source_exists",
            "Status": "PASS" if source.exists() else "FAIL",
            "Detail": str(source)
        })

    return results


# ============================================================
# START
# ============================================================

log("=" * 100)
log("STAGE 49 — SUPPLEMENTARY TABLES SCIENTIFIC & NUMERICAL AUDIT")
log("=" * 100)

audit = []

# ------------------------------------------------------------
# 1. REQUIRED TABLE INVENTORY
# ------------------------------------------------------------

log("")
log("[1] SUPPLEMENTARY TABLE INVENTORY")
log("-" * 100)

required_tables = [
    "Table_S1_Descriptive_Statistics.csv",
    "Table_S2_Data_Quality.csv",
    "Table_S3_Model_Comparison.csv",
    "Table_S4_Final_Ablation.csv",
    "Table_S5_Feature_Importance.csv",
    "Table_S6_Validation_Results.csv",
    "Table_S7_Experiment_Configuration.csv",
    "Table_S8_Temporal_Validation.csv",
    "Table_S9_Prediction_Diagnostics.csv",
    "Table_S10_Split_Validation.csv",
]

for filename in required_tables:
    path = TABLES / filename

    status = "PASS" if path.exists() else "FAIL"

    log(f"{status} | {filename}")

    audit.append({
        "Check": f"Inventory | {filename}",
        "Status": status,
        "Detail": str(path)
    })


# ------------------------------------------------------------
# 2. TABLE STRUCTURE AUDIT
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[2] TABLE STRUCTURE AUDIT")
log("=" * 100)

expected_dimensions = {
    "Table_S1_Descriptive_Statistics.csv": (4, 6),
    "Table_S2_Data_Quality.csv": (30, 3),
    "Table_S3_Model_Comparison.csv": (10, 11),
    "Table_S4_Final_Ablation.csv": (7, 11),
    "Table_S5_Feature_Importance.csv": (10, 4),
    "Table_S6_Validation_Results.csv": (10, 10),
    "Table_S7_Experiment_Configuration.csv": (52, 5),
    "Table_S8_Temporal_Validation.csv": (8, 4),
    "Table_S9_Prediction_Diagnostics.csv": (21, 4),
    "Table_S10_Split_Validation.csv": (3, 4),
}

for filename, expected in expected_dimensions.items():

    path = TABLES / filename

    if not path.exists():
        continue

    df = load_csv(path)

    actual = (len(df), len(df.columns))

    status = "PASS" if actual == expected else "FAIL"

    log(
        f"{status} | {filename:45s} | "
        f"expected={expected} | actual={actual}"
    )

    audit.append({
        "Check": f"Structure | {filename}",
        "Status": status,
        "Detail": f"expected={expected}; actual={actual}"
    })


# ------------------------------------------------------------
# 3. SOURCE TABLE EXISTENCE AUDIT
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[3] SOURCE FILE EXISTENCE AUDIT")
log("=" * 100)

source_map = {

    "S1":
        MASTER / "year_summary.csv",

    "S2":
        MASTER / "missing_value_report.csv",

    "S3":
        [
            BASELINE / "baseline_comparison_table.csv",
            ADVANCED / "baseline_vs_advanced.csv",
            VALIDATION / "FINAL_MANUSCRIPT_MODEL_RESULTS.csv",
        ],

    "S4":
        ABLATION / "MANUSCRIPT_ABLATION_TABLE_V3.csv",

    "S5":
        VALIDATION / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv",

    "S6":
        [
            BASELINE / "validation_baseline_results.csv",
            ADVANCED / "advanced_validation_results.csv",
        ],

    "S7":
        [
            BASELINE / "experiment_configuration.csv",
            ADVANCED / "advanced_experiment_configuration.csv",
            CALENDAR / "feature_configuration.csv",
        ],

    "S8":
        CALENDAR / "calendar_lag_report.csv",

    "S9":
        ABLATION / "prediction_diagnostics_v3.csv",

    "S10":
        ABLATION / "split_summary_v3.csv",
}

for key, paths in source_map.items():

    if not isinstance(paths, list):
        paths = [paths]

    for source in paths:

        status = "PASS" if source.exists() else "FAIL"

        log(f"{status} | {key:4s} | {source}")

        audit.append({
            "Check": f"Source existence | {key}",
            "Status": status,
            "Detail": str(source)
        })


# ------------------------------------------------------------
# 4. DIRECT SOURCE → SUPPLEMENTARY COMPARISON
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[4] DIRECT SOURCE → SUPPLEMENTARY NUMERICAL AUDIT")
log("=" * 100)


direct_pairs = {
    "Table_S1_Descriptive_Statistics.csv":
        MASTER / "year_summary.csv",

    "Table_S2_Data_Quality.csv":
        MASTER / "missing_value_report.csv",

    "Table_S4_Final_Ablation.csv":
        ABLATION / "MANUSCRIPT_ABLATION_TABLE_V3.csv",

    "Table_S5_Feature_Importance.csv":
        VALIDATION / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv",

    "Table_S8_Temporal_Validation.csv":
        CALENDAR / "calendar_lag_report.csv",

    "Table_S9_Prediction_Diagnostics.csv":
        ABLATION / "prediction_diagnostics_v3.csv",

    "Table_S10_Split_Validation.csv":
        ABLATION / "split_summary_v3.csv",
}


for table_name, source_path in direct_pairs.items():

    if not source_path.exists():
        continue

    generated_path = TABLES / table_name

    if not generated_path.exists():
        continue

    source = load_csv(source_path)
    generated = load_csv(generated_path)

    checks = compare_dataframes(
        source,
        generated,
        table_name
    )

    audit.extend(checks)

    for c in checks:
        log(
            f"{c['Status']} | {c['Check']} | "
            f"{c['Detail'][:250]}"
        )


# ------------------------------------------------------------
# 5. FINAL ABLATION PRIORITY CHECK
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[5] FINAL ABLATION PRIORITY CHECK")
log("=" * 100)

s4 = TABLES / "Table_S4_Final_Ablation.csv"
authoritative = ABLATION / "MANUSCRIPT_ABLATION_TABLE_V3.csv"

if s4.exists() and authoritative.exists():

    s4_df = normalize(load_csv(s4))
    auth_df = normalize(load_csv(authoritative))

    identical = (
        s4_df.reset_index(drop=True)
        .equals(auth_df.reset_index(drop=True))
    )

    status = "PASS" if identical else "FAIL"

    log(
        f"{status} | S4 is identical to "
        f"MANUSCRIPT_ABLATION_TABLE_V3.csv"
    )

    audit.append({
        "Check": "S4 authoritative final ablation",
        "Status": status,
        "Detail": (
            "S4 exactly matches authoritative v3 manuscript ablation."
            if identical
            else
            "S4 differs from authoritative v3 manuscript ablation."
        )
    })


# ------------------------------------------------------------
# 6. FEATURE IMPORTANCE CHECK
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[6] FEATURE IMPORTANCE CHECK")
log("=" * 100)

s5_path = TABLES / "Table_S5_Feature_Importance.csv"

if s5_path.exists():

    s5 = load_csv(s5_path)

    feature_columns = [
        c for c in s5.columns
        if "feature" in c.lower() or "variable" in c.lower()
    ]

    importance_columns = [
        c for c in s5.columns
        if "importance" in c.lower()
    ]

    status = (
        "PASS"
        if len(feature_columns) >= 1 and len(importance_columns) >= 1
        else "FAIL"
    )

    log(
        f"{status} | Feature importance contains "
        f"feature + importance information"
    )

    audit.append({
        "Check": "S5 feature/importance fields",
        "Status": status,
        "Detail": (
            f"feature_columns={feature_columns}; "
            f"importance_columns={importance_columns}"
        )
    })


# ------------------------------------------------------------
# 7. NUMERIC SANITY CHECK
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[7] NUMERIC SANITY CHECK")
log("=" * 100)

for filename in required_tables:

    path = TABLES / filename

    if not path.exists():
        continue

    df = load_csv(path)

    numeric = df.select_dtypes(include=[np.number])

    if numeric.shape[1] == 0:
        status = "PASS"
        detail = "No numeric columns requiring range check."
    else:
        inf_count = int(np.isinf(numeric.to_numpy()).sum())
        nan_count = int(np.isnan(numeric.to_numpy()).sum())

        status = (
            "PASS"
            if inf_count == 0 and nan_count == 0
            else "FAIL"
        )

        detail = (
            f"numeric_columns={len(numeric.columns)}; "
            f"NaN={nan_count}; Inf={inf_count}"
        )

    log(f"{status} | {filename} | {detail}")

    audit.append({
        "Check": f"Numeric sanity | {filename}",
        "Status": status,
        "Detail": detail
    })


# ------------------------------------------------------------
# 8. LEGACY / DUPLICATE RISK CHECK
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[8] LEGACY / DUPLICATE RISK CHECK")
log("=" * 100)

# The final ablation must explicitly come from v3.
legacy_sources = [
    ABLATION / "ablation_results_v3.csv",
    ABLATION / "MANUSCRIPT_ABLATION_TABLE_V3.csv",
]

for path in legacy_sources:

    status = "PASS" if path.exists() else "FAIL"

    log(
        f"{status} | v3 ablation source | {path.name}"
    )

    audit.append({
        "Check": "Legacy control | v3 source",
        "Status": status,
        "Detail": str(path)
    })


# ------------------------------------------------------------
# 9. GLOBAL DUPLICATE CHECK
# ------------------------------------------------------------

log("")
log("=" * 100)
log("[9] GLOBAL DUPLICATE CHECK")
log("=" * 100)

for filename in required_tables:

    path = TABLES / filename

    if not path.exists():
        continue

    df = load_csv(path)

    duplicates = int(df.duplicated().sum())

    status = "PASS" if duplicates == 0 else "WARNING"

    log(
        f"{status} | {filename} | duplicate_rows={duplicates}"
    )

    audit.append({
        "Check": f"Duplicate rows | {filename}",
        "Status": status,
        "Detail": f"duplicate_rows={duplicates}"
    })


# ------------------------------------------------------------
# 10. FINAL STATUS
# ------------------------------------------------------------

audit_df = pd.DataFrame(audit)

AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
audit_df.to_csv(AUDIT_FILE, index=False)

fail_count = int((audit_df["Status"] == "FAIL").sum())
warning_count = int((audit_df["Status"] == "WARNING").sum())
pass_count = int((audit_df["Status"] == "PASS").sum())

log("")
log("=" * 100)
log("STAGE 49 FINAL STATUS")
log("=" * 100)

log(f"PASS    : {pass_count}")
log(f"WARNING : {warning_count}")
log(f"FAIL    : {fail_count}")
log("")
log(f"Audit saved:")
log(str(AUDIT_FILE))
log("")

if fail_count == 0:
    log("STAGE 49 — PASS")
    log("Supplementary Tables passed the scientific and numerical audit.")
else:
    log("STAGE 49 — FAIL")
    log("One or more Supplementary Tables require correction.")

log("=" * 100)