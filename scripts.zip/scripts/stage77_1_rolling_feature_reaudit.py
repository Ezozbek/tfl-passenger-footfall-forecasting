
from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

MASTER = (
    BASE / "tfl_master_data"
    / "TfL_StationFootfall_Master_2023_2026.csv"
)

DATA_DIR = BASE / "tfl_calendar_ml"
OUT_DIR = BASE / "tfl_stage77_audit"
OUT_DIR.mkdir(exist_ok=True)

FEATURES = [
    "RollingMean_7",
    "RollingStd_7",
    "RollingMean_14",
    "RollingMean_28",
]

SPLITS = [
    "train_2023.csv",
    "validation_2024.csv",
    "test_2025_2026.csv",
]

print("=" * 80)
print("STAGE 77.1 — ROLLING FEATURE RE-AUDIT")
print("=" * 80)

# Load the original, unfiltered master dataset.
master = pd.read_csv(
    MASTER,
    parse_dates=["TravelDate"],
    low_memory=False,
)

required = {"Station", "TravelDate", "TotalFootfall"}
if not required.issubset(master.columns):
    raise ValueError(
        f"Master dataset lacks columns: {required - set(master.columns)}"
    )

if master.duplicated(["Station", "TravelDate"]).any():
    raise ValueError("Duplicate Station-Date rows in original master.")

master = master.sort_values(
    ["Station", "TravelDate"]
).copy()

# Recalculate rolling features using the original full history.
parts = []

for station, group in master.groupby("Station", sort=False):
    group = group.sort_values("TravelDate").copy()
    series = group.set_index("TravelDate")["TotalFootfall"]

    previous = series.shift(1)

    rolling = pd.DataFrame(index=series.index)
    rolling["RollingMean_7"] = (
        previous.rolling("7D", min_periods=3).mean()
    )
    rolling["RollingStd_7"] = (
        previous.rolling("7D", min_periods=3).std()
    )
    rolling["RollingMean_14"] = (
        previous.rolling("14D", min_periods=5).mean()
    )
    rolling["RollingMean_28"] = (
        previous.rolling("28D", min_periods=7).mean()
    )

    rolling["Station"] = station
    rolling["TravelDate"] = rolling.index
    parts.append(rolling.reset_index(drop=True))

expected = pd.concat(parts, ignore_index=True)

# Compare original-history calculations with the saved ML splits.
results = []

for filename in SPLITS:
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(path)

    saved = pd.read_csv(
        path,
        parse_dates=["TravelDate"],
        low_memory=False,
    )

    merged = saved[
        ["Station", "TravelDate", *FEATURES]
    ].merge(
        expected,
        on=["Station", "TravelDate"],
        how="left",
        suffixes=("_saved", "_expected"),
        validate="one_to_one",
        indicator=True,
    )

    unmatched = int((merged["_merge"] != "both").sum())

    for feature in FEATURES:
        a = merged[f"{feature}_saved"]
        b = merged[f"{feature}_expected"]

        both_nan = a.isna() & b.isna()
        both_values = a.notna() & b.notna()

        errors = (a[both_values] - b[both_values]).abs()
        mismatches = int((errors > 1e-6).sum())

        null_disagreements = int(
            (a.isna() ^ b.isna()).sum()
        )

        results.append({
            "Split": filename,
            "Feature": feature,
            "Rows": len(merged),
            "Unmatched_Keys": unmatched,
            "Compared_NonNull": int(both_values.sum()),
            "Mismatches": mismatches,
            "Null_Disagreements": null_disagreements,
            "Max_Absolute_Error": (
                float(errors.max()) if len(errors) else None
            ),
            "Status": (
                "PASS"
                if unmatched == 0
                and mismatches == 0
                and null_disagreements == 0
                else "REVIEW"
            ),
        })

report = pd.DataFrame(results)
report.to_csv(
    OUT_DIR / "stage77_1_rolling_reaudit.csv",
    index=False,
)

print(report.to_string(index=False))

print("\nSaved report:")
print(OUT_DIR / "stage77_1_rolling_reaudit.csv")

if (report["Status"] == "PASS").all():
    print("\nRESULT: All rolling features match the original-history calculation.")
else:
    print("\nRESULT: Some features need investigation; inspect the CSV report.")
