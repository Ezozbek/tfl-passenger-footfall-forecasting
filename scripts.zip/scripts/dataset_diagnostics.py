from pathlib import Path
import pandas as pd
import numpy as np

# ============================================================
# PROJECT DIRECTORY
# ============================================================

BASE_DIR = Path(
    r"c:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
)

# ============================================================
# FILES
# ============================================================

FILES = {
    "NYC_TLC": BASE_DIR / "yellow_tripdata_2025-01.parquet",
    "NYC_ZONE_LOOKUP": BASE_DIR / "taxi_zone_lookup.csv",

    "TfL_Footfall_2023": BASE_DIR / "StationFootfall_2023.csv",
    "TfL_Footfall_2024": BASE_DIR / "StationFootfall_2024.csv",
    "TfL_Footfall_2025_2026": BASE_DIR / "stationfootfall-2025-2026.csv",
    "TfL_Journeys_2025_2026": BASE_DIR / "Journeys_2025_2026 .csv",
}

# ============================================================
# OUTPUT DIRECTORY
# ============================================================

OUTPUT_DIR = BASE_DIR / "dataset_diagnostics"
OUTPUT_DIR.mkdir(exist_ok=True)

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def memory_mb(df):
    return df.memory_usage(deep=True).sum() / (1024 ** 2)


def detect_datetime_columns(df):
    candidates = []

    for col in df.columns:
        name = str(col).lower()

        if any(x in name for x in [
            "date", "time", "timestamp", "datetime", "day"
        ]):
            candidates.append(col)

    return candidates


def print_dataframe_summary(name, df, file_path):

    print("\n" + "=" * 100)
    print(f"DATASET: {name}")
    print("=" * 100)

    print(f"File       : {file_path.name}")
    print(f"Path       : {file_path}")
    print(f"Rows       : {len(df):,}")
    print(f"Columns    : {len(df.columns):,}")
    print(f"Memory     : {memory_mb(df):,.2f} MB")

    print("\n--- COLUMNS ---")

    for i, col in enumerate(df.columns, start=1):
        print(f"{i:3}. {col}")

    print("\n--- DATA TYPES ---")
    print(df.dtypes.to_string())

    print("\n--- MISSING VALUES ---")

    missing = df.isna().sum()
    missing_pct = (missing / len(df) * 100).round(2)

    missing_table = pd.DataFrame({
        "Missing": missing,
        "Missing_%": missing_pct
    })

    missing_table = missing_table[
        missing_table["Missing"] > 0
    ].sort_values("Missing", ascending=False)

    if len(missing_table) == 0:
        print("No missing values.")
    else:
        print(missing_table.to_string())

    print("\n--- DUPLICATES ---")
    print(f"Duplicate rows: {df.duplicated().sum():,}")

    print("\n--- DATETIME-LIKE COLUMNS ---")

    datetime_candidates = detect_datetime_columns(df)

    if datetime_candidates:
        for col in datetime_candidates:
            print(f"- {col}")
    else:
        print("No obvious datetime column detected.")

    print("\n--- NUMERIC SUMMARY ---")

    numeric_cols = df.select_dtypes(
        include=np.number
    ).columns

    if len(numeric_cols) > 0:
        print(
            df[numeric_cols]
            .describe()
            .T
            .to_string()
        )
    else:
        print("No numeric columns.")

    print("\n--- SAMPLE ROWS ---")
    print(df.head(5).to_string())

    return missing_table


# ============================================================
# LOAD DATASETS
# ============================================================

all_results = []

for name, file_path in FILES.items():

    print("\n\n")
    print("#" * 100)
    print(f"LOADING: {name}")
    print("#" * 100)

    if not file_path.exists():
        print(f"WARNING: FILE NOT FOUND")
        print(file_path)
        continue

    try:

        if file_path.suffix.lower() == ".parquet":

            df = pd.read_parquet(file_path)

        elif file_path.suffix.lower() == ".csv":

            # Try UTF-8 first
            try:
                df = pd.read_csv(
                    file_path,
                    low_memory=False
                )

            except UnicodeDecodeError:

                df = pd.read_csv(
                    file_path,
                    encoding="latin1",
                    low_memory=False
                )

        else:
            print(f"Unsupported file type: {file_path.suffix}")
            continue

        missing_table = print_dataframe_summary(
            name,
            df,
            file_path
        )

        # Save missing-value report
        missing_output = OUTPUT_DIR / f"{name}_missing_values.csv"

        missing_table.to_csv(
            missing_output,
            encoding="utf-8"
        )

        # Save column information
        column_info = pd.DataFrame({
            "column": df.columns,
            "dtype": [
                str(dtype)
                for dtype in df.dtypes
            ],
            "missing": [
                df[col].isna().sum()
                for col in df.columns
            ],
            "missing_pct": [
                round(
                    df[col].isna().mean() * 100,
                    2
                )
                for col in df.columns
            ],
            "unique_values": [
                df[col].nunique(dropna=True)
                for col in df.columns
            ]
        })

        column_output = OUTPUT_DIR / f"{name}_columns.csv"

        column_info.to_csv(
            column_output,
            index=False,
            encoding="utf-8"
        )

        all_results.append({
            "Dataset": name,
            "File": file_path.name,
            "Rows": len(df),
            "Columns": len(df.columns),
            "Memory_MB": round(memory_mb(df), 2),
            "Duplicate_Rows": int(df.duplicated().sum()),
            "Total_Missing": int(df.isna().sum().sum()),
            "Missing_Cells_%": round(
                df.isna().sum().sum()
                / (len(df) * len(df.columns))
                * 100,
                2
            )
        })

        # Free memory
        del df

    except Exception as e:

        print("\nERROR:")
        print(type(e).__name__)
        print(str(e))


# ============================================================
# FINAL COMPARISON TABLE
# ============================================================

print("\n\n")
print("#" * 100)
print("FINAL DATASET COMPARISON")
print("#" * 100)

if all_results:

    comparison = pd.DataFrame(all_results)

    print(
        comparison.to_string(index=False)
    )

    comparison.to_csv(
        OUTPUT_DIR / "DATASET_COMPARISON.csv",
        index=False,
        encoding="utf-8"
    )

else:

    print("No datasets were successfully loaded.")


print("\n")
print("=" * 100)
print("DIAGNOSTICS COMPLETED")
print("=" * 100)

print(f"\nReports saved to:")
print(OUTPUT_DIR)