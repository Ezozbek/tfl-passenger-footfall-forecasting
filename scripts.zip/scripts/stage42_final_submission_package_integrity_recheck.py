from pathlib import Path
import hashlib
import zipfile
import csv
import re
from docx import Document


# =============================================================================
# STAGE 42 — FINAL SUBMISSION PACKAGE INTEGRITY RECHECK
# =============================================================================

BASE = Path(__file__).resolve().parent

PACKAGE_DIR = BASE / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

FINAL_ZIP = BASE / "FINAL_Q1_JOURNAL_SUBMISSION_PACKAGE_STAGE40.zip"

MANUSCRIPT = PACKAGE_DIR / "01_Final_Manuscript.docx"

FIGURE_DIR = PACKAGE_DIR / "03_High_Resolution_Figures"

SUPPLEMENTARY = (
    PACKAGE_DIR
    / "05_Supplementary_Material"
    / "Figure_2_3_Paired_Test_Predictions.csv"
)

REPORT = PACKAGE_DIR / "STAGE42_FINAL_SUBMISSION_PACKAGE_INTEGRITY_RECHECK.txt"


# =============================================================================
# EXPECTED SUBMISSION MEMBERS
# =============================================================================

EXPECTED_MEMBERS = [
    "01_Final_Manuscript.docx",
    "03_High_Resolution_Figures/Figure_1_Feature_Importance.png",
    "03_High_Resolution_Figures/Figure_2_Actual_vs_Predicted.png",
    "03_High_Resolution_Figures/Figure_3_Residual_Diagnostics.png",
    "03_High_Resolution_Figures/Figure_4_Model_Comparison.png",
    "05_Supplementary_Material/Figure_2_3_Paired_Test_Predictions.csv",
]


EXPECTED_FIGURES = {
    "Figure_1_Feature_Importance.png":
        FIGURE_DIR / "Figure_1_Feature_Importance.png",

    "Figure_2_Actual_vs_Predicted.png":
        FIGURE_DIR / "Figure_2_Actual_vs_Predicted.png",

    "Figure_3_Residual_Diagnostics.png":
        FIGURE_DIR / "Figure_3_Residual_Diagnostics.png",

    "Figure_4_Model_Comparison.png":
        FIGURE_DIR / "Figure_4_Model_Comparison.png",
}


# =============================================================================
# EXPECTED HASHES FROM STAGE 38B / STAGE 40
# =============================================================================

EXPECTED_DOCX_HASH = (
    "3383e042ab1fab8b7c7bce8c93eb4307b86ccf3ecf2ddb657a43447dd464245c"
)

EXPECTED_FIGURE_HASHES = {
    "Figure_1_Feature_Importance.png":
        "11abe4230f733037875b68607ad61c651a24ea20fd82f6c84c131ef7860face0",

    "Figure_2_Actual_vs_Predicted.png":
        "0ae61a8e18c4b54586b98b1b55e9c604a7e04947c3101f7b877d2418985e1805",

    "Figure_3_Residual_Diagnostics.png":
        "91c28f72a8ff02cf50a9afce295ac1b4301f6c31f791f072ea30dfc0523941be",

    "Figure_4_Model_Comparison.png":
        "42713001f8ade663e514d45edee38ba83100e87989824e07d63103c894fde57b",
}


# =============================================================================
# EXPECTED SCIENTIFIC VALUES
# =============================================================================

SCIENTIFIC_VALUES = [
    "516,819",
    "140,157",
    "151,509",
    "225,153",

    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",

    "1,490.7452",
    "4,087.0080",
    "0.979950",
    "0.989932",

    "20.0042%",
    "19.7594%",
    "16.0978%",

    "26.3903",
    "32.6876",
]


# =============================================================================
# HELPERS
# =============================================================================

passed = 0
failed = 0
notes = 0

report_lines = []


def add_line(text):
    print(text)
    report_lines.append(text)


def pass_check(message):
    global passed
    passed += 1
    add_line(f"PASS | {message}")


def fail_check(message):
    global failed
    failed += 1
    add_line(f"FAIL | {message}")


def note(message):
    global notes
    notes += 1
    add_line(f"NOTE | {message}")


def sha256_file(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()


def normalize(text):
    return (
        text
        .replace("−", "-")
        .replace("–", "-")
        .replace("—", "-")
    )


# =============================================================================
# HEADER
# =============================================================================

add_line("=" * 100)
add_line("STAGE 42 — FINAL SUBMISSION PACKAGE INTEGRITY RECHECK")
add_line("FINAL Q1 JOURNAL SUBMISSION PACKAGE / ZIP / DOCX / FIGURES / DATA")
add_line("=" * 100)


# =============================================================================
# 1. FINAL ZIP EXISTENCE
# =============================================================================

add_line("\n[1] FINAL ZIP")

if FINAL_ZIP.exists():
    pass_check("Final submission ZIP exists")

    add_line(f"Path: {FINAL_ZIP}")
    add_line(
        f"Size: {FINAL_ZIP.stat().st_size / (1024 * 1024):.2f} MB"
    )

    zip_hash = sha256_file(FINAL_ZIP)
    add_line(f"SHA256: {zip_hash}")

    expected_zip_hash = (
        "a5b982cf71270fe3e6db0361004cdab7bc146ce98f134ed4255987a1100aca40"
    )

    if zip_hash == expected_zip_hash:
        pass_check("Final ZIP SHA256 matches Stage 40")
    else:
        fail_check(
            "Final ZIP SHA256 differs from Stage 40 expected hash"
        )

else:
    fail_check("Final submission ZIP does not exist")
    raise SystemExit(1)


# =============================================================================
# 2. ZIP INTEGRITY
# =============================================================================

add_line("\n[2] ZIP INTEGRITY")

try:
    with zipfile.ZipFile(FINAL_ZIP, "r") as z:
        bad_file = z.testzip()

        if bad_file is None:
            pass_check("ZIP integrity check passed")
        else:
            fail_check(
                f"Corrupted ZIP member detected: {bad_file}"
            )

        members = z.namelist()

except Exception as exc:
    fail_check(f"Could not open ZIP: {exc}")
    raise SystemExit(1)


# =============================================================================
# 3. ZIP MEMBER COUNT
# =============================================================================

add_line("\n[3] ZIP CONTENT")

add_line(f"ZIP members: {len(members)}")

if len(members) == len(EXPECTED_MEMBERS):
    pass_check("ZIP contains exactly 6 submission members")
else:
    fail_check(
        f"Expected 6 ZIP members, found {len(members)}"
    )


# =============================================================================
# 4. REQUIRED MEMBERS
# =============================================================================

add_line("\n[4] REQUIRED SUBMISSION FILES")

for expected in EXPECTED_MEMBERS:
    if expected in members:
        pass_check(f"Present: {expected}")
    else:
        fail_check(f"Missing: {expected}")


# =============================================================================
# 5. UNEXPECTED MEMBERS
# =============================================================================

add_line("\n[5] UNEXPECTED ZIP CONTENT")

unexpected = [
    member
    for member in members
    if member not in EXPECTED_MEMBERS
]

if not unexpected:
    pass_check("No unexpected files in final submission ZIP")
else:
    for item in unexpected:
        fail_check(f"Unexpected ZIP member: {item}")


# =============================================================================
# 6. PDF EXCLUSION
# =============================================================================

add_line("\n[6] PDF EXCLUSION")

pdf_members = [
    member
    for member in members
    if member.lower().endswith(".pdf")
]

if not pdf_members:
    pass_check("No PDF files included")
else:
    fail_check(
        "PDF file(s) detected: "
        + ", ".join(pdf_members)
    )


# =============================================================================
# 7. DOCX HASH
# =============================================================================

add_line("\n[7] MANUSCRIPT DOCX HASH")

if MANUSCRIPT.exists():
    docx_hash = sha256_file(MANUSCRIPT)

    add_line(f"Local DOCX SHA256: {docx_hash}")

    if docx_hash == EXPECTED_DOCX_HASH:
        pass_check("Local manuscript DOCX hash matches Stage 40")
    else:
        fail_check(
            "Local manuscript DOCX hash differs from Stage 40"
        )
else:
    fail_check("Local manuscript DOCX not found")


# =============================================================================
# 8. DOCX HASH INSIDE ZIP
# =============================================================================

add_line("\n[8] ZIP DOCX HASH")

with zipfile.ZipFile(FINAL_ZIP, "r") as z:
    zip_docx_data = z.read("01_Final_Manuscript.docx")

zip_docx_hash = hashlib.sha256(zip_docx_data).hexdigest()

add_line(f"ZIP DOCX SHA256: {zip_docx_hash}")

if zip_docx_hash == EXPECTED_DOCX_HASH:
    pass_check("ZIP manuscript hash matches Stage 40")
else:
    fail_check("ZIP manuscript hash mismatch")


# =============================================================================
# 9. LOCAL DOCX == ZIP DOCX
# =============================================================================

add_line("\n[9] LOCAL / ZIP DOCX CONSISTENCY")

if MANUSCRIPT.exists():
    if docx_hash == zip_docx_hash:
        pass_check("Local DOCX and ZIP DOCX are identical")
    else:
        fail_check("Local DOCX and ZIP DOCX differ")


# =============================================================================
# 10. FIGURE HASHES
# =============================================================================

add_line("\n[10] FIGURE HASHES")

for figure_name, figure_path in EXPECTED_FIGURES.items():

    if not figure_path.exists():
        fail_check(f"Missing local figure: {figure_name}")
        continue

    actual_hash = sha256_file(figure_path)

    expected_hash = EXPECTED_FIGURE_HASHES[figure_name]

    add_line(f"{figure_name}")
    add_line(f"  Actual  : {actual_hash}")
    add_line(f"  Expected: {expected_hash}")

    if actual_hash == expected_hash:
        pass_check(f"Figure hash matches: {figure_name}")
    else:
        fail_check(f"Figure hash mismatch: {figure_name}")


# =============================================================================
# 11. FIGURE HASHES INSIDE ZIP
# =============================================================================

add_line("\n[11] ZIP FIGURE HASHES")

with zipfile.ZipFile(FINAL_ZIP, "r") as z:

    for figure_name, expected_hash in EXPECTED_FIGURE_HASHES.items():

        zip_path = (
            "03_High_Resolution_Figures/"
            + figure_name
        )

        if zip_path not in members:
            fail_check(
                f"Figure missing from ZIP: {figure_name}"
            )
            continue

        data = z.read(zip_path)
        actual_hash = hashlib.sha256(data).hexdigest()

        if actual_hash == expected_hash:
            pass_check(
                f"ZIP figure hash matches: {figure_name}"
            )
        else:
            fail_check(
                f"ZIP figure hash mismatch: {figure_name}"
            )


# =============================================================================
# 12. FIGURE LOCAL == ZIP
# =============================================================================

add_line("\n[12] LOCAL / ZIP FIGURE CONSISTENCY")

with zipfile.ZipFile(FINAL_ZIP, "r") as z:

    for figure_name, figure_path in EXPECTED_FIGURES.items():

        if not figure_path.exists():
            continue

        zip_path = (
            "03_High_Resolution_Figures/"
            + figure_name
        )

        if zip_path not in members:
            continue

        local_hash = sha256_file(figure_path)
        zip_hash_figure = hashlib.sha256(
            z.read(zip_path)
        ).hexdigest()

        if local_hash == zip_hash_figure:
            pass_check(
                f"Local/ZIP figure identical: {figure_name}"
            )
        else:
            fail_check(
                f"Local/ZIP figure mismatch: {figure_name}"
            )


# =============================================================================
# 13. SUPPLEMENTARY CSV
# =============================================================================

add_line("\n[13] SUPPLEMENTARY CSV")

if SUPPLEMENTARY.exists():

    pass_check("Supplementary CSV exists")

    try:

        with open(
            SUPPLEMENTARY,
            "r",
            encoding="utf-8-sig",
            newline=""
        ) as f:

            reader = csv.reader(f)

            rows = list(reader)

        if rows:
            header = rows[0]
            data_rows = rows[1:]

            add_line(
                f"Local CSV rows: {len(data_rows):,}"
            )
            add_line(
                f"Local CSV columns: {len(header)}"
            )

            if len(data_rows) == 225153:
                pass_check(
                    "Supplementary CSV row count = 225,153"
                )
            else:
                fail_check(
                    "Supplementary CSV row count differs "
                    f"from 225,153: {len(data_rows)}"
                )

            if len(header) == 6:
                pass_check(
                    "Supplementary CSV column count = 6"
                )
            else:
                fail_check(
                    f"Supplementary CSV column count = "
                    f"{len(header)}"
                )

    except Exception as exc:
        fail_check(
            f"Could not read supplementary CSV: {exc}"
        )

else:
    fail_check("Supplementary CSV does not exist")


# =============================================================================
# 14. SUPPLEMENTARY CSV INSIDE ZIP
# =============================================================================

add_line("\n[14] ZIP SUPPLEMENTARY CSV")

zip_csv_path = (
    "05_Supplementary_Material/"
    "Figure_2_3_Paired_Test_Predictions.csv"
)

with zipfile.ZipFile(FINAL_ZIP, "r") as z:

    if zip_csv_path in members:

        pass_check("Supplementary CSV present in ZIP")

        csv_bytes = z.read(zip_csv_path)

        try:

            csv_text = csv_bytes.decode(
                "utf-8-sig"
            )

            csv_lines = csv_text.splitlines()

            add_line(
                f"ZIP CSV lines: {len(csv_lines):,}"
            )

            if len(csv_lines) == 225154:
                pass_check(
                    "ZIP supplementary CSV contains "
                    "225,153 data rows + header"
                )
            else:
                fail_check(
                    "ZIP supplementary CSV line count differs "
                    f"from 225,154: {len(csv_lines)}"
                )

        except Exception as exc:
            fail_check(
                f"Could not decode ZIP supplementary CSV: {exc}"
            )

    else:
        fail_check(
            "Supplementary CSV missing from ZIP"
        )


# =============================================================================
# 15. MANUSCRIPT SCIENTIFIC VALUES
# =============================================================================

add_line("\n[15] MANUSCRIPT SCIENTIFIC VALUES")

try:

    doc = Document(MANUSCRIPT)

    text_parts = [
        p.text
        for p in doc.paragraphs
    ]

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                text_parts.append(cell.text)

    manuscript_text = normalize(
        "\n".join(text_parts)
    )

    for value in SCIENTIFIC_VALUES:

        if value in manuscript_text:
            pass_check(
                f"Scientific value detected: {value}"
            )
        else:
            fail_check(
                f"Scientific value missing: {value}"
            )

except Exception as exc:
    fail_check(
        f"Could not inspect manuscript scientific values: {exc}"
    )


# =============================================================================
# 16. RESIDUAL DEFINITION
# =============================================================================

add_line("\n[16] RESIDUAL DEFINITION")

residual_patterns = [
    r"Actual\s*-\s*Predicted",
    r"Residual\s*definition\s*:\s*Actual\s*-\s*Predicted",
    r"e[_\s]?i\s*=\s*y[_\s]?i\s*-\s*y[_\s]?hat[_\s]?i",
]

residual_found = any(
    re.search(
        pattern,
        manuscript_text,
        flags=re.IGNORECASE | re.DOTALL
    )
    for pattern in residual_patterns
)

if residual_found:
    pass_check(
        "Residual definition is present and valid"
    )
else:
    fail_check(
        "Residual definition not detected"
    )


# =============================================================================
# 17. MANUSCRIPT FIGURE OBJECT COUNT
# =============================================================================

add_line("\n[17] MANUSCRIPT EMBEDDED MEDIA")

try:

    with zipfile.ZipFile(MANUSCRIPT, "r") as z:

        media = [
            name
            for name in z.namelist()
            if name.startswith("word/media/")
        ]

    add_line(
        f"Embedded media files: {len(media)}"
    )

    if len(media) == 4:
        pass_check(
            "Manuscript contains exactly 4 embedded figures"
        )
    elif len(media) > 4:
        note(
            f"Manuscript contains {len(media)} embedded media files"
        )
    else:
        fail_check(
            "Manuscript contains fewer than 4 embedded figures"
        )

except Exception as exc:
    fail_check(
        f"Could not inspect manuscript media: {exc}"
    )


# =============================================================================
# 18. MANUSCRIPT STRUCTURE
# =============================================================================

add_line("\n[18] MANUSCRIPT STRUCTURE")

section_checks = [
    "1. Introduction",
    "2. Related Work",
    "3. Proposed Forecasting Framework",
    "4. Mathematical Model",
    "5. Forecasting Algorithm",
    "6. Experimental Setup",
    "7. Results and Comparative Analysis",
    "8. Feature Ablation and Robustness Analysis",
    "9. Discussion",
    "10. Conclusion and Future Work",
]

for section in section_checks:

    if section.lower() in manuscript_text.lower():
        pass_check(
            f"Section present: {section}"
        )
    else:
        fail_check(
            f"Section missing: {section}"
        )


# =============================================================================
# 19. INTERNAL FILE / PDF / AUDIT CONTAMINATION
# =============================================================================

add_line("\n[19] FINAL ZIP CLEANLINESS")

contamination_terms = [
    "backup",
    "stage38",
    "stage39",
    "stage40",
    "stage41",
    "stage42",
    ".py",
    ".txt",
    ".log",
    ".pdf",
]

contaminated = []

for member in members:

    lower = member.lower()

    if any(term in lower for term in contamination_terms):
        contaminated.append(member)

if not contaminated:
    pass_check(
        "No internal audit, backup, script, log, TXT, or PDF files detected"
    )
else:
    for item in contaminated:
        fail_check(
            f"Potential submission contamination: {item}"
        )


# =============================================================================
# 20. FINAL PACKAGE MEMBER LIST
# =============================================================================

add_line("\n[20] FINAL PACKAGE MEMBER LIST")

for member in members:
    add_line(f"  {member}")


# =============================================================================
# FINAL SUMMARY
# =============================================================================

add_line("\n" + "=" * 100)
add_line("STAGE 42 FINAL RESULT")
add_line("=" * 100)

add_line(f"PASS CHECKS: {passed}")
add_line(f"FAIL CHECKS: {failed}")
add_line(f"NOTES: {notes}")

if failed == 0:
    status = "PASS"
else:
    status = "FAIL"

add_line(f"STATUS: {status}")

add_line("\nREPORT:")
add_line(str(REPORT))

REPORT.write_text(
    "\n".join(report_lines),
    encoding="utf-8"
)

add_line("=" * 100)

if failed > 0:
    raise SystemExit(1)