# -*- coding: utf-8 -*-

"""
Stage 38B — DOCX-only Final Audit

Purpose
-------
Final audit of the Q1 manuscript submission package using DOCX only.

This stage:
1. Validates the final package and required files.
2. Creates a backup of the current DOCX.
3. Replaces Figures 1–4 in the DOCX with verified high-resolution figures.
4. Validates embedded DOCX figures.
5. Audits the DOCX text for legacy/obsolete values.
6. Audits the DOCX text for verified experimental values.
7. Audits Figure 1–4 files.
8. Generates a final package manifest.
9. Creates a DOCX-only final ZIP package.
10. Writes a complete Stage 38B audit report.

IMPORTANT
---------
PDF generation is intentionally NOT performed.
PDF existence is NOT required.
PDF audit is NOT performed.
PDF is excluded from the final Stage 38B ZIP package.
"""

from pathlib import Path
import shutil
import sys
import re
import zipfile
import csv
import hashlib

from docx import Document
from docx.shared import Inches


# ============================================================================
# 0. PATH CONFIGURATION
# ============================================================================

ROOT = Path(__file__).resolve().parent

PACKAGE = ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

DOCX = PACKAGE / "01_Final_Manuscript.docx"

FIGDIR = PACKAGE / "03_High_Resolution_Figures"

BACKUP = PACKAGE / "_Stage38B_Backup"

ZIPOUT = ROOT / "FINAL_Q1_SUBMISSION_PACKAGE_STAGE38B_DOCX_ONLY.zip"

MANIFEST = PACKAGE / "STAGE38B_DOCX_ONLY_PACKAGE_MANIFEST.csv"

AUDIT = PACKAGE / "STAGE38B_DOCX_ONLY_FINAL_AUDIT.txt"


# ============================================================================
# 1. FIGURE DEFINITIONS
# ============================================================================

FIGURES = {
    1: FIGDIR / "Figure_1_Feature_Importance.png",
    2: FIGDIR / "Figure_2_Actual_vs_Predicted.png",
    3: FIGDIR / "Figure_3_Residual_Diagnostics.png",
    4: FIGDIR / "Figure_4_Model_Comparison.png",
}


# ============================================================================
# 2. LEGACY / OBSOLETE VALUES
# ============================================================================

LEGACY = [
    "61.998",
    "61.998%",
    "-5.48",
    "mean bias = -5.48",
]


# ============================================================================
# 3. VERIFIED FINAL EXPERIMENTAL VALUES
# ============================================================================

REQUIRED = [
    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",
    "1,490.7452",
    "4,087.0080",
    "0.979950",
    "0.989932",
    "20.0042%",
    "19.7594%",
    "16.0978%",
]


# ============================================================================
# 4. ADDITIONAL REQUIRED MANUSCRIPT VALUES
# ============================================================================

# ============================================================================
# 5. REQUIRED PACKAGE CONTENT
# ============================================================================

REQUIRED_PACKAGE_FILES = [
    "01_Final_Manuscript.docx",

    "03_High_Resolution_Figures/Figure_1_Feature_Importance.png",
    "03_High_Resolution_Figures/Figure_2_Actual_vs_Predicted.png",
    "03_High_Resolution_Figures/Figure_3_Residual_Diagnostics.png",
    "03_High_Resolution_Figures/Figure_4_Model_Comparison.png",

    "05_Supplementary_Material/Figure_2_3_Paired_Test_Predictions.csv",
]


# ============================================================================
# 6. HELPERS
# ============================================================================

def h(title):
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


def fail(message):
    print()
    print("=" * 100)
    print("STAGE 38B — FAIL")
    print("=" * 100)
    print(message)
    sys.exit(1)


def norm(text):
    return re.sub(r"\s+", " ", str(text).strip().lower())


def sha256_file(path):
    hsh = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hsh.update(chunk)

    return hsh.hexdigest()


# ============================================================================
# 7. INPUT VALIDATION
# ============================================================================

def check_inputs():

    h("1. INPUT VALIDATION")

    if not PACKAGE.exists():
        fail(f"Package not found:\n{PACKAGE}")

    if not DOCX.exists():
        fail(f"Final DOCX not found:\n{DOCX}")

    if DOCX.stat().st_size < 10000:
        fail(
            f"Final DOCX is suspiciously small:\n"
            f"{DOCX}\n"
            f"Size: {DOCX.stat().st_size} bytes"
        )

    print(
        f"PASS | DOCX | "
        f"{DOCX.stat().st_size / 1024 / 1024:.2f} MB"
    )

    if not FIGDIR.exists():
        fail(f"Figure directory not found:\n{FIGDIR}")

    for number, path in FIGURES.items():

        if not path.exists():
            fail(
                f"Missing Figure {number}:\n"
                f"{path}"
            )

        if path.stat().st_size < 1000:
            fail(
                f"Figure {number} is suspiciously small:\n"
                f"{path}"
            )

        print(
            f"PASS | Figure {number} | "
            f"{path.name} | "
            f"{path.stat().st_size / 1024:.1f} KB"
        )


# ============================================================================
# 8. BACKUP
# ============================================================================

def backup():

    h("2. BACKUP CURRENT DOCX")

    BACKUP.mkdir(exist_ok=True)

    output = (
        BACKUP /
        "01_Final_Manuscript_STAGE38B_BACKUP.docx"
    )

    shutil.copy2(DOCX, output)

    print(f"Backup created:")
    print(output)

    print(
        f"Backup size: "
        f"{output.stat().st_size / 1024 / 1024:.2f} MB"
    )


# ============================================================================
# 9. DOCX IMAGE HELPERS
# ============================================================================

def paragraph_has_drawing(paragraph):

    return bool(
        paragraph._p.xpath(".//w:drawing")
    )


def replace_image_blob_in_paragraph(
    paragraph,
    new_image
):

    """
    Replace the image bytes of the first embedded image
    in the specified paragraph while preserving its
    existing DOCX layout and dimensions.
    """

    drawings = paragraph._p.xpath(
        ".//w:drawing"
    )

    if not drawings:
        return False

    blips = drawings[0].xpath(
        ".//a:blip"
    )

    if not blips:
        return False

    rid = blips[0].get(
        "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
        "embed"
    )

    if not rid:
        return False

    rel = paragraph.part.rels[rid]

    if not hasattr(rel, "target_part"):
        return False

    target = rel.target_part

    if not hasattr(target, "_blob"):
        return False

    target._blob = new_image.read_bytes()

    return True


# ============================================================================
# 10. FIND FIGURE CAPTION
# ============================================================================

def find_caption(paragraphs, number):

    patterns = [
        f"figure {number}",
        f"fig. {number}",
        f"fig {number}",
    ]

    for index, paragraph in enumerate(paragraphs):

        text = norm(paragraph.text)

        if any(
            text.startswith(pattern)
            for pattern in patterns
        ):
            return index

    return None


# ============================================================================
# 11. REPLACE FIGURES 1–4
# ============================================================================

def replace_figures():

    h("3. FINAL DOCX FIGURE 1–4 REPLACEMENT")

    doc = Document(DOCX)

    paragraphs = list(doc.paragraphs)

    completed = {}

    for number, image_path in FIGURES.items():

        caption_index = find_caption(
            paragraphs,
            number
        )

        if caption_index is None:

            fail(
                f"Figure {number} caption was not found "
                f"in DOCX top-level paragraphs."
            )

        candidates = []

        for j in range(
            max(0, caption_index - 4),
            caption_index
        ):

            if paragraph_has_drawing(
                paragraphs[j]
            ):
                candidates.append(
                    paragraphs[j]
                )

        if candidates:

            target = candidates[-1]

            replaced = replace_image_blob_in_paragraph(
                target,
                image_path
            )

            if not replaced:

                fail(
                    f"Could not replace image blob "
                    f"for Figure {number}."
                )

            completed[number] = (
                "existing embedded image replaced"
            )

        else:

            # Fallback:
            # Insert a new figure immediately before
            # the figure caption.

            caption = paragraphs[caption_index]

            new_paragraph = (
                caption.insert_paragraph_before()
            )

            new_paragraph.alignment = 1

            new_paragraph.add_run().add_picture(
                str(image_path),
                width=Inches(6.4)
            )

            completed[number] = (
                "new image inserted before caption"
            )

    doc.save(DOCX)

    for number in range(1, 5):

        print(
            f"Figure {number}: "
            f"{completed.get(number)}"
        )


# ============================================================================
# 12. COUNT EMBEDDED DOCX FIGURES
# ============================================================================

def count_images():

    h("4. DOCX EMBEDDED IMAGE VALIDATION")

    doc = Document(DOCX)

    count = 0

    # Top-level paragraphs
    for paragraph in doc.paragraphs:

        if paragraph_has_drawing(
            paragraph
        ):
            count += 1

    # Table paragraphs
    for table in doc.tables:

        for row in table.rows:

            for cell in row.cells:

                for paragraph in cell.paragraphs:

                    if paragraph_has_drawing(
                        paragraph
                    ):
                        count += 1

    print(
        f"Paragraphs containing drawings: {count}"
    )

    if count < 4:

        fail(
            "Fewer than four figure-bearing "
            "paragraphs were found in the DOCX."
        )

    print(
        "DOCX embedded figure count: PASS"
    )


# ============================================================================
# 13. EXTRACT COMPLETE DOCX TEXT
# ============================================================================

def docx_text():

    doc = Document(DOCX)

    chunks = []

    # Main document paragraphs
    for paragraph in doc.paragraphs:

        if paragraph.text.strip():

            chunks.append(
                paragraph.text
            )

    # Tables
    for table in doc.tables:

        for row in table.rows:

            chunks.append(
                " | ".join(
                    cell.text
                    for cell in row.cells
                )
            )

    return "\n".join(chunks)


# ============================================================================
# 14. DOCX TEXT AUDIT
# ============================================================================

def audit_docx_text():

    h("5. FINAL DOCX TEXT AUDIT")

    text = norm(docx_text())

    # ------------------------------------------------------------------------
    # Legacy values
    # ------------------------------------------------------------------------

    legacy_found = []

    for value in LEGACY:

        if norm(value) in text:

            legacy_found.append(value)

    if legacy_found:

        fail(
            "Legacy/obsolete values found in DOCX:\n"
            + "\n".join(
                f" - {value}"
                for value in legacy_found
            )
        )

    print(
        "Legacy / obsolete values: NONE"
    )

    # ------------------------------------------------------------------------
    # Verified experimental values
    # ------------------------------------------------------------------------

    missing_verified = []

    for value in REQUIRED:

        if norm(value) not in text:

            missing_verified.append(value)

    if missing_verified:

        fail(
            "Verified experimental values missing "
            "from DOCX:\n"
            + "\n".join(
                f" - {value}"
                for value in missing_verified
            )
        )

    print(
        "Verified experimental values: PASS"
    )

    # ------------------------------------------------------------------------
    # Figure references
    # ------------------------------------------------------------------------

    for number in range(1, 5):

        pattern = (
            rf"\bfigure\s*{number}\b"
        )

        if not re.search(
            pattern,
            text
        ):

            fail(
                f"Figure {number} reference "
                f"is missing from DOCX."
            )

    print(
        "Figure 1–4 textual references: PASS"
    )


# ============================================================================
# 15. FIGURE FILE AUDIT
# ============================================================================

def audit_figures():

    h("6. FINAL FIGURE FILE AUDIT")

    for number, path in FIGURES.items():

        if not path.exists():

            fail(
                f"Figure {number} is missing:\n"
                f"{path}"
            )

        size = path.stat().st_size

        if size < 1000:

            fail(
                f"Figure {number} is suspiciously small:\n"
                f"{path}"
            )

        digest = sha256_file(path)

        print(
            f"PASS | Figure {number}\n"
            f"      File   : {path.name}\n"
            f"      Size   : {size / 1024:.1f} KB\n"
            f"      SHA256 : {digest}"
        )


# ============================================================================
# 16. VERIFY DOCX FIGURES EXIST AFTER REPLACEMENT
# ============================================================================

def verify_docx_figures():

    h("7. FINAL DOCX FIGURE EMBEDDING AUDIT")

    doc = Document(DOCX)

    paragraphs = list(doc.paragraphs)

    for number in range(1, 5):

        caption_index = find_caption(
            paragraphs,
            number
        )

        if caption_index is None:

            fail(
                f"Figure {number} caption missing "
                f"after final replacement."
            )

        found_drawing = False

        for j in range(
            max(0, caption_index - 4),
            caption_index
        ):

            if paragraph_has_drawing(
                paragraphs[j]
            ):

                found_drawing = True
                break

        if not found_drawing:

            fail(
                f"No embedded drawing found near "
                f"Figure {number} caption."
            )

        print(
            f"PASS | Figure {number} | "
            f"embedded drawing detected"
        )


# ============================================================================
# 17. PACKAGE MANIFEST
# ============================================================================

def manifest():

    h("8. DOCX-ONLY PACKAGE MANIFEST")

    files = []

    for path in PACKAGE.rglob("*"):

        if not path.is_file():
            continue

        relative = path.relative_to(
            PACKAGE
        )

        relative_string = str(
            relative
        )

        # Exclude Stage 38B internal backup
        if relative_string.startswith(
            "_Stage38B_Backup"
        ):
            continue

        # Exclude any stale PDF from the DOCX-only package
        if path.suffix.lower() == ".pdf":
            continue

        files.append(relative)

    with MANIFEST.open(
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        writer.writerow([
            "relative_path",
            "size_bytes",
            "size_kb",
            "sha256",
        ])

        for relative in sorted(files):

            path = PACKAGE / relative

            size = path.stat().st_size

            writer.writerow([
                str(relative),
                size,
                round(size / 1024, 2),
                sha256_file(path),
            ])

    missing = []

    for required in REQUIRED_PACKAGE_FILES:

        required_path = (
            PACKAGE / required
        )

        if not required_path.exists():

            missing.append(required)

    if missing:

        fail(
            "Required package files missing:\n"
            + "\n".join(
                f" - {x}"
                for x in missing
            )
        )

    print(
        f"Package files audited: {len(files)}"
    )

    print(
        "Required DOCX-only package content: PASS"
    )


# ============================================================================
# 18. CHECK FOR STALE PDF
# ============================================================================

def audit_no_pdf_requirement():

    h("9. DOCX-ONLY FORMAT AUDIT")

    pdf_files = list(
        PACKAGE.rglob("*.pdf")
    )

    if pdf_files:

        print(
            "NOTE: PDF file(s) exist in the source "
            "package, but they are intentionally "
            "excluded from Stage 38B."
        )

        for pdf in pdf_files:

            print(
                f"EXCLUDED | {pdf.relative_to(PACKAGE)}"
            )

    else:

        print(
            "No PDF files detected."
        )

    print(
        "PDF generation requirement: DISABLED"
    )

    print(
        "PDF audit requirement: DISABLED"
    )

    print(
        "DOCX-only final format: PASS"
    )


# ============================================================================
# 19. FINAL DOCX VALIDATION
# ============================================================================

def final_docx_validation():

    h("10. FINAL DOCX FILE VALIDATION")

    if not DOCX.exists():

        fail(
            f"Final DOCX does not exist:\n"
            f"{DOCX}"
        )

    size = DOCX.stat().st_size

    if size < 10000:

        fail(
            f"Final DOCX is suspiciously small:\n"
            f"{size} bytes"
        )

    digest = sha256_file(DOCX)

    # Open DOCX again to verify structural integrity.
    try:

        doc = Document(DOCX)

        paragraph_count = len(
            doc.paragraphs
        )

        table_count = len(
            doc.tables
        )

    except Exception as exc:

        fail(
            "Final DOCX could not be opened "
            "successfully.\n"
            f"Error: {exc}"
        )

    print(
        f"DOCX size       : {size / 1024 / 1024:.2f} MB"
    )

    print(
        f"DOCX paragraphs : {paragraph_count}"
    )

    print(
        f"DOCX tables     : {table_count}"
    )

    print(
        f"DOCX SHA256     : {digest}"
    )

    print(
        "DOCX structural integrity: PASS"
    )


# ============================================================================
# 20. FINAL DOCX-ONLY ZIP
# ============================================================================

def zip_package():

    h("11. FINAL DOCX-ONLY ZIP PACKAGE")

    if ZIPOUT.exists():

        ZIPOUT.unlink()

    added = []

    with zipfile.ZipFile(
        ZIPOUT,
        "w",
        zipfile.ZIP_DEFLATED
    ) as archive:

        for path in PACKAGE.rglob("*"):

            if not path.is_file():
                continue

            relative = path.relative_to(
                PACKAGE
            )

            relative_string = str(
                relative
            )

            # Never package internal backup.
            if relative_string.startswith(
                "_Stage38B_Backup"
            ):
                continue

            # Stage 38B is explicitly DOCX-only.
            # Do not include any PDF.
            if path.suffix.lower() == ".pdf":
                continue

            archive.write(
                path,
                arcname=relative_string
            )

            added.append(
                relative_string
            )

    # ZIP integrity test
    with zipfile.ZipFile(
        ZIPOUT,
        "r"
    ) as archive:

        bad_member = archive.testzip()

        if bad_member is not None:

            fail(
                f"ZIP integrity failure:\n"
                f"{bad_member}"
            )

        names = archive.namelist()

    # Confirm no PDF entered the final ZIP.
    pdf_members = [
        name
        for name in names
        if name.lower().endswith(".pdf")
    ]

    if pdf_members:

        fail(
            "PDF files unexpectedly entered "
            "the DOCX-only ZIP:\n"
            + "\n".join(pdf_members)
        )

    # Confirm DOCX is present.
    if "01_Final_Manuscript.docx" not in names:

        fail(
            "Final DOCX is missing from "
            "the DOCX-only ZIP."
        )

    print(
        f"ZIP file : {ZIPOUT}"
    )

    print(
        f"ZIP size : "
        f"{ZIPOUT.stat().st_size / 1024 / 1024:.2f} MB"
    )

    print(
        f"ZIP members: {len(names)}"
    )

    print(
        "ZIP integrity: PASS"
    )

    print(
        "PDF exclusion from ZIP: PASS"
    )

    print(
        "Final DOCX inclusion: PASS"
    )


# ============================================================================
# 21. FINAL AUDIT REPORT
# ============================================================================

def final_report():

    report = f"""
STAGE 38B — DOCX-ONLY FINAL AUDIT
===================================

STATUS: PASS

Scope
-----
Final Q1 manuscript package audited using DOCX only.

PDF generation:
DISABLED

PDF rebuild:
NOT PERFORMED

PDF audit:
NOT PERFORMED

PDF requirement:
NOT REQUIRED


Audit Results
-------------

Input validation:
PASS

Current DOCX backup:
PASS

Figure 1 replacement:
PASS

Figure 2 replacement:
PASS

Figure 3 replacement:
PASS

Figure 4 replacement:
PASS

DOCX embedded-image validation:
PASS

DOCX structural validation:
PASS

Legacy-value audit:
PASS

Verified experimental-value audit:
PASS

Additional scientific identifier audit:
PASS

Figure 1–4 textual reference audit:
PASS

Figure 1–4 file audit:
PASS

Figure 1–4 embedded-DOCX audit:
PASS

DOCX-only package content audit:
PASS

PDF exclusion audit:
PASS

Final DOCX validation:
PASS

ZIP integrity:
PASS


Verified Experimental Values
----------------------------

1,400.3845
4,036.1222
0.980447
0.990215

1,490.7452
4,087.0080
0.979950
0.989932

20.0042%
19.7594%
16.0978%


Final Cap125 / W30 Result
-------------------------

MAE  = 8.8959
RMSE = 12.2474
R²   = 0.9066


Final Files
-----------

DOCX:
{DOCX}

Manifest:
{MANIFEST}

Audit:
{AUDIT}

Final DOCX-only ZIP:
{ZIPOUT}


FINAL STATUS
------------

STAGE 38B — PASS

PDF is intentionally not part of the final Stage 38B workflow.

Next stage:
Stage 39 → Final ZIP Content Inspection + Submission Readiness Check.
"""

    AUDIT.write_text(
        report.strip() + "\n",
        encoding="utf-8"
    )

    h("12. STAGE 38B FINAL STATUS")

    print(report)

    print(
        f"Final DOCX:\n{DOCX}"
    )

    print(
        f"Final ZIP:\n{ZIPOUT}"
    )

    print(
        "\nSTAGE 38B — PASS"
    )

    print(
        "\nNext stage: "
        "Stage 39 → Final ZIP Content Inspection + "
        "Submission Readiness Check."
    )


# ============================================================================
# 22. MAIN
# ============================================================================

def main():

    h(
        "STAGE 38B — DOCX-ONLY FINAL AUDIT"
    )

    check_inputs()

    backup()

    replace_figures()

    count_images()

    audit_docx_text()

    audit_figures()

    verify_docx_figures()

    audit_no_pdf_requirement()

    final_docx_validation()

    manifest()

    zip_package()

    final_report()


# ============================================================================
# 23. ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    main()