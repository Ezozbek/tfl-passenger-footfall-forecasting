# ============================================================
# STAGE 32A
# FINAL FIGURE 1–4 GENERATION
# Transportation Research Part C
# ============================================================

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# 1. PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

FIGURE_DIR = PROJECT_ROOT / "figures"
BASELINE_DIR = PROJECT_ROOT / "tfl_baseline_results"

FIGURE_DIR.mkdir(exist_ok=True)

print("=" * 100)
print("STAGE 32A — FINAL FIGURE 1–4 GENERATION")
print("=" * 100)

print(f"Project root : {PROJECT_ROOT}")
print(f"Baseline dir : {BASELINE_DIR}")
print(f"Figure dir   : {FIGURE_DIR}")


# ============================================================
# 2. SOURCE FILES
# ============================================================

FEATURE_FILE = (
    BASELINE_DIR / "feature_importance.csv"
)

PREDICTION_FILE = (
    BASELINE_DIR / "final_test_predictions.csv"
)

COMPARISON_FILE = (
    BASELINE_DIR / "baseline_comparison_table.csv"
)


# ============================================================
# 3. CHECK FILES
# ============================================================

print("\nChecking source files...")

source_files = {
    "Feature importance": FEATURE_FILE,
    "Test predictions": PREDICTION_FILE,
    "Model comparison": COMPARISON_FILE,
}

for name, path in source_files.items():

    if path.exists():
        print(f"[OK] {name}: {path.name}")
    else:
        print(f"[MISSING] {name}: {path}")


# ============================================================
# 4. HELPER FUNCTION
# ============================================================

def save_figure(fig, filename):
    """
    Save publication-quality PNG and PDF.
    """

    png_path = FIGURE_DIR / f"{filename}.png"
    pdf_path = FIGURE_DIR / f"{filename}.pdf"

    fig.savefig(
        png_path,
        dpi=600,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf_path,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(f"[SAVED] {png_path.name}")
    print(f"[SAVED] {pdf_path.name}")


# ============================================================
# FIGURE 1
# FEATURE IMPORTANCE
# ============================================================

print("\n" + "=" * 100)
print("FIGURE 1 — FEATURE IMPORTANCE")
print("=" * 100)

if not FEATURE_FILE.exists():

    print("[ERROR] feature_importance.csv not found.")

else:

    df = pd.read_csv(FEATURE_FILE)

    print("Source:", FEATURE_FILE)
    print("Columns:", list(df.columns))
    print("Rows:", len(df))

    # --------------------------------------------------------
    # Validate columns
    # --------------------------------------------------------

    if "Feature" not in df.columns:
        raise ValueError(
            "feature_importance.csv must contain 'Feature'."
        )

    if "Importance" not in df.columns:
        raise ValueError(
            "feature_importance.csv must contain 'Importance'."
        )

    df["Importance"] = pd.to_numeric(
        df["Importance"],
        errors="coerce"
    )

    df = df.dropna(
        subset=["Importance"]
    )

    # Sort for horizontal bar chart
    df = df.sort_values(
        "Importance",
        ascending=True
    )

    print("\nFeature importance:")
    print(df.to_string(index=False))

    # --------------------------------------------------------
    # Plot
    # --------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(9, 6)
    )

    ax.barh(
        df["Feature"],
        df["Importance"]
    )

    ax.set_xlabel(
        "Feature Importance"
    )

    ax.set_ylabel(
        "Feature"
    )

    ax.set_title(
        "Feature Importance of the ExtraTrees Forecasting Model"
    )

    ax.grid(
        axis="x",
        alpha=0.25
    )

    save_figure(
        fig,
        "Figure_1_Feature_Importance"
    )


# ============================================================
# LOAD TEST PREDICTIONS
# ============================================================

print("\n" + "=" * 100)
print("LOADING TEST PREDICTIONS")
print("=" * 100)

prediction_df = None

if not PREDICTION_FILE.exists():

    print("[ERROR] final_test_predictions.csv not found.")

else:

    prediction_df = pd.read_csv(
        PREDICTION_FILE
    )

    print("Source:", PREDICTION_FILE)
    print("Rows:", len(prediction_df))
    print("Columns:", list(prediction_df.columns))

    print("\nFirst 5 rows:")
    print(
        prediction_df.head().to_string(
            index=False
        )
    )


# ============================================================
# DETECT ACTUAL / PREDICTED COLUMNS
# ============================================================

actual_col = None
predicted_col = None

if prediction_df is not None:

    columns_lower = {
        col.lower(): col
        for col in prediction_df.columns
    }

    # Possible actual names
    actual_candidates = [
        "actual",
        "y_true",
        "true",
        "observed",
        "actual_totalfootfall",
        "totalfootfall"
    ]

    # Possible prediction names
    prediction_candidates = [
        "predicted",
        "prediction",
        "y_pred",
        "forecast",
        "predicted_totalfootfall"
    ]

    for candidate in actual_candidates:

        if candidate in columns_lower:

            actual_col = columns_lower[candidate]
            break

    for candidate in prediction_candidates:

        if candidate in columns_lower:

            predicted_col = columns_lower[candidate]
            break

    print("\nDetected columns:")
    print("Actual    :", actual_col)
    print("Predicted :", predicted_col)


# ============================================================
# FIGURE 2
# ACTUAL VS PREDICTED
# ============================================================

print("\n" + "=" * 100)
print("FIGURE 2 — ACTUAL VS PREDICTED")
print("=" * 100)

if prediction_df is None:

    print(
        "[SKIPPED] Prediction data unavailable."
    )

elif actual_col is None or predicted_col is None:

    print(
        "[ERROR] Could not automatically identify "
        "actual/predicted columns."
    )

    print(
        "Available columns:",
        list(prediction_df.columns)
    )

else:

    actual = pd.to_numeric(
        prediction_df[actual_col],
        errors="coerce"
    )

    predicted = pd.to_numeric(
        prediction_df[predicted_col],
        errors="coerce"
    )

    valid = (
        actual.notna()
        & predicted.notna()
    )

    actual = actual[valid]
    predicted = predicted[valid]

    print(
        f"Valid observations: {len(actual):,}"
    )

    # --------------------------------------------------------
    # Calculate R2 and Pearson r independently
    # --------------------------------------------------------

    ss_res = np.sum(
        (actual - predicted) ** 2
    )

    ss_tot = np.sum(
        (actual - actual.mean()) ** 2
    )

    r2 = (
        1 - ss_res / ss_tot
        if ss_tot != 0
        else np.nan
    )

    pearson_r = np.corrcoef(
        actual,
        predicted
    )[0, 1]

    print(f"R²         : {r2:.5f}")
    print(f"Pearson r  : {pearson_r:.5f}")

    # --------------------------------------------------------
    # Plot
    # --------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(7.5, 7.5)
    )

    ax.scatter(
        actual,
        predicted,
        alpha=0.25,
        s=12
    )

    min_value = min(
        actual.min(),
        predicted.min()
    )

    max_value = max(
        actual.max(),
        predicted.max()
    )

    ax.plot(
        [min_value, max_value],
        [min_value, max_value],
        linestyle="--",
        linewidth=1.5
    )

    ax.set_xlabel(
        "Observed Total Footfall"
    )

    ax.set_ylabel(
        "Predicted Total Footfall"
    )

    ax.set_title(
        "Observed versus Predicted Passenger Footfall"
    )

    ax.text(
        0.05,
        0.95,
        f"$R^2$ = {r2:.5f}\n"
        f"Pearson $r$ = {pearson_r:.5f}",
        transform=ax.transAxes,
        verticalalignment="top"
    )

    ax.grid(
        alpha=0.25
    )

    save_figure(
        fig,
        "Figure_2_Actual_vs_Predicted"
    )


# ============================================================
# FIGURE 3
# RESIDUAL DIAGNOSTICS
# ============================================================

print("\n" + "=" * 100)
print("FIGURE 3 — RESIDUAL DIAGNOSTICS")
print("=" * 100)

if prediction_df is None:

    print(
        "[SKIPPED] Prediction data unavailable."
    )

elif actual_col is None or predicted_col is None:

    print(
        "[ERROR] Actual/predicted columns unavailable."
    )

else:

    actual = pd.to_numeric(
        prediction_df[actual_col],
        errors="coerce"
    )

    predicted = pd.to_numeric(
        prediction_df[predicted_col],
        errors="coerce"
    )

    valid = (
        actual.notna()
        & predicted.notna()
    )

    actual = actual[valid].to_numpy()
    predicted = predicted[valid].to_numpy()

    residuals = (
        actual - predicted
    )

    print(
        f"Residual observations: {len(residuals):,}"
    )

    print(
        f"Mean residual   : {residuals.mean():.4f}"
    )

    print(
        f"Median residual : {np.median(residuals):.4f}"
    )

    print(
        f"Residual std    : {residuals.std():.4f}"
    )

    # --------------------------------------------------------
    # Plot
    # --------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(9, 6)
    )

    ax.scatter(
        predicted,
        residuals,
        alpha=0.25,
        s=12
    )

    ax.axhline(
        0,
        linestyle="--",
        linewidth=1.5
    )

    ax.set_xlabel(
        "Predicted Total Footfall"
    )

    ax.set_ylabel(
        "Residual (Observed − Predicted)"
    )

    ax.set_title(
        "Residual Diagnostics for the ExtraTrees Model"
    )

    ax.grid(
        alpha=0.25
    )

    save_figure(
        fig,
        "Figure_3_Residual_Diagnostics"
    )


# ============================================================
# FIGURE 4
# MODEL COMPARISON
# ============================================================

print("\n" + "=" * 100)
print("FIGURE 4 — MODEL COMPARISON")
print("=" * 100)

if not COMPARISON_FILE.exists():

    print(
        "[ERROR] baseline_comparison_table.csv not found."
    )

else:

    comparison_df = pd.read_csv(
        COMPARISON_FILE
    )

    print(
        "Source:",
        COMPARISON_FILE
    )

    print(
        "Columns:",
        list(comparison_df.columns)
    )

    print(
        "\nModel comparison data:"
    )

    print(
        comparison_df.to_string(
            index=False
        )
    )

    # --------------------------------------------------------
    # Use REAL TEST results
    # --------------------------------------------------------

    required_columns = [
        "Model",
        "Test_MAE",
        "Test_RMSE",
        "Test_R2",
        "Test_Pearson_r"
    ]

    missing_columns = [
        col
        for col in required_columns
        if col not in comparison_df.columns
    ]

    if missing_columns:

        raise ValueError(
            "Missing columns in baseline_comparison_table.csv: "
            + str(missing_columns)
        )

    # --------------------------------------------------------
    # Convert numerical columns
    # --------------------------------------------------------

    for col in [
        "Test_MAE",
        "Test_RMSE",
        "Test_R2",
        "Test_Pearson_r"
    ]:

        comparison_df[col] = pd.to_numeric(
            comparison_df[col],
            errors="coerce"
        )

    comparison_df = comparison_df.dropna(
        subset=[
            "Test_MAE",
            "Test_RMSE"
        ]
    )

    # --------------------------------------------------------
    # Plot TEST MAE and TEST RMSE
    # --------------------------------------------------------

    models = comparison_df[
        "Model"
    ].astype(str)

    x = np.arange(
        len(models)
    )

    width = 0.35

    fig, ax = plt.subplots(
        figsize=(10, 6)
    )

    ax.bar(
        x - width / 2,
        comparison_df["Test_MAE"],
        width,
        label="Test MAE"
    )

    ax.bar(
        x + width / 2,
        comparison_df["Test_RMSE"],
        width,
        label="Test RMSE"
    )

    ax.set_xticks(x)

    ax.set_xticklabels(
        models,
        rotation=20,
        ha="right"
    )

    ax.set_ylabel(
        "Prediction Error"
    )

    ax.set_title(
        "Test-Set Comparison of Forecasting Models"
    )

    ax.legend()

    ax.grid(
        axis="y",
        alpha=0.25
    )

    fig.tight_layout()

    save_figure(
        fig,
        "Figure_4_Model_Comparison"
    )


# ============================================================
# FINAL OUTPUT REPORT
# ============================================================

print("\n" + "=" * 100)
print("STAGE 32A — FINAL OUTPUT")
print("=" * 100)

print("\nFigure directory:")
print(FIGURE_DIR)

print("\nGenerated files:")

for file in sorted(
    FIGURE_DIR.iterdir()
):

    if file.is_file():

        print(
            f" - {file.name}"
        )

print("\nExpected final files:")

expected_files = [
    "Figure_1_Feature_Importance.png",
    "Figure_1_Feature_Importance.pdf",
    "Figure_2_Actual_vs_Predicted.png",
    "Figure_2_Actual_vs_Predicted.pdf",
    "Figure_3_Residual_Diagnostics.png",
    "Figure_3_Residual_Diagnostics.pdf",
    "Figure_4_Model_Comparison.png",
    "Figure_4_Model_Comparison.pdf",
]

for filename in expected_files:

    path = FIGURE_DIR / filename

    status = "OK" if path.exists() else "MISSING"

    print(
        f"[{status}] {filename}"
    )

print("\n" + "=" * 100)
print("STAGE 32A COMPLETED")
print("=" * 100)
# ============================================================
# FINAL OUTPUT REPORT
# ============================================================

print("\n" + "=" * 100)
print("STAGE 32A — FINAL OUTPUT")
print("=" * 100)

print("\nFigure directory:")
print(FIGURE_DIR)

print("\nGenerated files:")

for file in sorted(
    FIGURE_DIR.iterdir()
):

    if file.is_file():

        print(
            f" - {file.name}"
        )

print("\nExpected final files:")

expected_files = [
    "Figure_1_Feature_Importance.png",
    "Figure_1_Feature_Importance.pdf",
    "Figure_2_Actual_vs_Predicted.png",
    "Figure_2_Actual_vs_Predicted.pdf",
    "Figure_3_Residual_Diagnostics.png",
    "Figure_3_Residual_Diagnostics.pdf",
    "Figure_4_Model_Comparison.png",
    "Figure_4_Model_Comparison.pdf",
]

for filename in expected_files:

    path = FIGURE_DIR / filename

    status = "OK" if path.exists() else "MISSING"

    print(
        f"[{status}] {filename}"
    )

print("\n" + "=" * 100)
print("DONE")
print("=" * 100)