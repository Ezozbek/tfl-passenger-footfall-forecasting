# -*- coding: utf-8 -*-
"""
Stage 48 — Supplementary Tables Generation

Purpose:
    Collect verified experimental outputs into standardized
    Supplementary Tables S1-S10.

Important:
    - No new model training.
    - No recalculation of scientific results unless explicitly required
      for descriptive/source tables.
    - Final v3 ablation is the primary ablation source.
    - Main manuscript Figures 1-4 are NOT duplicated here.
"""

from pathlib import Path
import pandas as pd
import numpy as np
import shutil
import sys
import traceback


# =============================================================================
# 1. PATHS
# =============================================================================

ROOT = Path(__file__).resolve().parent

OUT_DIR = (
    ROOT
    / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"
    / "05_Supplementary_Material"
)

TABLE_DIR = OUT_DIR / "Tables"

TABLE_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 2. SOURCE FILES
# =============================================================================

FILES = {
    # Master data
    "year_summary":
        ROOT / "tfl_master_data" / "year_summary.csv",

    "missing_value_report":
        ROOT / "tfl_master_data" / "missing_value_report.csv",

    "station_summary":
        ROOT / "tfl_master_data" / "station_summary.csv",

    # Baseline
    "baseline_comparison":
        ROOT / "tfl_baseline_results" / "baseline_comparison_table.csv",

    "baseline_validation":
        ROOT / "tfl_baseline_results" / "validation_baseline_results.csv",

    "baseline_test":
        ROOT / "tfl_baseline_results" / "test_baseline_results.csv",

    "baseline_feature_importance":
        ROOT / "tfl_baseline_results" / "feature_importance.csv",

    "baseline_configuration":
        ROOT / "tfl_baseline_results" / "experiment_configuration.csv",

    # Advanced
    "advanced_test":
        ROOT / "tfl_advanced_results" / "advanced_test_results.csv",

    "advanced_validation":
        ROOT / "tfl_advanced_results" / "advanced_validation_results.csv",

    "baseline_vs_advanced":
        ROOT / "tfl_advanced_results" / "baseline_vs_advanced.csv",

    "advanced_feature_importance":
        ROOT / "tfl_advanced_results" / "advanced_feature_importance.csv",

    "advanced_configuration":
        ROOT / "tfl_advanced_results"
        / "advanced_experiment_configuration.csv",

    # Final v3 ablation
    "ablation_v3":
        ROOT / "tfl_ablation_results_v3"
        / "MANUSCRIPT_ABLATION_TABLE_V3.csv",

    "ablation_results_v3":
        ROOT / "tfl_ablation_results_v3"
        / "ablation_results_v3.csv",

    "feature_summary_v3":
        ROOT / "tfl_ablation_results_v3"
        / "feature_summary_v3.csv",

    "feature_diagnostics_v3":
        ROOT / "tfl_ablation_results_v3"
        / "feature_diagnostics_v3.csv",

    "prediction_diagnostics_v3":
        ROOT / "tfl_ablation_results_v3"
        / "prediction_diagnostics_v3.csv",

    "split_summary_v3":
        ROOT / "tfl_ablation_results_v3"
        / "split_summary_v3.csv",

    # Calendar-aware validation
    "calendar_lag_report":
        ROOT / "tfl_calendar_ml" / "calendar_lag_report.csv",

    "calendar_configuration":
        ROOT / "tfl_calendar_ml" / "feature_configuration.csv",

    # Scientific validation
    "final_model_results":
        ROOT / "scientific_validation_results"
        / "FINAL_MANUSCRIPT_MODEL_RESULTS.csv",

    "final_feature_importance":
        ROOT / "scientific_validation_results"
        / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv",

    "model_comparison_deltas":
        ROOT / "scientific_validation_results"
        / "stage35_audit"
        / "model_comparison_deltas.csv",
}


# =============================================================================
# 3. LOGGING
# =============================================================================

audit_rows = []


def log(message):
    print(message)


def record(table, status, source="", rows="", cols="", note=""):
    audit_rows.append({
        "Table": table,
        "Status": status,
        "Source": source,
        "Rows": rows,
        "Columns": cols,
        "Note": note,
    })


def load_csv(key):
    """
    Load a source CSV while preserving original values as much as possible.
    """
    path = FILES[key]

    if not path.exists():
        raise FileNotFoundError(
            f"Required source file not found:\n{path}"
        )

    df = pd.read_csv(path)

    log(
        f"LOADED | {key:<28} | "
        f"{df.shape[0]:>8,} rows | {df.shape[1]:>3} cols | {path.name}"
    )

    return df


def save_table(df, filename):
    """
    Save supplementary CSV.
    """
    path = TABLE_DIR / filename

    df.to_csv(
        path,
        index=False,
        encoding="utf-8-sig"
    )

    log(
        f"SAVED  | {filename:<42} | "
        f"{df.shape[0]:>8,} rows | {df.shape[1]:>3} cols"
    )

    return path


# =============================================================================
# 4. VALIDATE ALL SOURCE FILES FIRST
# =============================================================================

log("=" * 100)
log("STAGE 48 — SUPPLEMENTARY TABLES GENERATION")
log("=" * 100)

log("\n[1] SOURCE FILE VALIDATION")
log("-" * 100)

missing = []

for key, path in FILES.items():
    if path.exists():
        log(f"PASS | {key:<30} | {path}")
    else:
        log(f"MISS | {key:<30} | {path}")
        missing.append((key, path))

if missing:
    log("\nWARNING: Some optional/expected files are missing.")
    for key, path in missing:
        log(f"  - {key}: {path}")

log("")


# =============================================================================
# 5. TABLE S1 — DESCRIPTIVE STATISTICS
# =============================================================================

log("=" * 100)
log("TABLE S1 — DESCRIPTIVE STATISTICS")
log("=" * 100)

try:
    year = load_csv("year_summary")

    # Preserve source table as the primary descriptive summary.
    s1 = year.copy()

    save_table(
        s1,
        "Table_S1_Descriptive_Statistics.csv"
    )

    record(
        "S1",
        "PASS",
        str(FILES["year_summary"]),
        s1.shape[0],
        s1.shape[1],
        "Source year-level descriptive summary."
    )

except Exception as e:
    record("S1", "FAIL", note=str(e))
    log(f"S1 ERROR: {e}")


# =============================================================================
# 6. TABLE S2 — DATA QUALITY
# =============================================================================

log("=" * 100)
log("TABLE S2 — DATA QUALITY")
log("=" * 100)

try:
    missing_df = load_csv("missing_value_report")

    s2 = missing_df.copy()

    # If station summary contains useful data-quality fields,
    # keep the missing-value report as the authoritative source.
    save_table(
        s2,
        "Table_S2_Data_Quality.csv"
    )

    record(
        "S2",
        "PASS",
        str(FILES["missing_value_report"]),
        s2.shape[0],
        s2.shape[1],
        "Source missing-value/data-quality report."
    )

except Exception as e:
    record("S2", "FAIL", note=str(e))
    log(f"S2 ERROR: {e}")


# =============================================================================
# 7. TABLE S3 — MODEL COMPARISON
# =============================================================================

log("=" * 100)
log("TABLE S3 — MODEL COMPARISON")
log("=" * 100)

try:
    sources = []

    if FILES["baseline_comparison"].exists():
        df = load_csv("baseline_comparison")
        df["Source"] = "Baseline"
        sources.append(df)

    if FILES["baseline_vs_advanced"].exists():
        df = load_csv("baseline_vs_advanced")
        df["Source"] = "Baseline_vs_Advanced"
        sources.append(df)

    if FILES["final_model_results"].exists():
        df = load_csv("final_model_results")
        df["Source"] = "Scientific_Validation"
        sources.append(df)

    if not sources:
        raise FileNotFoundError(
            "No model comparison source was available."
        )

    s3 = pd.concat(
        sources,
        ignore_index=True,
        sort=False
    )

    save_table(
        s3,
        "Table_S3_Model_Comparison.csv"
    )

    record(
        "S3",
        "PASS",
        "baseline_comparison + baseline_vs_advanced + "
        "FINAL_MANUSCRIPT_MODEL_RESULTS",
        s3.shape[0],
        s3.shape[1],
        "Combined model-comparison evidence; source retained."
    )

except Exception as e:
    record("S3", "FAIL", note=str(e))
    log(f"S3 ERROR: {e}")


# =============================================================================
# 8. TABLE S4 — FINAL ABLATION
# =============================================================================

log("=" * 100)
log("TABLE S4 — FINAL ABLATION")
log("=" * 100)

try:
    # IMPORTANT:
    # Final v3 manuscript table is the authoritative ablation source.
    s4 = load_csv("ablation_v3")

    save_table(
        s4,
        "Table_S4_Final_Ablation.csv"
    )

    record(
        "S4",
        "PASS",
        str(FILES["ablation_v3"]),
        s4.shape[0],
        s4.shape[1],
        "Final v3 manuscript ablation table."
    )

except Exception as e:
    record("S4", "FAIL", note=str(e))
    log(f"S4 ERROR: {e}")


# =============================================================================
# 9. TABLE S5 — FEATURE IMPORTANCE
# =============================================================================

log("=" * 100)
log("TABLE S5 — FEATURE IMPORTANCE")
log("=" * 100)

try:
    sources = []

    if FILES["final_feature_importance"].exists():
        df = load_csv("final_feature_importance")
        df["Source"] = "Final_Manuscript"
        sources.append(df)

    elif FILES["advanced_feature_importance"].exists():
        df = load_csv("advanced_feature_importance")
        df["Source"] = "Advanced"
        sources.append(df)

    elif FILES["baseline_feature_importance"].exists():
        df = load_csv("baseline_feature_importance")
        df["Source"] = "Baseline"
        sources.append(df)

    if not sources:
        raise FileNotFoundError(
            "No feature-importance source was available."
        )

    s5 = pd.concat(
        sources,
        ignore_index=True,
        sort=False
    )

    save_table(
        s5,
        "Table_S5_Feature_Importance.csv"
    )

    record(
        "S5",
        "PASS",
        "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10 "
        "or verified fallback",
        s5.shape[0],
        s5.shape[1],
        "Feature-importance evidence."
    )

except Exception as e:
    record("S5", "FAIL", note=str(e))
    log(f"S5 ERROR: {e}")


# =============================================================================
# 10. TABLE S6 — VALIDATION RESULTS
# =============================================================================

log("=" * 100)
log("TABLE S6 — VALIDATION RESULTS")
log("=" * 100)

try:
    sources = []

    if FILES["baseline_validation"].exists():
        df = load_csv("baseline_validation")
        df["Source"] = "Baseline"
        sources.append(df)

    if FILES["advanced_validation"].exists():
        df = load_csv("advanced_validation")
        df["Source"] = "Advanced"
        sources.append(df)

    if not sources:
        raise FileNotFoundError(
            "No validation-result source was available."
        )

    s6 = pd.concat(
        sources,
        ignore_index=True,
        sort=False
    )

    save_table(
        s6,
        "Table_S6_Validation_Results.csv"
    )

    record(
        "S6",
        "PASS",
        "validation_baseline_results + "
        "advanced_validation_results",
        s6.shape[0],
        s6.shape[1],
        "Validation results from completed experiments."
    )

except Exception as e:
    record("S6", "FAIL", note=str(e))
    log(f"S6 ERROR: {e}")


# =============================================================================
# 11. TABLE S7 — EXPERIMENT CONFIGURATION
# =============================================================================

log("=" * 100)
log("TABLE S7 — EXPERIMENT CONFIGURATION")
log("=" * 100)

try:
    sources = []

    if FILES["baseline_configuration"].exists():
        df = load_csv("baseline_configuration")
        df["Source"] = "Baseline"
        sources.append(df)

    if FILES["advanced_configuration"].exists():
        df = load_csv("advanced_configuration")
        df["Source"] = "Advanced"
        sources.append(df)

    if FILES["calendar_configuration"].exists():
        df = load_csv("calendar_configuration")
        df["Source"] = "Calendar_Aware"
        sources.append(df)

    if not sources:
        raise FileNotFoundError(
            "No experiment configuration files were available."
        )

    s7 = pd.concat(
        sources,
        ignore_index=True,
        sort=False
    )

    save_table(
        s7,
        "Table_S7_Experiment_Configuration.csv"
    )

    record(
        "S7",
        "PASS",
        "Baseline + Advanced + Calendar configuration files",
        s7.shape[0],
        s7.shape[1],
        "Experimental configuration provenance."
    )

except Exception as e:
    record("S7", "FAIL", note=str(e))
    log(f"S7 ERROR: {e}")


# =============================================================================
# 12. TABLE S8 — TEMPORAL VALIDATION
# =============================================================================

log("=" * 100)
log("TABLE S8 — TEMPORAL VALIDATION")
log("=" * 100)

try:
    s8 = load_csv("calendar_lag_report")

    save_table(
        s8,
        "Table_S8_Temporal_Validation.csv"
    )

    record(
        "S8",
        "PASS",
        str(FILES["calendar_lag_report"]),
        s8.shape[0],
        s8.shape[1],
        "Calendar/lag temporal-validation evidence."
    )

except Exception as e:
    record("S8", "FAIL", note=str(e))
    log(f"S8 ERROR: {e}")


# =============================================================================
# 13. TABLE S9 — PREDICTION DIAGNOSTICS
# =============================================================================

log("=" * 100)
log("TABLE S9 — PREDICTION DIAGNOSTICS")
log("=" * 100)

try:
    s9 = load_csv("prediction_diagnostics_v3")

    save_table(
        s9,
        "Table_S9_Prediction_Diagnostics.csv"
    )

    record(
        "S9",
        "PASS",
        str(FILES["prediction_diagnostics_v3"]),
        s9.shape[0],
        s9.shape[1],
        "Final v3 prediction diagnostics."
    )

except Exception as e:
    record("S9", "FAIL", note=str(e))
    log(f"S9 ERROR: {e}")


# =============================================================================
# 14. TABLE S10 — SPLIT VALIDATION
# =============================================================================

log("=" * 100)
log("TABLE S10 — SPLIT VALIDATION")
log("=" * 100)

try:
    s10 = load_csv("split_summary_v3")

    save_table(
        s10,
        "Table_S10_Split_Validation.csv"
    )

    record(
        "S10",
        "PASS",
        str(FILES["split_summary_v3"]),
        s10.shape[0],
        s10.shape[1],
        "Final v3 train/validation/test split evidence."
    )

except Exception as e:
    record("S10", "FAIL", note=str(e))
    log(f"S10 ERROR: {e}")


# =============================================================================
# 15. CREATE AUDIT REPORT
# =============================================================================

log("=" * 100)
log("CREATING STAGE 48 AUDIT")
log("=" * 100)

audit_df = pd.DataFrame(audit_rows)

audit_path = OUT_DIR / "STAGE48_SUPPLEMENTARY_TABLES_AUDIT.csv"

audit_df.to_csv(
    audit_path,
    index=False,
    encoding="utf-8-sig"
)

log(f"\nAudit saved:")
log(audit_path)


# =============================================================================
# 16. INVENTORY
# =============================================================================

inventory = []

for path in sorted(TABLE_DIR.glob("*.csv")):
    inventory.append({
        "File": path.name,
        "Size_KB": round(path.stat().st_size / 1024, 2),
    })

inventory_df = pd.DataFrame(inventory)

inventory_path = OUT_DIR / "STAGE48_TABLE_INVENTORY.csv"

inventory_df.to_csv(
    inventory_path,
    index=False,
    encoding="utf-8-sig"
)

log("\nTable inventory:")
print(inventory_df.to_string(index=False))


# =============================================================================
# 17. FINAL STATUS
# =============================================================================

passed = int(
    (audit_df["Status"] == "PASS").sum()
)

failed = int(
    (audit_df["Status"] == "FAIL").sum()
)

log("\n" + "=" * 100)
log("STAGE 48 FINAL STATUS")
log("=" * 100)

log(f"Tables PASS : {passed}")
log(f"Tables FAIL : {failed}")
log(f"Output dir  : {TABLE_DIR}")

if failed == 0:
    log("\nSTAGE 48 — PASS")
    log("All Supplementary Tables were generated successfully.")
else:
    log("\nSTAGE 48 — REVIEW REQUIRED")
    log("One or more tables could not be generated.")
    log("Review STAGE48_SUPPLEMENTARY_TABLES_AUDIT.csv")

log("=" * 100)