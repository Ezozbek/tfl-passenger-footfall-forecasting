from pathlib import Path
from docx import Document
import re

MANUSCRIPT = Path(
    r"C:\Users\Kawai\PycharmProjects\PythonProject5_Transport_Scheduling"
    r"\STAGE36_FINAL_Q1_SUBMISSION_PACKAGE\01_Final_Manuscript.docx"
)

doc = Document(MANUSCRIPT)

texts = []

for p in doc.paragraphs:
    if p.text.strip():
        texts.append(p.text.strip())

for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            if cell.text.strip():
                texts.append(cell.text.strip())

full_text = "\n".join(texts)

patterns = [
    r".{0,250}residual.{0,400}",
    r".{0,250}resid.{0,400}",
    r".{0,250}error.{0,400}",
    r".{0,250}prediction.{0,400}",
    r".{0,250}26\.3903.{0,300}",
    r".{0,250}32\.6876.{0,300}",
]

print("=" * 100)
print("STAGE 41A — RESIDUAL DEFINITION VERIFICATION")
print("=" * 100)

found = set()

for pattern in patterns:

    matches = re.findall(
        pattern,
        full_text,
        flags=re.IGNORECASE | re.DOTALL
    )

    for match in matches:

        cleaned = " ".join(match.split())

        if cleaned not in found:

            found.add(cleaned)

            print("\n---")
            print(cleaned)

print("\n" + "=" * 100)
print(f"Unique relevant passages found: {len(found)}")
print("=" * 100)