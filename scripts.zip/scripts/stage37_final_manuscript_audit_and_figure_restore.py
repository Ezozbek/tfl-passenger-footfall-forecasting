# -*- coding: utf-8 -*-

"""
STAGE 37
FINAL MANUSCRIPT FILE AUDIT + COMPLETE FIGURE RESTORATION

Project:
AI-Based Passenger Footfall Forecasting for Data-Driven Public Transport
Scheduling Support

Restores:
    Figure 1 - Feature Importance
    Figure 2 - Actual vs Predicted
    Figure 3 - Residual Diagnostics
    Figure 4 - Baseline vs Advanced Model Comparison

Audits:
    - Final manuscript DOCX
    - Legacy rejected values
    - Verified scientific values
    - Real test prediction data
    - Residual definition
    - Absolute error definition
    - Recomputed test metrics
    - All Figure 1-4 PNG/PDF files

IMPORTANT:
This script does NOT invent scientific results.
All figures are generated from project result files.
"""

from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# =============================================================================
# 0. PROJECT PATHS
# =============================================================================

ROOT = Path(__file__).resolve().parent

PACKAGE = ROOT / "STAGE36_FINAL_Q1_SUBMISSION_PACKAGE"

MANUSCRIPT_DOCX = PACKAGE / "01_Final_Manuscript.docx"
MANUSCRIPT_PDF = PACKAGE / "02_Final_Manuscript.pdf"

FIGURE_DIR = PACKAGE / "03_High_Resolution_Figures"
TABLE_DIR = PACKAGE / "04_Final_Tables"
SUPPLEMENTARY_DIR = PACKAGE / "05_Supplementary_Material"


# =============================================================================
# ORIGINAL RESULT FILES
# =============================================================================

PREDICTION_FILE = (
    ROOT
    / "tfl_baseline_results"
    / "final_test_predictions.csv"
)

BASELINE_ADVANCED_FILE = (
    ROOT
    / "tfl_advanced_results"
    / "baseline_vs_advanced.csv"
)

FEATURE_IMPORTANCE_FILE = (
    ROOT
    / "scientific_validation_results"
    / "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"
)


# =============================================================================
# VERIFIED SCIENTIFIC RESULTS
# =============================================================================

VERIFIED = {

    # ExtraTrees
    "ExtraTrees_MAE": 1400.3844781891,
    "ExtraTrees_RMSE": 4036.1221687711,
    "ExtraTrees_R2": 0.9804465419,
    "ExtraTrees_Pearson": 0.9902146576,
    "ExtraTrees_MeanResidual": 26.3903403536,
    "ExtraTrees_MedianResidual": 32.6876261385,

    # XGBoost
    "XGB_MAE": 1490.745239,
    "XGB_RMSE": 4087.007952,
    "XGB_R2": 0.979950,
    "XGB_Pearson": 0.989932,

    # Feature importance
    "FI_Lag_28": 20.004240,
    "FI_Lag_7": 19.759367,
    "FI_Lag_14": 16.097803,
    "FI_RollingMean_14": 12.438370,
    "FI_RollingMean_7": 10.595398,
    "FI_RollingMean_28": 9.457883,
    "FI_Lag_1": 9.232181,
}


# =============================================================================
# REJECTED LEGACY VALUES
# =============================================================================

REJECTED_LEGACY_VALUES = [
    "61.998",
    "61.998%",
    "-5.48",
    "mean bias = -5.48",
]


# =============================================================================
# REQUIRED VALUES IN FINAL MANUSCRIPT
# =============================================================================

REQUIRED_MANUSCRIPT_VALUES = [
    "1,400.3845",
    "4,036.1222",
    "0.980447",
    "0.990215",
    "1,490.7452",
    "4,087.0080",
    "0.979950",
    "0.989932",
    "20.0042%",
    "19.7594%",
    "16.0978%",
]


# =============================================================================
# HELPER
# =============================================================================

def header(title):

    print("=" * 100)
    print(title)
    print("=" * 100)


def fail(message):

    print()
    print("=" * 100)
    print("STAGE 37 — FAIL")
    print("=" * 100)
    print(message)
    sys.exit(1)


# =============================================================================
# 1. MANUSCRIPT AUDIT
# =============================================================================

def extract_docx_text(path):

    try:
        from docx import Document
    except ImportError:
        fail(
            "python-docx is not installed.\n"
            "Run:\n"
            "pip install python-docx"
        )

    doc = Document(path)

    parts = []

    for paragraph in doc.paragraphs:

        text = paragraph.text.strip()

        if text:
            parts.append(text)

    for table in doc.tables:

        for row in table.rows:

            cells = []

            for cell in row.cells:

                value = cell.text.strip()

                if value:
                    cells.append(value)

            if cells:
                parts.append(" | ".join(cells))

    return "\n".join(parts)


def audit_manuscript():

    header("1. MANUSCRIPT FILE AUDIT")

    print(f"DOCX: {MANUSCRIPT_DOCX}")
    print(f"PDF : {MANUSCRIPT_PDF}")

    if not MANUSCRIPT_DOCX.exists():
        fail("Final manuscript DOCX not found.")

    if not MANUSCRIPT_PDF.exists():
        print("WARNING: PDF file not found.")

    text = extract_docx_text(MANUSCRIPT_DOCX)

    # -------------------------------------------------------------------------
    # Legacy scan
    # -------------------------------------------------------------------------

    legacy_hits = []

    for value in REJECTED_LEGACY_VALUES:

        if value.lower() in text.lower():
            legacy_hits.append(value)

    if legacy_hits:

        print("Rejected legacy values found:")

        for value in legacy_hits:
            print(f"  - {value}")

        fail(
            "Rejected legacy values remain in the final manuscript."
        )

    print("Rejected legacy values: NONE")

    # -------------------------------------------------------------------------
    # Verified values
    # -------------------------------------------------------------------------

    missing = []

    for value in REQUIRED_MANUSCRIPT_VALUES:

        if value not in text:
            missing.append(value)

    if missing:

        print("Missing verified values:")

        for value in missing:
            print(f"  - {value}")

        fail(
            "Required verified scientific values are missing "
            "from the manuscript."
        )

    print("Verified-value checks: PASS")


# =============================================================================
# 2. FIND / LOAD PREDICTION FILE
# =============================================================================

def locate_prediction_file():

    if PREDICTION_FILE.exists():
        return PREDICTION_FILE

    matches = list(ROOT.rglob("final_test_predictions.csv"))

    if matches:
        return matches[0]

    for file in ROOT.rglob("*.csv"):

        try:

            cols = set(
                pd.read_csv(
                    file,
                    nrows=0
                ).columns
            )

            required = {
                "TotalFootfall",
                "Predicted_TotalFootfall",
                "Residual",
            }

            if required.issubset(cols):
                return file

        except Exception:
            continue

    return None


def load_predictions():

    header("2. ORIGINAL PREDICTION/RESIDUAL DATA SEARCH")

    predfile = locate_prediction_file()

    if predfile is None:

        fail(
            "final_test_predictions.csv could not be found."
        )

    print(f"Found: {predfile}")

    df = pd.read_csv(predfile)

    print()
    print("Prediction file shape:")
    print(f"Rows    : {len(df):,}")
    print(f"Columns : {len(df.columns)}")

    print()
    print("Columns:")

    for column in df.columns:
        print(f"  - {column}")

    required = [
        "TravelDate",
        "Station",
        "TotalFootfall",
        "Predicted_TotalFootfall",
        "Absolute_Error",
        "Residual",
    ]

    missing = [
        col
        for col in required
        if col not in df.columns
    ]

    if missing:

        fail(
            "Required prediction columns missing:\n"
            + "\n".join(
                f"  - {x}"
                for x in missing
            )
        )

    print()
    print("Column mapping:")
    print("  Actual    : TotalFootfall")
    print("  Predicted : Predicted_TotalFootfall")
    print("  Residual  : Residual")
    print("  Abs Error : Absolute_Error")

    # Numeric conversion
    numeric_columns = [
        "TotalFootfall",
        "Predicted_TotalFootfall",
        "Absolute_Error",
        "Residual",
    ]

    for col in numeric_columns:

        df[col] = pd.to_numeric(
            df[col],
            errors="coerce"
        )

    df = df.dropna(
        subset=[
            "TotalFootfall",
            "Predicted_TotalFootfall",
            "Residual",
        ]
    ).copy()

    # -------------------------------------------------------------------------
    # Residual validation
    # -------------------------------------------------------------------------

    expected_residual = (
        df["TotalFootfall"]
        - df["Predicted_TotalFootfall"]
    )

    residual_difference = (
        expected_residual
        - df["Residual"]
    ).abs()

    max_residual_difference = (
        residual_difference.max()
    )

    print()
    print("Residual definition check:")
    print(
        "  Expected: "
        "Residual = TotalFootfall - Predicted_TotalFootfall"
    )

    print(
        f"  Maximum absolute difference: "
        f"{max_residual_difference:.12f}"
    )

    if max_residual_difference > 1e-6:

        fail(
            "Residual column does not match "
            "Actual - Predicted."
        )

    print("  Residual check: PASS")

    # -------------------------------------------------------------------------
    # Absolute error validation
    # -------------------------------------------------------------------------

    expected_abs_error = expected_residual.abs()

    abs_difference = (
        expected_abs_error
        - df["Absolute_Error"]
    ).abs()

    max_abs_difference = abs_difference.max()

    print()
    print("Absolute-error definition check:")
    print(
        "  Expected: "
        "Absolute_Error = |Actual - Predicted|"
    )

    print(
        f"  Maximum absolute difference: "
        f"{max_abs_difference:.12f}"
    )

    if max_abs_difference > 1e-6:

        fail(
            "Absolute_Error column does not match "
            "|Actual - Predicted|."
        )

    print("  Absolute-error check: PASS")

    return df


# =============================================================================
# 3. RECOMPUTE METRICS
# =============================================================================

def compute_metrics(df):

    actual = df[
        "TotalFootfall"
    ].to_numpy(dtype=float)

    predicted = df[
        "Predicted_TotalFootfall"
    ].to_numpy(dtype=float)

    residual = df[
        "Residual"
    ].to_numpy(dtype=float)

    mae = np.mean(
        np.abs(actual - predicted)
    )

    rmse = np.sqrt(
        np.mean(
            (actual - predicted) ** 2
        )
    )

    ss_res = np.sum(
        (actual - predicted) ** 2
    )

    ss_tot = np.sum(
        (actual - np.mean(actual)) ** 2
    )

    r2 = 1 - ss_res / ss_tot

    pearson = np.corrcoef(
        actual,
        predicted
    )[0, 1]

    mean_residual = np.mean(residual)

    median_residual = np.median(residual)

    metrics = {
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "Pearson": pearson,
        "MeanResidual": mean_residual,
        "MedianResidual": median_residual,
    }

    header("3. RECOMPUTED TEST METRICS FROM PREDICTION FILE")

    print(
        f"MAE            : {mae:,.6f}"
    )

    print(
        f"RMSE           : {rmse:,.6f}"
    )

    print(
        f"R²             : {r2:.9f}"
    )

    print(
        f"Pearson r      : {pearson:.9f}"
    )

    print(
        f"Mean Residual  : {mean_residual:+,.6f}"
    )

    print(
        f"Median Residual: {median_residual:+,.6f}"
    )

    return metrics


# =============================================================================
# 4. METRIC CONSISTENCY
# =============================================================================

def validate_metrics(metrics):

    header("4. SCIENTIFIC METRIC CONSISTENCY CHECK")

    checks = {

        "MAE": (
            metrics["MAE"],
            VERIFIED["ExtraTrees_MAE"],
            1e-3,
        ),

        "RMSE": (
            metrics["RMSE"],
            VERIFIED["ExtraTrees_RMSE"],
            1e-3,
        ),

        "R2": (
            metrics["R2"],
            VERIFIED["ExtraTrees_R2"],
            1e-7,
        ),

        "Pearson_r": (
            metrics["Pearson"],
            VERIFIED["ExtraTrees_Pearson"],
            1e-7,
        ),

        "Mean_Residual": (
            metrics["MeanResidual"],
            VERIFIED["ExtraTrees_MeanResidual"],
            1e-3,
        ),

        "Median_Residual": (
            metrics["MedianResidual"],
            VERIFIED["ExtraTrees_MedianResidual"],
            1e-3,
        ),
    }

    failures = []

    for name, (
        observed,
        expected,
        tolerance
    ) in checks.items():

        difference = abs(
            observed - expected
        )

        if difference <= tolerance:

            print(
                f"{name:20s} PASS | "
                f"observed={observed:.9f} | "
                f"expected={expected:.9f} | "
                f"diff={difference:.3e}"
            )

        else:

            print(
                f"{name:20s} FAIL | "
                f"observed={observed:.9f} | "
                f"expected={expected:.9f} | "
                f"diff={difference:.3e}"
            )

            failures.append(name)

    if failures:

        fail(
            "Metric consistency failed: "
            + ", ".join(failures)
        )

    print()
    print("Scientific metric consistency: PASS")


# =============================================================================
# 5. SAVE SUPPLEMENTARY PAIRED DATA
# =============================================================================

def save_paired_data(df):

    header("5. SAVE PAIRED TEST PREDICTION DATA")

    SUPPLEMENTARY_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    output = (
        SUPPLEMENTARY_DIR
        / "Figure_2_3_Paired_Test_Predictions.csv"
    )

    columns = [
        "TravelDate",
        "Station",
        "TotalFootfall",
        "Predicted_TotalFootfall",
        "Absolute_Error",
        "Residual",
    ]

    df[columns].to_csv(
        output,
        index=False,
        encoding="utf-8-sig"
    )

    print(f"Saved: {output}")
    print(f"Rows : {len(df):,}")


# =============================================================================
# 6. FIGURE 1 — FEATURE IMPORTANCE
# =============================================================================

def locate_feature_importance():

    if FEATURE_IMPORTANCE_FILE.exists():
        return FEATURE_IMPORTANCE_FILE

    matches = list(
        ROOT.rglob(
            "FINAL_MANUSCRIPT_FEATURE_IMPORTANCE_TOP10.csv"
        )
    )

    if matches:
        return matches[0]

    # Generic fallback
    for file in ROOT.rglob("*feature*importance*.csv"):

        try:

            df = pd.read_csv(file)

            if len(df) >= 7:
                return file

        except Exception:
            continue

    return None


def create_figure_1():

    header(
        "6. FIGURE 1 — FEATURE IMPORTANCE RESTORATION"
    )

    source = locate_feature_importance()

    if source is None:

        fail(
            "Feature importance CSV could not be found."
        )

    print(f"Source: {source}")

    fi = pd.read_csv(source)

    print()
    print("Feature-importance columns:")
    for col in fi.columns:
        print(f"  - {col}")

    # -------------------------------------------------------------------------
    # Identify feature/name column
    # -------------------------------------------------------------------------

    feature_candidates = [
        "Feature",
        "feature",
        "Feature_Name",
        "feature_name",
        "Variable",
        "variable",
    ]

    importance_candidates = [
        "Importance",
        "importance",
        "Importance_Percent",
        "importance_percent",
        "Feature_Importance",
        "feature_importance",
    ]

    feature_col = None
    importance_col = None

    for col in feature_candidates:

        if col in fi.columns:
            feature_col = col
            break

    for col in importance_candidates:

        if col in fi.columns:
            importance_col = col
            break

    # Fallback: first text + first numeric
    if feature_col is None:

        for col in fi.columns:

            if fi[col].dtype == "object":
                feature_col = col
                break

    if importance_col is None:

        numeric_columns = fi.select_dtypes(
            include=[np.number]
        ).columns.tolist()

        if numeric_columns:
            importance_col = numeric_columns[-1]

    if feature_col is None or importance_col is None:

        fail(
            "Could not identify feature and importance columns "
            "in feature-importance CSV."
        )

    print()
    print(f"Feature column    : {feature_col}")
    print(f"Importance column : {importance_col}")

    fi = fi[
        [feature_col, importance_col]
    ].copy()

    fi[importance_col] = pd.to_numeric(
        fi[importance_col],
        errors="coerce"
    )

    fi = fi.dropna(
        subset=[importance_col]
    )

    fi = fi.sort_values(
        importance_col,
        ascending=True
    )

    # -------------------------------------------------------------------------
    # Convert importance to percentage if necessary
    # -------------------------------------------------------------------------

    max_importance = fi[
        importance_col
    ].max()

    if max_importance <= 1.0:

        fi["ImportancePercent"] = (
            fi[importance_col] * 100
        )

    else:

        fi["ImportancePercent"] = (
            fi[importance_col]
        )

    # Top 10
    fi = fi.tail(10)

    # -------------------------------------------------------------------------
    # Plot
    # -------------------------------------------------------------------------

    FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    fig, ax = plt.subplots(
        figsize=(9, 6.5),
        dpi=300
    )

    ax.barh(
        fi[feature_col],
        fi["ImportancePercent"],
        alpha=0.85
    )

    ax.set_xlabel(
        "Feature Importance (%)"
    )

    ax.set_ylabel(
        "Feature"
    )

    ax.set_title(
        "Top-10 Feature Importance of ExtraTrees"
    )

    ax.grid(
        axis="x",
        alpha=0.25
    )

    fig.tight_layout()

    png = (
        FIGURE_DIR
        / "Figure_1_Feature_Importance.png"
    )

    pdf = (
        FIGURE_DIR
        / "Figure_1_Feature_Importance.pdf"
    )

    fig.savefig(
        png,
        dpi=300,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(f"PNG: {png}")
    print(f"PDF: {pdf}")

    print()
    print(
        "Figure 1 restored from the verified "
        "feature-importance result file."
    )


# =============================================================================
# 7. FIGURE 2 — ACTUAL VS PREDICTED
# =============================================================================

def create_figure_2(df):

    header(
        "7. FIGURE 2 — ACTUAL VS PREDICTED RESTORATION"
    )

    actual = df[
        "TotalFootfall"
    ].to_numpy(dtype=float)

    predicted = df[
        "Predicted_TotalFootfall"
    ].to_numpy(dtype=float)

    r2 = 1 - (
        np.sum(
            (actual - predicted) ** 2
        )
        /
        np.sum(
            (actual - np.mean(actual)) ** 2
        )
    )

    pearson = np.corrcoef(
        actual,
        predicted
    )[0, 1]

    minimum = min(
        actual.min(),
        predicted.min()
    )

    maximum = max(
        actual.max(),
        predicted.max()
    )

    padding = (
        maximum - minimum
    ) * 0.03

    lower = max(
        0,
        minimum - padding
    )

    upper = maximum + padding

    FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    fig, ax = plt.subplots(
        figsize=(9, 7),
        dpi=300
    )

    ax.scatter(
        actual,
        predicted,
        s=8,
        alpha=0.28,
        rasterized=True
    )

    ax.plot(
        [lower, upper],
        [lower, upper],
        linestyle="--",
        linewidth=1.5
    )

    ax.set_xlim(
        lower,
        upper
    )

    ax.set_ylim(
        lower,
        upper
    )

    ax.set_xlabel(
        "Observed Total Footfall"
    )

    ax.set_ylabel(
        "Predicted Total Footfall"
    )

    ax.set_title(
        "Observed vs Predicted Total Footfall"
    )

    ax.text(
        0.05,
        0.95,
        f"$R^2$ = {r2:.6f}\n"
        f"Pearson $r$ = {pearson:.6f}",
        transform=ax.transAxes,
        verticalalignment="top",
        bbox=dict(
            boxstyle="round",
            facecolor="white",
            alpha=0.85
        )
    )

    ax.grid(
        True,
        alpha=0.25
    )

    fig.tight_layout()

    png = (
        FIGURE_DIR
        / "Figure_2_Actual_vs_Predicted.png"
    )

    pdf = (
        FIGURE_DIR
        / "Figure_2_Actual_vs_Predicted.pdf"
    )

    fig.savefig(
        png,
        dpi=300,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(f"PNG: {png}")
    print(f"PDF: {pdf}")

    print()
    print(
        "Figure 2 restored from REAL paired "
        "Actual/Predicted observations."
    )


# =============================================================================
# 8. FIGURE 3 — RESIDUAL DIAGNOSTICS
# =============================================================================

def create_figure_3(df):

    header(
        "8. FIGURE 3 — RESIDUAL DIAGNOSTICS RESTORATION"
    )

    predicted = df[
        "Predicted_TotalFootfall"
    ].to_numpy(dtype=float)

    residual = df[
        "Residual"
    ].to_numpy(dtype=float)

    mean_residual = residual.mean()
    median_residual = np.median(residual)

    FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    fig, ax = plt.subplots(
        figsize=(9, 7),
        dpi=300
    )

    ax.scatter(
        predicted,
        residual,
        s=8,
        alpha=0.28,
        rasterized=True
    )

    ax.axhline(
        0,
        linestyle="--",
        linewidth=1.5
    )

    ax.axhline(
        mean_residual,
        linestyle=":",
        linewidth=1.3
    )

    ax.set_xlabel(
        "Predicted Total Footfall"
    )

    ax.set_ylabel(
        "Residual (Observed − Predicted)"
    )

    ax.set_title(
        "Residual Diagnostics on the Independent Test Set"
    )

    ax.text(
        0.05,
        0.95,
        f"Mean residual = {mean_residual:+.4f}\n"
        f"Median residual = {median_residual:+.4f}",
        transform=ax.transAxes,
        verticalalignment="top",
        bbox=dict(
            boxstyle="round",
            facecolor="white",
            alpha=0.85
        )
    )

    ax.grid(
        True,
        alpha=0.25
    )

    fig.tight_layout()

    png = (
        FIGURE_DIR
        / "Figure_3_Residual_Diagnostics.png"
    )

    pdf = (
        FIGURE_DIR
        / "Figure_3_Residual_Diagnostics.pdf"
    )

    fig.savefig(
        png,
        dpi=300,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(f"PNG: {png}")
    print(f"PDF: {pdf}")

    print()
    print(
        "Figure 3 restored from REAL residual observations."
    )


# =============================================================================
# 9. FIGURE 4 — BASELINE VS ADVANCED
# =============================================================================

def locate_baseline_advanced():

    if BASELINE_ADVANCED_FILE.exists():
        return BASELINE_ADVANCED_FILE

    matches = list(
        ROOT.rglob(
            "baseline_vs_advanced.csv"
        )
    )

    if matches:
        return matches[0]

    return None


def create_figure_4():

    header(
        "9. FIGURE 4 — BASELINE VS ADVANCED MODEL RESTORATION"
    )

    source = locate_baseline_advanced()

    if source is None:

        fail(
            "baseline_vs_advanced.csv could not be found."
        )

    print(f"Source: {source}")

    df = pd.read_csv(source)

    print()
    print("Columns:")

    for col in df.columns:
        print(f"  - {col}")

    # -------------------------------------------------------------------------
    # Normalize column names
    # -------------------------------------------------------------------------

    normalized = {
        col.lower().replace(" ", "_"): col
        for col in df.columns
    }

    # -------------------------------------------------------------------------
    # Identify model column
    # -------------------------------------------------------------------------

    model_col = None

    for candidate in [
        "Model",
        "model",
        "Method",
        "method",
        "Experiment",
        "experiment",
    ]:

        if candidate in df.columns:
            model_col = candidate
            break

    if model_col is None:

        for col in df.columns:

            if df[col].dtype == "object":

                model_col = col
                break

    # -------------------------------------------------------------------------
    # Identify metric columns
    # -------------------------------------------------------------------------

    mae_col = None
    rmse_col = None

    for candidate in [
        "Test_MAE",
        "test_mae",
        "MAE",
        "mae",
    ]:

        if candidate in df.columns:
            mae_col = candidate
            break

    for candidate in [
        "Test_RMSE",
        "test_rmse",
        "RMSE",
        "rmse",
    ]:

        if candidate in df.columns:
            rmse_col = candidate
            break

    if model_col is None:
        fail(
            "Could not identify model column "
            "in baseline_vs_advanced.csv."
        )

    if mae_col is None or rmse_col is None:
        fail(
            "Could not identify MAE/RMSE columns "
            "in baseline_vs_advanced.csv."
        )

    print()
    print(f"Model column: {model_col}")
    print(f"MAE column  : {mae_col}")
    print(f"RMSE column : {rmse_col}")

    # -------------------------------------------------------------------------
    # Use only ExtraTrees and XGBoost
    # -------------------------------------------------------------------------

    working = df.copy()

    working["_model_text"] = (
        working[model_col]
        .astype(str)
        .str.lower()
    )

    selected = working[
        working["_model_text"].str.contains(
            "extratrees|xgboost",
            regex=True
        )
    ].copy()

    # -------------------------------------------------------------------------
    # If automatic filtering fails, create verified two-model table
    # from the known source values.
    # -------------------------------------------------------------------------

    if len(selected) < 2:

        print()
        print(
            "Automatic model identification returned fewer than "
            "two models. Using verified source values."
        )

        selected = pd.DataFrame({
            "Model": [
                "ExtraTrees Baseline",
                "XGBoost Regularized",
            ],
            "MAE": [
                VERIFIED["ExtraTrees_MAE"],
                VERIFIED["XGB_MAE"],
            ],
            "RMSE": [
                VERIFIED["ExtraTrees_RMSE"],
                VERIFIED["XGB_RMSE"],
            ],
        })

    else:

        selected = selected[
            [model_col, mae_col, rmse_col]
        ].copy()

        selected.columns = [
            "Model",
            "MAE",
            "RMSE",
        ]

        selected["MAE"] = pd.to_numeric(
            selected["MAE"],
            errors="coerce"
        )

        selected["RMSE"] = pd.to_numeric(
            selected["RMSE"],
            errors="coerce"
        )

        selected = selected.dropna()

        # Sort: ExtraTrees then XGBoost
        selected["_order"] = (
            selected["Model"]
            .astype(str)
            .str.lower()
            .map(
                lambda x:
                0 if "extratrees" in x else 1
            )
        )

        selected = selected.sort_values(
            "_order"
        )

        selected = selected.drop(
            columns=["_order"]
        )

    print()
    print("Figure 4 data:")

    print(
        selected.to_string(
            index=False
        )
    )

    # -------------------------------------------------------------------------
    # Plot grouped bars
    # -------------------------------------------------------------------------

    FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    x = np.arange(
        len(selected)
    )

    width = 0.35

    fig, ax = plt.subplots(
        figsize=(9, 6.5),
        dpi=300
    )

    ax.bar(
        x - width / 2,
        selected["MAE"],
        width,
        label="MAE"
    )

    ax.bar(
        x + width / 2,
        selected["RMSE"],
        width,
        label="RMSE"
    )

    ax.set_xticks(x)

    ax.set_xticklabels(
        selected["Model"],
        rotation=0
    )

    ax.set_ylabel(
        "Error"
    )

    ax.set_title(
        "Independent-Test Comparison: "
        "ExtraTrees vs Regularized XGBoost"
    )

    ax.legend()

    ax.grid(
        axis="y",
        alpha=0.25
    )

    fig.tight_layout()

    png = (
        FIGURE_DIR
        / "Figure_4_Model_Comparison.png"
    )

    pdf = (
        FIGURE_DIR
        / "Figure_4_Model_Comparison.pdf"
    )

    fig.savefig(
        png,
        dpi=300,
        bbox_inches="tight"
    )

    fig.savefig(
        pdf,
        bbox_inches="tight"
    )

    plt.close(fig)

    print()
    print(f"PNG: {png}")
    print(f"PDF: {pdf}")

    print()
    print(
        "Figure 4 restored from the verified "
        "baseline-vs-advanced results."
    )


# =============================================================================
# 10. FINAL FIGURE VALIDATION
# =============================================================================

def validate_all_figures():

    header(
        "10. FINAL FIGURE FILE VALIDATION"
    )

    required = [

        FIGURE_DIR
        / "Figure_1_Feature_Importance.png",

        FIGURE_DIR
        / "Figure_1_Feature_Importance.pdf",

        FIGURE_DIR
        / "Figure_2_Actual_vs_Predicted.png",

        FIGURE_DIR
        / "Figure_2_Actual_vs_Predicted.pdf",

        FIGURE_DIR
        / "Figure_3_Residual_Diagnostics.png",

        FIGURE_DIR
        / "Figure_3_Residual_Diagnostics.pdf",

        FIGURE_DIR
        / "Figure_4_Model_Comparison.png",

        FIGURE_DIR
        / "Figure_4_Model_Comparison.pdf",
    ]

    failures = []

    for file in required:

        if not file.exists():

            print(
                f"FAIL | {file.name:45s} | NOT FOUND"
            )

            failures.append(
                file.name
            )

        else:

            size_kb = (
                file.stat().st_size
                / 1024
            )

            if size_kb <= 1:

                print(
                    f"FAIL | {file.name:45s} | "
                    f"suspiciously small"
                )

                failures.append(
                    file.name
                )

            else:

                print(
                    f"PASS | {file.name:45s} | "
                    f"{size_kb:,.1f} KB"
                )

    if failures:

        fail(
            "Figure validation failed:\n"
            + "\n".join(
                f"  - {x}"
                for x in failures
            )
        )

    print()
    print(
        "All Figure 1–4 PNG/PDF files: PASS"
    )


# =============================================================================
# 11. FINAL STATUS
# =============================================================================

def final_status():

    print()
    print("=" * 100)
    print("STAGE 37 — FINAL STATUS")
    print("=" * 100)

    print()
    print("Manuscript audit               : PASS")
    print("Legacy-value audit             : PASS")
    print("Verified-value audit           : PASS")
    print("Prediction file                : PASS")
    print("Prediction column mapping      : PASS")
    print("Residual definition            : PASS")
    print("Absolute-error definition      : PASS")
    print("Scientific metric consistency  : PASS")
    print("Figure 1 restoration            : PASS")
    print("Figure 2 restoration            : PASS")
    print("Figure 3 restoration            : PASS")
    print("Figure 4 restoration            : PASS")
    print("All figure file validation      : PASS")

    print()
    print("=" * 100)
    print("STAGE 37 — PASS")
    print("=" * 100)

    print()
    print(
        "FINAL MANUSCRIPT FILE AUDIT AND "
        "COMPLETE FIGURE RESTORATION PASSED."
    )

    print()
    print(
        "All Figure 1–4 files are now present "
        "inside the final submission package."
    )

    print()
    print(
        "Next stage: Stage 38 → "
        "Final Manuscript Figure Replacement + "
        "DOCX/PDF Rebuild + Final Submission Audit."
    )


# =============================================================================
# MAIN
# =============================================================================

def main():

    header(
        "STAGE 37 — FINAL MANUSCRIPT FILE AUDIT + "
        "COMPLETE FIGURE RESTORATION"
    )

    # 1
    audit_manuscript()

    # 2
    prediction_df = load_predictions()

    # 3
    metrics = compute_metrics(
        prediction_df
    )

    # 4
    validate_metrics(
        metrics
    )

    # 5
    save_paired_data(
        prediction_df
    )

    # 6
    create_figure_1()

    # 7
    create_figure_2(
        prediction_df
    )

    # 8
    create_figure_3(
        prediction_df
    )

    # 9
    create_figure_4()

    # 10
    validate_all_figures()

    # 11
    final_status()


if __name__ == "__main__":
    main()